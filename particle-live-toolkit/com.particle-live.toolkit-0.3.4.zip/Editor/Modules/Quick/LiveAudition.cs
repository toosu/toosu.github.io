using System;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.AnimationRepeat;
using ParticleLiveToolkit.Modules.LivePreview;
using UnityEditor;
using UnityEditor.ShortcutManagement;
using UnityEditor.Timeline;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UIElements;

namespace ParticleLiveToolkit.Modules.Quick
{
    [InitializeOnLoad]
    internal static class LiveAudition
    {
        const double HoldSeconds = 0.30;
        const double TimelineDriftTolerance = 0.08;
        internal const string AnimationShortcut = "Particle Live/長押しプレビュー（Animation）";
        internal const string TimelineShortcut = "Particle Live/長押しプレビュー（Timeline）";
        static bool bindingsDirty = true, bindingsObserved, animationBound, timelineBound, customPress;
        static ParticleLiveProject project;
        static GameObject root;
        static bool loaded, down, held, sawKeyDown;
        static EditorWindow window;
        static double pressedAt, origin, nextSample, lastPosition;
        static bool lastValid, physicalDown;
        static PlayableDirector director;
        static PlayableAsset sequence;
        static AnimationClip clip;
        static TimelinePlaybackControls transport;
        static double start, end, loopStart, loopEnd;
        static bool loop, reachedEnd;
        static long audioCycle;
        static PlayableGraph graph;
        static DirectorUpdateMode previousClock;
        static object previousFrameRate;
        static readonly EditorPreviewAudio audio = new EditorPreviewAudio();
        const BindingFlags Instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static readonly PropertyInfo animState = typeof(AnimationWindow).GetProperty("state", Instance);
        static readonly PropertyInfo linked = animState?.PropertyType.GetProperty("linkedWithSequencer", Instance);
        static readonly PropertyInfo timelineState = typeof(TimelineEditor).GetProperty("state", BindingFlags.NonPublic | BindingFlags.Static);
        static readonly PropertyInfo timelinePlaying = timelineState?.PropertyType.GetProperty("playing", Instance);
        static readonly PropertyInfo rangeEnabled = timelineState?.PropertyType.GetProperty("playRangeEnabled", Instance);
        static readonly PropertyInfo playRange = timelineState?.PropertyType.GetProperty("playRange", Instance);
        static readonly MethodInfo frameLocked = typeof(PlayableGraph).GetMethod("IsMatchFrameRateEnabled", Instance);
        static readonly MethodInfo getRate = typeof(PlayableGraph).GetMethod("GetFrameRate", Instance);
        static readonly MethodInfo lockRate = typeof(PlayableGraph).GetMethod("EnableMatchFrameRate", Instance);
        static readonly MethodInfo unlockRate = typeof(PlayableGraph).GetMethod("DisableMatchFrameRate", Instance);
        const TimelinePlaybackControls.Context Global = TimelinePlaybackControls.Context.Global;

        static LiveAudition()
        {
            EditorApplication.update += Tick;
            AssemblyReloadEvents.beforeAssemblyReload += SaveAndStop;
            EditorApplication.quitting += SaveAndStop;
        }

        internal static void Select(ParticleLiveProject p)
        {
            if (!loaded || p != project) { Cancel(); root = null; project = p; loaded = true; }
        }

        internal static bool Owns(ParticleLiveProject p, PlayableDirector director)
        {
            if (!p || !director) return false;
            var owner = p == project && root ? root : ProjectSceneUtility.FindRoot(p);
            if (p == project) root = owner;
            return owner && director.transform.IsChildOf(owner.transform);
        }

        static bool Matches()
        {
            if (!project || !window || EditorApplication.isPlayingOrWillChangePlaymode) return false;
            if (window is TimelineEditorWindow) return Owns(project, TimelineEditor.inspectedDirector);
            if (!(window is AnimationWindow a) || !project.mainClip || a.animationClip != project.mainClip) return false;
            if (Linked(a)) return Owns(project, TimelineEditor.inspectedDirector);
            var go = AnimationWindowBridge.GetEditedRoot(a);
            if (!root) root = ProjectSceneUtility.FindRoot(project);
            return go && root && go.transform.IsChildOf(root.transform);
        }

        static readonly PropertyInfo control = animState?.PropertyType.GetProperty("controlInterface", Instance);
        static bool Linked(AnimationWindow a)
        {
            var state = animState?.GetValue(a);
            return state != null && (linked?.GetValue(state) as bool? == true ||
                control?.GetValue(state)?.GetType().Assembly == typeof(TimelineEditor).Assembly);
        }
        static bool UsesTimeline => window is TimelineEditorWindow || window is AnimationWindow a && Linked(a);
        static double Position => UsesTimeline ? TimelineEditor.GetWindow().playbackControls.GetCurrentTime(Global) : ((AnimationWindow)window).time;
        static bool Playing => window is AnimationWindow a ? a.playing :
            timelinePlaying?.GetValue(timelineState.GetValue(null)) as bool? == true;

        static void TrackFocus()
        {
            var focus = EditorWindow.focusedWindow;
            var next = focus is AnimationWindow || focus is TimelineEditorWindow ? focus : null;
            if (next != window)
            {
                Cancel();
                if (window) { window.rootVisualElement.UnregisterCallback<KeyDownEvent>(KeyDown, TrickleDown.TrickleDown); window.rootVisualElement.UnregisterCallback<KeyUpEvent>(KeyUp, TrickleDown.TrickleDown); }
                physicalDown = lastValid = false;
                window = next;
                if (window) { window.rootVisualElement.RegisterCallback<KeyDownEvent>(KeyDown, TrickleDown.TrickleDown); window.rootVisualElement.RegisterCallback<KeyUpEvent>(KeyUp, TrickleDown.TrickleDown); }
            }
        }

        static bool HasCustomBinding()
        {
            if (!bindingsObserved)
            {
                ShortcutManager.instance.activeProfileChanged += _ => bindingsDirty = true;
                ShortcutManager.instance.shortcutBindingChanged += _ => bindingsDirty = true;
                bindingsObserved = true;
            }
            if (bindingsDirty)
            {
                animationBound = ShortcutManager.instance.GetShortcutBinding(AnimationShortcut).keyCombinationSequence.Any();
                timelineBound = ShortcutManager.instance.GetShortcutBinding(TimelineShortcut).keyCombinationSequence.Any();
                bindingsDirty = false;
            }
            return window is AnimationWindow ? animationBound : timelineBound;
        }

        [ClutchShortcut(AnimationShortcut, typeof(AnimationWindow))]
        static void AnimationPreview(ShortcutArguments args) => CustomPreview(args);

        [ClutchShortcut(TimelineShortcut, typeof(TimelineEditorWindow))]
        static void TimelinePreview(ShortcutArguments args) => CustomPreview(args);

        static void CustomPreview(ShortcutArguments args)
        {
            if (args.stage == ShortcutStage.End)
            {
                if (!customPress || window != args.context as EditorWindow) return;
                if (!held && EditorApplication.timeSinceStartup - pressedAt < HoldSeconds &&
                    window == EditorWindow.focusedWindow && Matches() && SameTarget())
                {
                    try
                    {
                        if (transport == null) ((AnimationWindow)window).playing = !Playing;
                        else if (Playing) transport.Pause();
                        else transport.Play();
                    }
                    finally { Reset(); }
                }
                else Finish();
                return;
            }
            if (!loaded) Select(ActiveProjectMemory.Load());
            TrackFocus();
            if (down || !window || window != args.context as EditorWindow || EditorGUIUtility.editingTextField ||
                window.rootVisualElement.focusController?.focusedElement is TextElement || !Matches()) return;
            Begin(Position);
            customPress = true;
        }

        static void Tick()
        {
            if (!loaded) Select(ActiveProjectMemory.Load());
            TrackFocus();
            if (!window || !UnityEditorInternal.InternalEditorUtility.isApplicationActive) { Cancel(); lastValid = false; return; }
#if UNITY_EDITOR_WIN
            bool physical = !HasCustomBinding() && PhysicalSpace();
            // Unity's native shortcut handler can consume KeyDown before UI Toolkit.
            if (!down && physical && !physicalDown && lastValid && !EditorGUIUtility.editingTextField &&
                !OtherModifier() && Matches()) Begin(lastPosition);
            physicalDown = physical;
#endif
            if (down)
            {
                if (!Matches() || !SameTarget()) { Finish(); return; }
#if UNITY_EDITOR_WIN
                if (!customPress && !physical) { Finish(); return; }
#endif
                if (!held && EditorApplication.timeSinceStartup - pressedAt >= HoldSeconds) StartHold();
                else if (held) AdvanceHold(EditorApplication.timeSinceStartup);
            }
            else
            {
                lastValid = Matches();
                if (!lastValid) return;
                lastPosition = Position;
                if (!Playing && EditorApplication.timeSinceStartup >= nextSample)
                {
                    nextSample = EditorApplication.timeSinceStartup + 0.08;
                    Remember();
                }
            }
        }

#if UNITY_EDITOR_WIN
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
        static bool OtherModifier() => ((GetAsyncKeyState(0x10) | GetAsyncKeyState(0x11) | GetAsyncKeyState(0x12) | GetAsyncKeyState(0x5b) | GetAsyncKeyState(0x5c)) & 0x8000) != 0;
        static bool PhysicalSpace() => (GetAsyncKeyState(0x20) & 0x8000) != 0;
#endif

        static void KeyDown(KeyDownEvent e)
        {
            if (e.keyCode != KeyCode.Space || e.modifiers != EventModifiers.None || EditorGUIUtility.editingTextField ||
                e.target is TextElement || HasCustomBinding() || !Matches()) return;
            if (down && sawKeyDown) { e.StopImmediatePropagation(); e.PreventDefault(); return; }
            if (!down) Begin(Position);
            sawKeyDown = true;
        }
        static void Begin(double at)
        {
            pressedAt = EditorApplication.timeSinceStartup;
            origin = at;
            transport = UsesTimeline ? TimelineEditor.GetWindow().playbackControls : null;
            director = transport != null ? TimelineEditor.masterDirector : null;
            sequence = director ? director.playableAsset : null;
            clip = (window as AnimationWindow)?.animationClip;
            down = true;
            // Leave the initial event to Unity's normal play/pause shortcut.
        }
        static void KeyUp(KeyUpEvent e) { if (down && !customPress && e.keyCode == KeyCode.Space) Finish(); }

        static void StartHold()
        {
            held = true;
            if (transport != null && director)
            {
                transport.Play();
                end = director.duration;
                loopStart = 0;
                loopEnd = end;
                loop = director.extrapolationMode == DirectorWrapMode.Loop;
                var state = timelineState?.GetValue(null);
                if (state != null && rangeEnabled?.GetValue(state) as bool? == true)
                {
                    var range = playRange?.GetValue(state);
                    if (range?.GetType().GetField("start")?.GetValue(range) is double first &&
                        range.GetType().GetField("end")?.GetValue(range) is double last && last > first)
                    { loop = true; loopStart = first; loopEnd = last; }
                }
                graph = director.playableGraph;
                if (graph.IsValid())
                {
                    previousClock = graph.GetTimeUpdateMode();
                    if (frameLocked?.Invoke(graph, null) as bool? == true && getRate != null && lockRate != null && unlockRate != null)
                    {
                        previousFrameRate = getRate.Invoke(graph, null);
                        unlockRate.Invoke(graph, null);
                    }
                    graph.SetTimeUpdateMode(DirectorUpdateMode.DSPClock);
                }
            }
            else if (window is AnimationWindow a)
            {
                // Sample only the visible instant. Native playback would evaluate the same clip again.
                a.playing = false;
                if (a.canPreview) a.previewing = true;
                end = clip.length > 0 ? clip.length : project.song ? project.song.length : 0;
                loop = end > 0;
                loopStart = 0;
                loopEnd = end;
                audioCycle = -1;
            }
            start = loop && (origin < loopStart || origin >= loopEnd) ? loopStart : origin;
            reachedEnd = false;
            AdvanceHold(EditorApplication.timeSinceStartup);
        }

        static bool SameTarget() => transport != null
            ? director && TimelineEditor.masterDirector == director && director.playableAsset == sequence &&
                (!(window is AnimationWindow linkedWindow) || linkedWindow.animationClip == clip)
            : window is AnimationWindow a && a.animationClip == clip;

        static void AdvanceHold(double now)
        {
            double raw = start + Math.Max(0, now - pressedAt);
            double target = loop ? PreviewTimeMath.WrapIntoLoop(raw, loopStart, loopEnd) : PreviewTimeMath.ClampTime(raw, end);
            if (transport != null)
            {
                // Preserve continuous Timeline mixing, offsets and clip speeds. Seek only on a real clock slip.
                if (!loop && raw >= end)
                {
                    if (!reachedEnd) { transport.Pause(); transport.SetCurrentTime(end, Global); reachedEnd = true; }
                    return;
                }
                if (Math.Abs(transport.GetCurrentTime(Global) - target) > TimelineDriftTolerance)
                    transport.SetCurrentTime(target, Global);
                return;
            }
            var a = (AnimationWindow)window;
            long cycle = loop ? (long)Math.Floor((raw - loopStart) / (loopEnd - loopStart)) : 0;
            if (cycle != audioCycle)
            {
                audioCycle = cycle;
                audio.Stop();
                if (project.song && target < project.song.length) audio.Play(project.song, target);
            }
            if (audio.TryGetTime(out var audible) && Math.Abs(audible - target) < 0.15)
                target = PreviewTimeMath.ClampTime(audible, end);
            int frame = Mathf.RoundToInt((float)(target * clip.frameRate));
            if (a.frame != frame) { a.time = (float)target; a.Repaint(); }
        }

        static void Finish()
        {
            if (!down) return;
            try
            {
                if ((held || EditorApplication.timeSinceStartup - pressedAt >= HoldSeconds) && SameTarget() && Matches())
                {
                    if (transport != null) { transport.Pause(); transport.SetCurrentTime(origin, Global); }
                    else if (window is AnimationWindow a) { a.playing = false; a.time = (float)origin; }
                    Remember();
                    window.Repaint();
                }
                else if (held && graph.IsValid() && director && director.playableAsset == sequence && graph.Equals(director.playableGraph))
                    director.Pause();
            }
            finally { Reset(); }
        }

        static void Remember()
        {
            LiveWorkspace.Remember(project, Position);
        }

        static void SaveAndStop()
        {
            if (down) Cancel();
            else if (Matches() && !Playing) Remember();
            LiveSettings.Flush();
        }

        static void Cancel() { if (down) Finish(); }
        static void Reset()
        {
            if (graph.IsValid())
            {
                graph.SetTimeUpdateMode(previousClock);
                if (previousFrameRate != null) lockRate.Invoke(graph, new[] { previousFrameRate });
            }
            graph = default;
            previousFrameRate = null;
            transport = null;
            director = null;
            sequence = null;
            clip = null;
            audio.Stop();
            customPress = sawKeyDown = held = down = false;
        }
    }
}
