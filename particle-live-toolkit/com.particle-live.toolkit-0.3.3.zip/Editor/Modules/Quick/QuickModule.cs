using System;
using System.Collections.Generic;
using System.Linq;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.AnimationRepeat;
using ParticleLiveToolkit.Modules.PathFixer;
using UnityEditor;
using UnityEditor.ShortcutManagement;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.Quick
{
    internal sealed class RepeatCursor : ScriptableObject
    {
        public double offset;
    }

    public sealed class QuickModule : IToolkitModule, IDisposable
    {
        public string Id => "quick";
        public string DisplayName => "よく使う項目";
        public int Order => 0;

        private HierarchySnapshot before;
        private Transform pathRoot;
        private AnimationClip clip, capture;
        private ClipCurveRef[] curves;
        private double start, end;
        private RepeatCursor cursor;
        private ParticleLiveProject capturedProject;
        public void OnEnable(ToolkitContext ctx) { }
        public void OnDisable() { }
        public void Dispose()
        {
            if (capture) UnityEngine.Object.DestroyImmediate(capture);
            if (cursor) UnityEngine.Object.DestroyImmediate(cursor);
        }

        internal static Transform ResolveRoot(ToolkitContext ctx)
        {
            var root = ProjectSceneUtility.FindRoot(ctx.ActiveProject);
            if (root) return PathTrackingService.FindPathBase(root.transform, out _);
            var animator = Selection.activeTransform ? Selection.activeTransform.GetComponentInParent<Animator>() : null;
            return animator ? animator.transform : null;
        }

        internal static bool Repair(Transform root, HierarchySnapshot baseline, ParticleLiveProject project, out string message)
        {
            if (!root || baseline == null || baseline.RootId != root.gameObject.GetInstanceID())
            {
                message = "同じ Animator で変更前の状態を取得してください。";
                return false;
            }
            var diff = HierarchyDiffCalculator.Compute(baseline, HierarchySnapshot.Capture(root));
            var build = PathFixPlanner.BuildRemaps(diff.Candidates, null, null);
            if (diff.Candidates.Any(c => c.NeedsReview) || build.Errors.Count > 0 || diff.Missing.Count > 0)
            {
                message = "自動で判断できない変更があります。Path Fixer で確認してください。";
                return false;
            }
            var animator = root.GetComponent<Animator>();
            var clips = PathFixPlanner.CollectTargetClips(animator ? animator.runtimeAnimatorController : null,
                project && project.mainClip ? new[] { project.mainClip } : null);
            var plan = PathFixPlanner.Preview(clips, build.Remaps);
            if (plan.SkippedClipCount > 0)
            {
                message = "書き換えられないクリップがあります。Path Fixer で確認してください。";
                return false;
            }
            if (plan.TotalChanges == 0) { message = "修正対象のパスはありません。"; return true; }
            var result = PathFixPlanner.Apply(plan);
            message = result.TotalBindings + " 件のパスを修正しました。";
            return result.Skipped.Count == 0;
        }

        public void OnGUI(ToolkitContext ctx)
        {
            ToolkitGUI.Section("オブジェクト変更時パス自動修正");
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("変更前に押す"))
                {
                    pathRoot = ResolveRoot(ctx);
                    before = pathRoot ? HierarchySnapshot.Capture(pathRoot) : null;
                    ctx.ShowNotification(pathRoot ? "変更前の階層を記録しました" : "ライブまたは Animator を選択してください");
                }
                using (new EditorGUI.DisabledScope(before == null))
                if (GUILayout.Button("変更後に押す"))
                {
                    if (Repair(ResolveRoot(ctx), before, ctx.ActiveProject, out string result)) before = null;
                    ctx.ShowNotification(result);
                }
            }

            ToolkitGUI.Section("秒数コピー");
            double beat = BeatMath.BeatSeconds(ctx.Bpm);
            using (new EditorGUILayout.HorizontalScope())
            {
                double bar = BeatMath.BarSeconds(ctx.Bpm, ctx.BeatsPerBar);
                Copy(ctx, "1小節", bar);
                Copy(ctx, "2小節", 2 * bar);
                Copy(ctx, "4小節", 4 * bar);
            }
            using (new EditorGUILayout.HorizontalScope())
            {
                foreach (int division in new[] { 2, 4, 3 }) Copy(ctx, division + "分", BeatMath.NoteSeconds(ctx.Bpm, division));
            }

            ToolkitGUI.Section("キーフレームリピート用");
            if (GUILayout.Button("現在の範囲を取得")) Capture(ctx);
            using (new EditorGUI.DisabledScope(!capture || !clip || capturedProject != ctx.ActiveProject))
            using (new EditorGUILayout.HorizontalScope())
            {
                foreach (int beats in new[] { 1, 2, 4 })
                    if (GUILayout.Button((beats == 1 ? "" : beats.ToString()) + "ビートで4回")) Append(ctx, beat * beats);
            }
            GUILayout.Space(6f);
            if (GUILayout.Button(new GUIContent("ショートカット設定を開く", "Unity のショートカット設定で「Particle Live」を検索してください。")))
            {
                string menu = Application.platform == RuntimePlatform.OSXEditor ? "Unity/Shortcuts..." : "Edit/Shortcuts...";
                if (!EditorApplication.ExecuteMenuItem(menu)) ctx.ShowNotification("Unity の Shortcuts を開き、「Particle Live」を検索してください");
            }
        }

        static void Copy(ToolkitContext ctx, string label, double seconds)
        {
            if (!GUILayout.Button(label)) return;
            EditorGUIUtility.systemCopyBuffer = BeatMath.FormatSeconds(seconds);
            ctx.ShowNotification(EditorGUIUtility.systemCopyBuffer + " 秒");
        }

        void Capture(ToolkitContext ctx)
        {
            var keys = new List<SelectedKeyInfo>();
            if (!new AnimationWindowBridge().TryGetSelectedKeys(keys, out string reason) || keys.Count == 0)
            { ctx.ShowNotification(reason ?? "Animation でキーを選択してください"); return; }
            CaptureKeys(ctx, keys);
        }

        internal void CaptureKeys(ToolkitContext ctx, List<SelectedKeyInfo> keys)
        {
            var target = keys[0].Clip;
            if (!target || keys.Any(k => k.Clip != target))
            { ctx.ShowNotification("1つのクリップのキーを選択してください"); return; }
            var selected = new HashSet<string>(keys.Select(k => CurveRefKey.Of(k.Curve)));
            var matched = ClipEditUtility.GetAllCurves(target).Where(c => selected.Contains(CurveRefKey.Of(c))).ToArray();
            if (matched.Length != selected.Count)
            { ctx.ShowNotification("実カーブを特定できません。Curves 表示で対象成分のキーを選択してください"); return; }
            if (capture) UnityEngine.Object.DestroyImmediate(capture);
            if (cursor) UnityEngine.Object.DestroyImmediate(cursor);
            cursor = ScriptableObject.CreateInstance<RepeatCursor>();
            cursor.hideFlags = HideFlags.HideAndDontSave;
            capture = UnityEngine.Object.Instantiate(target);
            capture.hideFlags = HideFlags.HideAndDontSave;
            clip = target;
            capturedProject = ctx.ActiveProject;
            curves = matched;
            start = keys.Min(k => k.Time);
            end = keys.Max(k => k.Time);
            ctx.ShowNotification(curves.Length + " カーブの範囲を取得しました");
        }

        internal void Append(ToolkitContext ctx, double step)
        {
            var options = new AnimationRepeatController(ctx.State(ToolkitModuleIds.AnimationRepeat), null);
            var request = new RepeatRequest { Clip = clip, CapturedSource = capture, PreviousOffset = cursor.offset,
                StartSeconds = start, EndSeconds = end, IncludeEndKey = true,
                TargetCurves = curves, IntervalSeconds = step, Count = 4, Policy = options.Policy, SnapToFrames = options.SnapToFrames };
            var plan = RangeRepeater.Preview(request);
            if (!plan.CanExecute || plan.AddedKeyCount == 0)
            { ctx.ShowNotification(plan.Reason ?? "追加できるキーがありません"); return; }
            if (plan.RemovedKeyCount > 0 && !EditorUtility.DisplayDialog("リピート", plan.RemovedKeyCount + " 個の既存キーが置き換わります。", "適用", "キャンセル")) return;
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            var result = RangeRepeater.Apply(request);
            if (result.CanExecute)
            {
                Undo.RegisterCompleteObjectUndo(cursor, RangeRepeater.UndoName);
                cursor.offset += 4 * step;
                Undo.CollapseUndoOperations(group);
            }
            ctx.ShowNotification(result.Reason ?? result.AddedKeyCount + " キー追加");
        }
    }

    internal static class BeatShortcuts
    {
        internal enum StepUnit { Bar, Quarter, Sixteenth }

        [Shortcut("Particle Live/4分 戻る", typeof(AnimationWindow), KeyCode.Alpha1, ShortcutModifiers.Alt)]
        static void BackQuarterNumber(ShortcutArguments args) => Step(args, StepUnit.Quarter, -1);

        [Shortcut("Particle Live/4分 戻る（矢印）", typeof(AnimationWindow), KeyCode.LeftArrow, ShortcutModifiers.Alt)]
        static void BackQuarterArrow(ShortcutArguments args) => Step(args, StepUnit.Quarter, -1);

        [Shortcut("Particle Live/4分 進む", typeof(AnimationWindow), KeyCode.Alpha2, ShortcutModifiers.Alt)]
        static void ForwardQuarterNumber(ShortcutArguments args) => Step(args, StepUnit.Quarter, 1);

        [Shortcut("Particle Live/4分 進む（矢印）", typeof(AnimationWindow), KeyCode.RightArrow, ShortcutModifiers.Alt)]
        static void ForwardQuarterArrow(ShortcutArguments args) => Step(args, StepUnit.Quarter, 1);

        [Shortcut("Particle Live/1小節 戻る", typeof(AnimationWindow), KeyCode.Alpha3, ShortcutModifiers.Alt)]
        static void BackBarNumber(ShortcutArguments args) => Step(args, StepUnit.Bar, -1);

        [Shortcut("Particle Live/1小節 戻る（矢印）", typeof(AnimationWindow), KeyCode.LeftArrow, ShortcutModifiers.Alt | ShortcutModifiers.Shift)]
        static void BackBarArrow(ShortcutArguments args) => Step(args, StepUnit.Bar, -1);

        [Shortcut("Particle Live/1小節 進む", typeof(AnimationWindow), KeyCode.Alpha4, ShortcutModifiers.Alt)]
        static void ForwardBarNumber(ShortcutArguments args) => Step(args, StepUnit.Bar, 1);

        [Shortcut("Particle Live/1小節 進む（矢印）", typeof(AnimationWindow), KeyCode.RightArrow, ShortcutModifiers.Alt | ShortcutModifiers.Shift)]
        static void ForwardBarArrow(ShortcutArguments args) => Step(args, StepUnit.Bar, 1);

        [Shortcut("Particle Live/16分 戻る", typeof(AnimationWindow), KeyCode.Alpha5, ShortcutModifiers.Alt)]
        static void BackSixteenthNumber(ShortcutArguments args) => Step(args, StepUnit.Sixteenth, -1);

        [Shortcut("Particle Live/16分 戻る（矢印）", typeof(AnimationWindow), KeyCode.LeftArrow, ShortcutModifiers.Alt | ShortcutModifiers.Action)]
        static void BackSixteenthArrow(ShortcutArguments args) => Step(args, StepUnit.Sixteenth, -1);

        [Shortcut("Particle Live/16分 進む", typeof(AnimationWindow), KeyCode.Alpha6, ShortcutModifiers.Alt)]
        static void ForwardSixteenthNumber(ShortcutArguments args) => Step(args, StepUnit.Sixteenth, 1);

        [Shortcut("Particle Live/16分 進む（矢印）", typeof(AnimationWindow), KeyCode.RightArrow, ShortcutModifiers.Alt | ShortcutModifiers.Action)]
        static void ForwardSixteenthArrow(ShortcutArguments args) => Step(args, StepUnit.Sixteenth, 1);

        internal static double StepSeconds(StepUnit unit, ToolkitContext context)
        {
            return unit == StepUnit.Bar ? BeatMath.BarSeconds(context.Bpm, context.BeatsPerBar)
                : BeatMath.NoteSeconds(context.Bpm, unit == StepUnit.Quarter ? 4 : 16);
        }

        static AnimationWindow lastWindow;
        static AnimationClip lastClip;
        static double exactFrame;
        static int lastFrame;
        static void Step(ShortcutArguments args, StepUnit unit, int sign)
        {
            var window = args.context as AnimationWindow;
            if (!window || !window.animationClip || EditorGUIUtility.editingTextField) return;
            var context = new ToolkitContext();
            context.SetActiveProject(ActiveProjectMemory.Load());
            if (window != lastWindow || lastClip != window.animationClip || lastFrame != window.frame) exactFrame = window.frame;
            exactFrame = Math.Max(0, exactFrame + sign * StepSeconds(unit, context) * window.animationClip.frameRate);
            window.frame = (int)Math.Min(int.MaxValue, Math.Round(exactFrame, MidpointRounding.AwayFromZero));
            lastWindow = window;
            lastClip = window.animationClip;
            lastFrame = window.frame;
            window.Repaint();
        }
    }
}
