using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>Animation ウィンドウで選択中のキー 1 個。</summary>
    public readonly struct SelectedKeyInfo
    {
        /// <summary>キーが属するクリップ。</summary>
        public readonly AnimationClip Clip;

        public readonly ClipCurveRef Curve;

        /// <summary>キーの時刻(クリップ上の秒)。</summary>
        public readonly float Time;

        public SelectedKeyInfo(AnimationClip clip, ClipCurveRef curve, float time)
        {
            Clip = clip;
            Curve = curve;
            Time = time;
        }
    }

    /// <summary>
    /// 開いている Animation ウィンドウとの橋渡し。どのメソッドも例外を投げず、使えないときは false と理由(日本語)を返す。
    /// テストでは偽実装に差し替える。
    /// </summary>
    public interface IAnimationWindowBridge
    {
        /// <summary>Animation ウィンドウが開いているか(軽い判定。毎フレーム呼んでよい)。</summary>
        bool IsWindowAvailable(out string reason);

        /// <summary>選択中のキーを取得できる状態か(軽い判定。毎フレーム呼んでよい。選択が 0 個かどうかまでは見ない)。</summary>
        bool CanGetSelectedKeys(out string reason);

        /// <summary>Animation ウィンドウに表示中のクリップ。</summary>
        bool TryGetClip(out AnimationClip clip, out string reason);

        /// <summary>Animation ウィンドウの再生ヘッドの時刻(秒)。</summary>
        bool TryGetTime(out double time, out string reason);

        /// <summary>選択中のキーを result に入れる(最初に result を空にする)。使えないときは空のまま false。</summary>
        bool TryGetSelectedKeys(List<SelectedKeyInfo> result, out string reason);
    }

    /// <summary>
    /// IAnimationWindowBridge の本物。公開 API(AnimationWindow.animationClip / time)と、
    /// 選択キーの取得だけ Unity 内部 API をリフレクションで使う(このクラスの外には出さない)。
    ///
    /// 使う内部メンバー(Unity 2022.3.22f1 で確認):
    ///   UnityEditor.AnimationWindow            : private フィールド m_AnimEditor(UnityEditor.AnimEditor)
    ///                                            ※無ければ non-public プロパティ state を使う
    ///   UnityEditor.AnimEditor                 : プロパティ state(UnityEditorInternal.AnimationWindowState)
    ///   UnityEditorInternal.AnimationWindowState    : プロパティ selectedKeys(List&lt;AnimationWindowKeyframe&gt;)、

    ///   UnityEditorInternal.AnimationWindowKeyframe : プロパティ time(float)、curve(AnimationWindowCurve)
    ///   UnityEditorInternal.AnimationWindowCurve    : プロパティ binding(EditorCurveBinding)、isPPtrCurve(bool)、clip(AnimationClip)
    /// </summary>
    public sealed class AnimationWindowBridge : IAnimationWindowBridge
    {
        const string NotOpenReason = "Animation ウィンドウが開いていません(Window > Animation > Animation で開けます)。";
        const string NoClipReason = "Animation ウィンドウにクリップが表示されていません。アニメーションするオブジェクトを選択してください。";
        const string UnsupportedPrefix = "この Unity では選択中のキーを取得できません(内部 API が見つかりません: ";

        sealed class Members
        {
            public FieldInfo AnimEditorField;
            public PropertyInfo WindowState;
            public PropertyInfo EditorState;
            public PropertyInfo SelectedKeys;

            public PropertyInfo KeyTime;
            public PropertyInfo KeyCurve;
            public PropertyInfo CurveBinding;
            public PropertyInfo CurveIsPPtr;
            public PropertyInfo CurveClip;
        }

        static bool s_resolved;
        static Members s_members;
        static string s_resolveError;

        /// <summary>内部 API のメンバーがすべて見つかるか(結果はキャッシュ)。</summary>
        internal static bool InternalApiResolved(out string reason)
        {
            Members m = Resolve();
            reason = m == null ? UnsupportedPrefix + s_resolveError + ")。" : null;
            return m != null;
        }

        static Members Resolve()
        {
            if (s_resolved) return s_members;
            s_resolved = true;
            try
            {
                const BindingFlags inst = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
                Assembly editor = typeof(AnimationWindow).Assembly;
                var m = new Members
                {
                    AnimEditorField = typeof(AnimationWindow).GetField("m_AnimEditor", inst),
                    WindowState = typeof(AnimationWindow).GetProperty("state", inst),
                };
                Type stateType = editor.GetType("UnityEditorInternal.AnimationWindowState");
                Type keyType = editor.GetType("UnityEditorInternal.AnimationWindowKeyframe");
                Type curveType = editor.GetType("UnityEditorInternal.AnimationWindowCurve");
                if (m.AnimEditorField != null) m.EditorState = m.AnimEditorField.FieldType.GetProperty("state", inst);
                if (stateType != null)
                {
                    m.SelectedKeys = stateType.GetProperty("selectedKeys", inst);

                }
                if (keyType != null)
                {
                    m.KeyTime = keyType.GetProperty("time", inst);
                    m.KeyCurve = keyType.GetProperty("curve", inst);
                }
                if (curveType != null)
                {
                    m.CurveBinding = curveType.GetProperty("binding", inst);
                    m.CurveIsPPtr = curveType.GetProperty("isPPtrCurve", inst);
                    m.CurveClip = curveType.GetProperty("clip", inst);
                }

                var missing = new List<string>();
                if ((m.AnimEditorField == null || m.EditorState == null) && m.WindowState == null) missing.Add("AnimationWindow.m_AnimEditor.state");
                if (m.SelectedKeys == null) missing.Add("AnimationWindowState.selectedKeys");
                if (m.KeyTime == null || m.KeyTime.PropertyType != typeof(float)) missing.Add("AnimationWindowKeyframe.time");
                if (m.KeyCurve == null) missing.Add("AnimationWindowKeyframe.curve");
                if (m.CurveBinding == null || m.CurveBinding.PropertyType != typeof(EditorCurveBinding)) missing.Add("AnimationWindowCurve.binding");
                if (m.CurveIsPPtr == null || m.CurveIsPPtr.PropertyType != typeof(bool)) missing.Add("AnimationWindowCurve.isPPtrCurve");
                if (missing.Count > 0)
                {
                    s_resolveError = string.Join(", ", missing);
                    return null;
                }
                s_members = m;
                return m;
            }
            catch (Exception e)
            {
                s_resolveError = e.GetType().Name + ": " + e.Message;
                return null;
            }
        }

        public bool IsWindowAvailable(out string reason)
        {
            try
            {
                if (!EditorWindow.HasOpenInstances<AnimationWindow>())
                {
                    reason = NotOpenReason;
                    return false;
                }
                reason = null;
                return true;
            }
            catch (Exception e)
            {
                reason = "Animation ウィンドウの状態を確認できませんでした(" + e.Message + ")。";
                return false;
            }
        }

        public bool CanGetSelectedKeys(out string reason)
        {
            if (!IsWindowAvailable(out reason)) return false;
            return InternalApiResolved(out reason);
        }

        public bool TryGetClip(out AnimationClip clip, out string reason)
        {
            clip = null;
            try
            {
                AnimationWindow window = FindWindow(out reason);
                if (window == null) return false;
                clip = window.animationClip;
                if (clip == null)
                {
                    reason = NoClipReason;
                    return false;
                }
                reason = null;
                return true;
            }
            catch (Exception e)
            {
                clip = null;
                reason = "Animation ウィンドウのクリップを取得できませんでした(" + e.Message + ")。";
                return false;
            }
        }

        public bool TryGetTime(out double time, out string reason)
        {
            time = 0.0;
            try
            {
                AnimationWindow window = FindWindow(out reason);
                if (window == null) return false;
                if (window.animationClip == null)
                {
                    reason = NoClipReason;
                    return false;
                }
                time = window.time;
                reason = null;
                return true;
            }
            catch (Exception e)
            {
                time = 0.0;
                reason = "Animation ウィンドウの再生ヘッドを取得できませんでした(" + e.Message + ")。";
                return false;
            }
        }

        public bool TryGetSelectedKeys(List<SelectedKeyInfo> result, out string reason)
        {
            if (result == null)
            {
                reason = "結果の入れ物がありません。";
                return false;
            }
            result.Clear();
            try
            {
                AnimationWindow window = FindWindow(out reason);
                if (window == null) return false;
                Members m = Resolve();
                if (m == null)
                {
                    InternalApiResolved(out reason);
                    return false;
                }

                object state = GetState(window, m);
                if (state == null)
                {
                    reason = "Animation ウィンドウの状態を取得できませんでした。";
                    return false;
                }


                AnimationClip windowClip = window.animationClip;
                if (m.SelectedKeys.GetValue(state) is IEnumerable keys)
                {
                    foreach (object key in keys)
                    {
                        if (key == null) continue;
                        object curve = m.KeyCurve.GetValue(key);
                        if (curve == null) continue;
                        float time = (float)m.KeyTime.GetValue(key);
                        var binding = (EditorCurveBinding)m.CurveBinding.GetValue(curve);
                        bool pptr = (bool)m.CurveIsPPtr.GetValue(curve);
                        AnimationClip clip = m.CurveClip != null ? m.CurveClip.GetValue(curve) as AnimationClip : null;
                        result.Add(new SelectedKeyInfo(clip != null ? clip : windowClip, new ClipCurveRef(binding, pptr), time));
                    }
                }
                reason = null;
                return true;
            }
            catch (Exception e)
            {
                result.Clear();
                Exception inner = e is TargetInvocationException tie && tie.InnerException != null ? tie.InnerException : e;
                reason = "選択中のキーを取得できませんでした(" + inner.GetType().Name + ": " + inner.Message + ")。";
                return false;
            }
        }

        static object GetState(AnimationWindow window, Members m)
        {
            if (m.AnimEditorField != null && m.EditorState != null)
            {
                object animEditor = m.AnimEditorField.GetValue(window);
                if (animEditor != null)
                {
                    object state = m.EditorState.GetValue(animEditor);
                    if (state != null) return state;
                }
            }
            return m.WindowState != null ? m.WindowState.GetValue(window) : null;
        }

        /// <summary>開いている Animation ウィンドウ(複数あればクリップを表示しているもの優先)。新しく開くことはしない。</summary>
        internal static AnimationWindow FindWindow(out string reason)
        {
            if (!EditorWindow.HasOpenInstances<AnimationWindow>())
            {
                reason = NotOpenReason;
                return null;
            }
            if (EditorWindow.focusedWindow is AnimationWindow focused && focused.animationClip)
            { reason = null; return focused; }
            AnimationWindow fallback = null;
            foreach (AnimationWindow w in Resources.FindObjectsOfTypeAll<AnimationWindow>())
            {
                if (w == null) continue;
                if (w.animationClip != null)
                {
                    reason = null;
                    return w;
                }
                if (fallback == null) fallback = w;
            }
            reason = fallback == null ? NotOpenReason : null;
            return fallback;
        }
    }
}
