using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ParticleLiveToolkit.Editor")]
[assembly: InternalsVisibleTo("ParticleLiveToolkit.Editor.Tests")]
