using System;
using System.Collections.Generic;
using UnityEngine;

namespace ParticleLiveToolkit
{
    /// <summary>
    /// 1 本のパーティクルライブの設定。全モジュールがこのアセットを共有して参照する。
    /// データだけを持ち、ロジックは持たない(契約: フィールドの追加は可、既存フィールドの改名・型変更は不可)。
    /// </summary>
    [CreateAssetMenu(menuName = "Particle Live/Project", fileName = "ParticleLiveProject")]
    public sealed class ParticleLiveProject : ScriptableObject
    {
        [Serializable]
        public sealed class EditorSetting
        {
            public string key;
            public string value;
        }
        [HideInInspector] public List<EditorSetting> editorSettings = new List<EditorSetting>();

        [HideInInspector] public string savedToolkitSettings = "";

        public const double DefaultBpm = 128.0;

        /// <summary>Beat Calculator に並べる「N 分」の既定値。</summary>
        public static readonly int[] DefaultNoteDivisions = { 4, 8, 16, 32, 64, 12, 24, 48 };

        [Tooltip("曲のテンポ")]
        public double bpm = DefaultBpm;

        [Tooltip("1 小節の拍数")]
        public int beatsPerBar = 4;

        [Tooltip("曲頭から 1 拍目までのずれ(秒)")]
        public double offsetSeconds = 0.0;

        [Tooltip("Beat Calculator に並べる「N 分」")]
        public int[] noteDivisions = (int[])DefaultNoteDivisions.Clone();

        [Tooltip("楽曲")]
        public AudioClip song;

        [Tooltip("演出のメイン AnimationClip")]
        public AnimationClip mainClip;

        [Tooltip("シーン内のライブルート(GlobalObjectId 文字列)。ProjectSceneUtility 経由で読み書きする")]
        public string rootGlobalId = "";

        [Tooltip("シーン内のライブルートの階層パス(rootGlobalId で見つからないときの予備)")]
        public string rootPath = "";

        [Tooltip("観客視点")]
        public List<Viewpoint> viewpoints = new List<Viewpoint>();
        public List<LiveMarker> markers = new List<LiveMarker>();
    }

    /// <summary>
    /// 観客視点。position は足元(床)の位置で、目の位置は position + 上方向 * eyeHeight。
    /// anchorPath が空でなく、ライブルートからその相対パスで Transform が見つかる場合は、
    /// position / eulerAngles の代わりにその Transform の位置・回転を使う。
    /// </summary>
    [Serializable]
    public sealed class LiveMarker
    {
        public string name = "Marker";
        public Color color = Color.yellow;
        public double time;
    }

    [Serializable]
    public sealed class Viewpoint
    {
        public string name = "Viewpoint";
        public string anchorPath = "";
        public Vector3 position = Vector3.zero;
        public Vector3 eulerAngles = Vector3.zero;
        public float eyeHeight = 1.5f;
        public float fieldOfView = 60f;
    }
}
