using System;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace ParticleLiveToolkit.Modules.ObjectEditing
{
    public sealed class MaterialModule : IToolkitModule
    {
        public string Id => "material";
        public string DisplayName => "Material Editor";
        public int Order => 52;
        readonly LiveForm<Options> form = new LiveForm<Options>();
        public void OnEnable(ToolkitContext ctx) { form.Reload(); }
        public void OnDisable() { }
        public void OnGUI(ToolkitContext ctx) => form.Draw(ctx, Id, options => options.Draw(ctx));

        [Serializable]
        sealed class Options
        {
            [SerializeField] SavedReference<Shader> filterRef = new SavedReference<Shader>();
            Shader filter { get => filterRef.Value; set => filterRef.Value = value; }
            [SerializeField] SavedReference<Material> fromRef = new SavedReference<Material>();
            Material from { get => fromRef.Value; set => fromRef.Value = value; }
            [SerializeField] SavedReference<Material> toRef = new SavedReference<Material>();
            Material to { get => toRef.Value; set => toRef.Value = value; }
            [SerializeField] Color color = Color.white;
            [SerializeField] SavedReference<Texture> textureRef = new SavedReference<Texture>();
            Texture texture { get => textureRef.Value; set => textureRef.Value = value; }
            [SerializeField] float scalar, exposure;
            [SerializeField] Vector4 vector;
            [SerializeField] int integer, index;

            public void Draw(ToolkitContext ctx)
            {
                filter = (Shader)EditorGUILayout.ObjectField("Shader で絞り込み", filter, typeof(Shader), false);
                var renderers = Selection.gameObjects.Where(g => g.scene.IsValid()).SelectMany(g => g.GetComponentsInChildren<Renderer>(true)).Distinct().ToArray();
                var materials = Selection.objects.OfType<Material>().Concat(renderers.SelectMany(r => r.sharedMaterials))
                    .Where(m => m && m.shader && (!filter || m.shader == filter) && AssetDatabase.IsOpenForEdit(m)).Distinct().ToArray();
                EditorGUILayout.LabelField("対象マテリアル", materials.Length.ToString());
                if (materials.Length > 0)
                {
                    var shader = materials[0].shader;
                    var properties = Enumerable.Range(0, shader.GetPropertyCount()).Where(i =>
                    {
                        var name = shader.GetPropertyName(i);
                        return materials.All(m => m.HasProperty(name) &&
                            m.shader.GetPropertyType(m.shader.FindPropertyIndex(name)) == shader.GetPropertyType(i));
                    }).ToArray();
                    if (properties.Length > 0)
                    {
                        index = EditorGUILayout.Popup("変更プロパティ", Mathf.Clamp(index,0,properties.Length-1),
                            properties.Select(i => shader.GetPropertyDescription(i) + "  " + shader.GetPropertyName(i)).ToArray());
                        int prop = properties[index];
                        string key = shader.GetPropertyName(prop);
                        var type = shader.GetPropertyType(prop);
                        switch (type)
                        {
                            case ShaderPropertyType.Color:
                                color = EditorGUILayout.ColorField(new GUIContent("色 (HDR)"), color, true, true, true);
                                exposure = EditorGUILayout.FloatField("HDR 強度 (EV)", exposure);
                                break;
                            case ShaderPropertyType.Texture: texture = (Texture)EditorGUILayout.ObjectField("テクスチャ",texture,typeof(Texture),false); break;
                            case ShaderPropertyType.Vector: vector = EditorGUILayout.Vector4Field("値",vector); break;
                            case ShaderPropertyType.Int: integer = EditorGUILayout.IntField("値",integer); break;
                            default: scalar = EditorGUILayout.FloatField("値",scalar); break;
                        }
                        if (GUILayout.Button("プロパティを一括変更") && Confirm(key, materials.Select(m => m.name).ToArray()))
                        {
                            Undo.RecordObjects(materials, "Material 一括編集");
                            foreach (var m in materials)
                            {
                                switch(type)
                                {
                                    case ShaderPropertyType.Color:
                                        var hdr = color * Mathf.Pow(2, exposure);
                                        hdr.a = color.a;
                                        m.SetColor(key,hdr);
                                        if (key == "_EmissionColor" && m.shader.keywordSpace.FindKeyword("_EMISSION").isValid)
                                        {
                                            if (hdr.maxColorComponent > 0) m.EnableKeyword("_EMISSION"); else m.DisableKeyword("_EMISSION");
                                            MaterialEditor.FixupEmissiveFlag(m);
                                        }
                                        break;
                                    case ShaderPropertyType.Texture: m.SetTexture(key,texture); break;
                                    case ShaderPropertyType.Vector: m.SetVector(key,vector); break;
                                    case ShaderPropertyType.Int: m.SetInteger(key,integer); break;
                                    default: m.SetFloat(key,scalar); break;
                                }
                                EditorUtility.SetDirty(m);
                            }
                        }
                    }
                }
                ToolkitGUI.Section("選択階層のマテリアル置換");
                from = (Material)EditorGUILayout.ObjectField("変更前",from,typeof(Material),false);
                to = (Material)EditorGUILayout.ObjectField("変更後",to,typeof(Material),false);
                var matches = renderers.Where(r => from && (!filter || from.shader == filter) && r.sharedMaterials.Contains(from)).ToArray();
                using (new EditorGUI.DisabledScope(!to || from == to || matches.Length == 0))
                if (GUILayout.Button($"{matches.Length} Renderer を置換") && Confirm(from.name + " → " + to.name,matches.Select(r => r.name).ToArray()))
                {
                    Undo.RecordObjects(matches,"マテリアル置換");
                    foreach (var r in matches)
                    {
                        r.sharedMaterials = r.sharedMaterials.Select(m => m == from ? to : m).ToArray();
                        PrefabUtility.RecordPrefabInstancePropertyModifications(r);
                    }
                }
            }
        }

        internal static bool Confirm(string action, string[] targets)
        {
            string list = string.Join("\n", targets.Take(12));
            if (targets.Length > 12) list += "\nほか " + (targets.Length-12) + " 件";
            return EditorUtility.DisplayDialog(action, list, "適用", "キャンセル");
        }
    }
}
