using System;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ObjectEditing
{
    public sealed class ParticleModule : IToolkitModule
    {
        public string Id => "particles";
        public string DisplayName => "Particle Editor";
        public int Order => 53;
        readonly LiveForm<Options> form = new LiveForm<Options>();
        public void OnEnable(ToolkitContext ctx) { form.Reload(); }
        public void OnDisable() { }
        public void OnGUI(ToolkitContext ctx) => form.Draw(ctx, Id, options => options.Draw(ctx));

        [Serializable]
        sealed class Options
        {
            [Flags] enum Fields { Lifetime=1, Speed=2, Size=4, Color=8, Emission=16, Burst=32, Shape=64, SimulationSpace=128, Renderer=256 }
            [SerializeField] Fields fields;
            [SerializeField] float lifetime=1, speed=1, size=1, rate=10, burstAt;
            [SerializeField] int burstCount=10, module;
            [SerializeField] Color color=Color.white;
            [SerializeField] ParticleSystemShapeType shape=ParticleSystemShapeType.Cone;
            [SerializeField] ParticleSystemSimulationSpace space;
            [SerializeField] SavedReference<Transform> customSpaceRef = new SavedReference<Transform>();
            Transform customSpace { get => customSpaceRef.Value; set => customSpaceRef.Value = value; }
            [SerializeField] ParticleSystemRenderMode renderMode;
            [SerializeField] SavedReference<Material> materialRef = new SavedReference<Material>();
            Material material { get => materialRef.Value; set => materialRef.Value = value; }
            [SerializeField] SavedReference<ParticleSystem> sourceRef = new SavedReference<ParticleSystem>();
            ParticleSystem source { get => sourceRef.Value; set => sourceRef.Value = value; }
            static readonly string[] Modules = { "InitialModule","EmissionModule","ShapeModule","VelocityModule","ClampVelocityModule",
                "InheritVelocityModule","LifetimeByEmitterSpeedModule","ForceModule","ColorModule","ColorBySpeedModule","SizeModule","SizeBySpeedModule",
                "RotationModule","RotationBySpeedModule","ExternalForcesModule","NoiseModule","CollisionModule","TriggerModule","SubModule","UVModule","LightsModule","TrailModule","CustomDataModule" };

            bool Has(Fields flag) => (fields & flag) != 0;
            public void Draw(ToolkitContext ctx)
            {
                var targets = Selection.gameObjects.Where(g => g.scene.IsValid()).SelectMany(g => g.GetComponentsInChildren<ParticleSystem>(true)).Distinct().ToArray();
                EditorGUILayout.LabelField("対象 ParticleSystem",targets.Length.ToString());
                fields = (Fields)EditorGUILayout.EnumFlagsField("変更する項目",fields);
                if (Has(Fields.Lifetime)) lifetime = Mathf.Max(0,EditorGUILayout.FloatField("Lifetime",lifetime));
                if (Has(Fields.Speed)) speed = EditorGUILayout.FloatField("Speed",speed);
                if (Has(Fields.Size)) size = Mathf.Max(0,EditorGUILayout.FloatField("Size",size));
                if (Has(Fields.Color)) color = EditorGUILayout.ColorField("Color",color);
                if (Has(Fields.Emission)) rate = Mathf.Max(0,EditorGUILayout.FloatField("Emission / 秒",rate));
                if (Has(Fields.Burst))
                {
                    burstAt = Mathf.Max(0,EditorGUILayout.FloatField("Burst 時刻（一覧を置換）",burstAt));
                    burstCount = Mathf.Clamp(EditorGUILayout.IntField("Burst 数",burstCount),0,short.MaxValue);
                }
                if (Has(Fields.Shape)) shape = (ParticleSystemShapeType)EditorGUILayout.EnumPopup("Shape",shape);
                if (Has(Fields.SimulationSpace))
                {
                    space = (ParticleSystemSimulationSpace)EditorGUILayout.EnumPopup("Simulation Space",space);
                    if (space == ParticleSystemSimulationSpace.Custom)
                        customSpace = (Transform)EditorGUILayout.ObjectField("基準",customSpace,typeof(Transform),true);
                }
                if (Has(Fields.Renderer))
                {
                    renderMode = (ParticleSystemRenderMode)EditorGUILayout.EnumPopup("Render Mode",renderMode);
                    material = (Material)EditorGUILayout.ObjectField("Material",material,typeof(Material),false);
                }
                using (new EditorGUI.DisabledScope(targets.Length == 0 || fields == 0 || (Has(Fields.SimulationSpace) && space == ParticleSystemSimulationSpace.Custom && !customSpace)))
                if (GUILayout.Button("指定項目を変更") && MaterialModule.Confirm(fields.ToString(),targets.Select(t => t.name).ToArray()))
                {
                    Undo.RegisterCompleteObjectUndo(targets,"Particle 一括編集");
                    foreach (var ps in targets)
                    {
                        var main = ps.main; var emission = ps.emission; var sh = ps.shape;
                        if (Has(Fields.Lifetime)) main.startLifetime = lifetime;
                        if (Has(Fields.Speed)) main.startSpeed = speed;
                        if (Has(Fields.Size))
                        {
                            main.startSize = size;
                            if (main.startSize3D) { main.startSizeY = size; main.startSizeZ = size; }
                        }
                        if (Has(Fields.Color)) main.startColor = color;
                        if (Has(Fields.Emission)) { emission.enabled=true; emission.rateOverTime=rate; }
                        if (Has(Fields.Burst)) { emission.enabled=true; emission.SetBursts(new[] {new ParticleSystem.Burst(burstAt,(short)burstCount)}); }
                        if (Has(Fields.Shape)) { sh.enabled=true; sh.shapeType=shape; }
                        if (Has(Fields.SimulationSpace)) { main.simulationSpace=space; if (space == ParticleSystemSimulationSpace.Custom) main.customSimulationSpace=customSpace; }
                        if (Has(Fields.Renderer) && ps.TryGetComponent(out ParticleSystemRenderer renderer))
                        {
                            Undo.RecordObject(renderer,"Particle Renderer");
                            renderer.renderMode=renderMode; renderer.sharedMaterial=material;
                            PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
                        }
                        PrefabUtility.RecordPrefabInstancePropertyModifications(ps);
                        EditorUtility.SetDirty(ps);
                    }
                }
                ToolkitGUI.Section("モジュール単位でコピー");
                source = (ParticleSystem)EditorGUILayout.ObjectField("コピー元",source,typeof(ParticleSystem),true);
                module = EditorGUILayout.Popup("モジュール",module,Modules);
                var copies = targets.Where(t => t != source).ToArray();
                using (new EditorGUI.DisabledScope(!source || copies.Length==0))
                if (GUILayout.Button("モジュールをコピー") && MaterialModule.Confirm(Modules[module],copies.Select(t => t.name).ToArray()))
                {
                    using (var src = new SerializedObject(source))
                    {
                        var property = src.FindProperty(Modules[module]);
                        if (property == null) { ctx.ShowNotification("この Unity でモジュールを取得できません"); return; }
                        foreach (var target in copies)
                        using (var dest = new SerializedObject(target))
                        {
                            dest.CopyFromSerializedProperty(property);
                            dest.ApplyModifiedProperties();
                        }
                    }
                }
            }
        }

    }
}
