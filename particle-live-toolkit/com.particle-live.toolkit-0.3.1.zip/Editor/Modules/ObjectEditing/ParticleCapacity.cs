using System;
using System.Collections.Generic;
using System.Linq;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.PathFixer;
using UnityEditor;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.Timeline;

namespace ParticleLiveToolkit.Modules.ObjectEditing
{
    internal static class ParticleCapacity
    {
        // The Bezier control polygon bounds the entire segment, including overshoot
        // between Unity keys. Unity's unweighted Hermite tangents use weight 1/3.
        internal static void Bounds(AnimationCurve curve, Action<double> add)
        {
            if (curve == null) return;
            var keys = curve.keys;
            foreach (var key in keys) add(key.value);
            for (int i = 1; i < keys.Length; i++)
            {
                var a = keys[i-1]; var b = keys[i];
                double dt = b.time - a.time;
                if (float.IsInfinity(a.outTangent) || float.IsInfinity(b.inTangent)) continue;
                add(a.value + dt * a.outTangent * ((a.weightedMode & WeightedMode.Out) != 0 ? a.outWeight : 1d/3));
                add(b.value - dt * b.inTangent * ((b.weightedMode & WeightedMode.In) != 0 ? b.inWeight : 1d/3));
            }
        }

        sealed class Inputs
        {
            internal readonly Dictionary<string, Vector2> ranges = new Dictionary<string, Vector2>();
            internal void Read(ParticleSystem ps, Transform root, AnimationClip clip)
            {
                if (!clip || !root || !ps.transform.IsChildOf(root)) return;
                string path = AnimationUtility.CalculateTransformPath(ps.transform, root);
                foreach (var b in AnimationUtility.GetCurveBindings(clip))
                {
                    if (b.type != typeof(ParticleSystem) || b.path != path) continue;
                    string key = b.propertyName;
                    var v = ranges.TryGetValue(key, out var found) ? found : new Vector2(float.PositiveInfinity, float.NegativeInfinity);
                    Bounds(AnimationUtility.GetEditorCurve(clip, b), x => { v.x = Mathf.Min(v.x, (float)x); v.y = Mathf.Max(v.y, (float)x); });
                    ranges[key] = v;
                }
            }

            internal double Max(string key, double initial) => ranges.TryGetValue(key, out var r) ? Math.Max(initial, r.y) : initial;
            internal double Min(string key, double initial) => ranges.TryGetValue(key, out var r) ? Math.Min(initial, r.x) : initial;
            internal double Peak(string name, ParticleSystem.MinMaxCurve c)
            {
                // Complex changes of curve shape/mode cannot be bounded by scalar keys alone.
                if (ranges.Keys.Any(k => k.StartsWith(name + ".", StringComparison.Ordinal) &&
                    k != name + ".scalar" && k != name + ".minScalar")) throw new InvalidOperationException("カーブ形状自体がアニメーションされています");
                double scalar = Max(name + ".scalar", c.constantMax);
                double low = Max(name + ".minScalar", c.constantMin);
                if (c.mode == ParticleSystemCurveMode.Constant) return Math.Max(0, scalar);
                if (c.mode == ParticleSystemCurveMode.TwoConstants) return Math.Max(0, Math.Max(low, scalar));
                double magnitude = 0;
                Action<double> add = v => magnitude = Math.Max(magnitude, Math.Abs(v));
                Bounds(c.curveMax, add);
                if (c.mode == ParticleSystemCurveMode.TwoCurves) Bounds(c.curveMin, add);
                double multiplier = Math.Max(Math.Abs(Max(name + ".scalar", c.curveMultiplier)), Math.Abs(Min(name + ".scalar", c.curveMultiplier)));
                return magnitude * multiplier;
            }
        }

        static IEnumerable<TrackAsset> WithChildren(TrackAsset track)
        {
            yield return track;
            foreach (var child in track.GetChildTracks())
                foreach (var sub in WithChildren(child)) yield return sub;
        }
        static Inputs Gather(ParticleSystem ps, ParticleLiveProject project)
        {
            var inputs = new Inputs();
            foreach (var a in ps.GetComponentsInParent<Animator>(true))
                if (a.runtimeAnimatorController)
                    foreach (var clip in a.runtimeAnimatorController.animationClips.Distinct()) inputs.Read(ps, a.transform, clip);
            foreach (var legacy in ps.GetComponentsInParent<Animation>(true))
                foreach (AnimationState state in legacy) inputs.Read(ps, legacy.transform, state.clip);
            var root = ProjectSceneUtility.FindRoot(project);
            if (root && project.mainClip) inputs.Read(ps, PathTrackingService.FindPathBase(root.transform, out _), project.mainClip);
            foreach (var d in UnityEngine.Object.FindObjectsOfType<PlayableDirector>(true))
            {
                if (!(d.playableAsset is TimelineAsset tl)) continue;
                foreach (var output in tl.GetOutputTracks().OfType<AnimationTrack>())
                {
                    var obj = d.GetGenericBinding(output);
                    var target = obj is Animator a ? a.transform : (obj as GameObject)?.transform;
                    if (!target || !ps.transform.IsChildOf(target)) continue;
                    foreach (var t in WithChildren(output).OfType<AnimationTrack>())
                    {
                        inputs.Read(ps, target, t.infiniteClip);
                        foreach (var c in t.GetClips()) inputs.Read(ps, target, c.animationClip);
                    }
                }
            }
            return inputs;
        }

        internal static int Estimate(ParticleSystem ps, ParticleLiveProject project)
        {
            var i = Gather(ps, project);
            var main = ps.main; var em = ps.emission;
            if (i.ranges.ContainsKey("InitialModule.maxNumParticles") || i.ranges.ContainsKey("maxNumParticles"))
                throw new InvalidOperationException("Max Particles 自体にアニメーションがあります");
            if (i.Max("ringBufferMode", (int)main.ringBufferMode) > 0) throw new InvalidOperationException("Ring Buffer が有効です");
            if (i.Peak("EmissionModule.rateOverDistance", em.rateOverDistance) > 0) throw new InvalidOperationException("距離放出には移動速度の上限が必要です");
            foreach (var emitter in UnityEngine.Object.FindObjectsOfType<ParticleSystem>(true))
                for (int j = 0; j < emitter.subEmitters.subEmittersCount; j++)
                    if (emitter.subEmitters.GetSubEmitterSystem(j) == ps) throw new InvalidOperationException("Sub Emitter の発火数は親に依存します");

            double life = i.Peak("InitialModule.startLifetime", main.startLifetime);
            var speedLife = ps.lifetimeByEmitterSpeed;
            if (i.Max("LifetimeByEmitterSpeedModule.enabled", speedLife.enabled ? 1 : 0) > 0)
                life *= Math.Max(1, i.Peak("LifetimeByEmitterSpeedModule.curve", speedLife.curve));
            bool loop = i.Max("looping", main.loop ? 1 : 0) > 0;
            double shortest = i.Min("lengthInSec", main.duration);
            double longest = i.Max("lengthInSec", main.duration);
            if (shortest <= 0) throw new InvalidOperationException("Duration の正の下限を取得できません");
            double span = loop ? life : Math.Min(life, longest);
            double total = Math.Ceiling(span * i.Peak("EmissionModule.rateOverTime", em.rateOverTime));
            int count = em.burstCount;
            if (i.ranges.Keys.Any(k => k.StartsWith("EmissionModule.m_Bursts.Array.size") ||
                k.StartsWith("EmissionModule.m_Bursts.Array.data[") && !Enumerable.Range(0,count).Any(b => k.StartsWith(BurstPath(b), StringComparison.Ordinal))))
                throw new InvalidOperationException("Burst 配列の要素数が変化します");
            for (int b = 0; b < count; b++)
            {
                var burst = em.GetBurst(b);
                string path = BurstPath(b);
                double n = i.Peak(path + "countCurve", burst.count);
                double cycles = Math.Ceiling(i.Max(path + "cycleCount", burst.cycleCount));
                bool infinite = i.Min(path + "cycleCount", burst.cycleCount) <= 0;
                double interval = i.Min(path + "repeatInterval", burst.repeatInterval);
                if (interval <= 0 && infinite) throw new InvalidOperationException("無限 Burst の間隔を取得できません");
                double within = interval > 0 ? 1 + Math.Floor(Math.Min(span, longest) / interval) : cycles;
                if (!infinite) within = Math.Min(within, cycles);
                double loops = loop ? Math.Ceiling(life / shortest) + 1 : 1;
                total += n * within * loops;
            }
            double capacity = Math.Ceiling(total * 1.25) + 8;
            if (!(capacity >= 1 && capacity <= int.MaxValue)) throw new InvalidOperationException("推定値が設定可能範囲を超えます");
            return (int)capacity;
        }
        static string BurstPath(int index) => "EmissionModule.m_Bursts.Array.data[" + index + "].";

        internal static string Apply(ParticleSystem ps, ParticleLiveProject project)
        {
            try
            {
                int capacity = Estimate(ps, project);
                var main = ps.main;
                int previous = main.maxParticles;
                if (previous != capacity)
                {
                    Undo.RegisterCompleteObjectUndo(ps, "Max Particles を設定");
                    main.maxParticles = capacity;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(ps);
                    EditorUtility.SetDirty(ps);
                }
                return ps.name + "   " + previous + " → " + main.maxParticles;
            }
            catch (InvalidOperationException e) { return ps.name + "   変更なし（" + e.Message + "）"; }
        }
    }
}
