using System;
using System.Linq;
using System.Text.RegularExpressions;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.PathFixer;
using ParticleLiveToolkit.Modules.Quick;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ObjectEditing
{
    public sealed class BatchRenameModule : IToolkitModule
    {
        public string Id => "rename";
        public string DisplayName => "Batch Rename";
        public int Order => 55;
        readonly LiveForm<Options> form = new LiveForm<Options>();
        public void OnEnable(ToolkitContext ctx) { form.Reload(); }
        public void OnDisable() { }
        public void OnGUI(ToolkitContext ctx) => form.Draw(ctx, Id, options => options.Draw(ctx));

        [Serializable]
        sealed class Options
        {
            [SerializeField] string prefix = "", suffix = "", find = "", replacement = "";
            [SerializeField] bool regex, number, repair = true;
            [SerializeField] int first = 1, digits = 2;

            public void Draw(ToolkitContext ctx)
            {
                var items = Selection.gameObjects.Where(o => o.scene.IsValid() && !EditorUtility.IsPersistent(o))
                    .OrderBy(o => ProjectSceneUtility.GetScenePath(o.transform), StringComparer.Ordinal).ThenBy(o => o.GetInstanceID()).ToArray();
                find = EditorGUILayout.TextField("検索", find);
                replacement = EditorGUILayout.TextField("置換", replacement);
                regex = EditorGUILayout.Toggle("正規表現", regex);
                prefix = EditorGUILayout.TextField("接頭辞", prefix);
                suffix = EditorGUILayout.TextField("接尾辞", suffix);
                number = EditorGUILayout.Toggle("連番", number);
                if (number)
                {
                    first = EditorGUILayout.IntField("開始番号", first);
                    digits = Mathf.Clamp(EditorGUILayout.IntField("桁数", digits), 1, 9);
                }
                repair = EditorGUILayout.Toggle("Animation パスも修正", repair);
                string[] names;
                try
                {
                    var pattern = regex && find.Length > 0 ? new Regex(find, RegexOptions.None, TimeSpan.FromMilliseconds(100)) : null;
                    names = items.Select((o,i) => prefix + (find.Length == 0 ? o.name : pattern == null ?
                        o.name.Replace(find,replacement) : pattern.Replace(o.name,replacement)) + suffix +
                        (number ? ((long)first + i).ToString("D" + digits) : "")).ToArray();
                }
                catch (Exception ex) when (ex is ArgumentException || ex is RegexMatchTimeoutException) { ToolkitGUI.Warning(ex.Message); return; }
                for (int i = 0; i < names.Length; i++) EditorGUILayout.LabelField(items[i].name, names[i]);
                var root = QuickModule.ResolveRoot(ctx);
                bool invalid = names.Any(n => string.IsNullOrWhiteSpace(n) || n.Contains("/"));
                if (repair && (!root || items.Any(o => !o.transform.IsChildOf(root)))) invalid = true;
                if (invalid) ToolkitGUI.Hint("名前と Animator の範囲を確認してください。パス修正には同じ Animator 配下の選択が必要です。");
                using (new EditorGUI.DisabledScope(invalid || !items.Where((o,i) => o.name != names[i]).Any()))
                if (GUILayout.Button("表示した名前を適用"))
                {
                    var before = repair ? HierarchySnapshot.Capture(root) : null;
                    Undo.IncrementCurrentGroup();
                    int group = Undo.GetCurrentGroup();
                    Undo.RegisterCompleteObjectUndo(items, "一括改名");
                    for (int i = 0; i < items.Length; i++)
                    {
                        items[i].name = names[i];
                        PrefabUtility.RecordPrefabInstancePropertyModifications(items[i]);
                        EditorUtility.SetDirty(items[i]);
                    }
                    if (repair && !QuickModule.Repair(root, before, ctx.ActiveProject, out string message))
                    { Undo.RevertAllDownToGroup(group); ctx.ShowNotification(message); }
                    else Undo.CollapseUndoOperations(group);
                }
            }
        }

    }
}
