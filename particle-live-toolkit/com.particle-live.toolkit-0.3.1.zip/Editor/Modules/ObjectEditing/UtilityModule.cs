using System;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ObjectEditing
{
    public sealed class UtilityModule : IToolkitModule
    {
        public string Id => "utilities";
        public string DisplayName => "便利ツール";
        public int Order => 2;
        internal enum Preset { Floor, Standard, Trail, Burst, Snow }
        static readonly string[] labels = { "透明な床（Collider）", "マテリアル付き Particle", "マテリアル付き Trail Particle", "Burst 100", "広範囲に降る雪" };
        string result;
        ParticleLiveProject shown;
        public void OnEnable(ToolkitContext ctx) { result = null; }
        public void OnDisable() { }
        public void OnGUI(ToolkitContext ctx)
        {
            var p = ctx.ActiveProject;
            if (p != shown) { result = null; shown = p; }
            var root = ProjectSceneUtility.FindRoot(p);
            var selected = Selection.activeTransform;
            var parent = selected && selected.gameObject.scene.IsValid() && (!p || root && selected.IsChildOf(root.transform))
                ? selected : root ? root.transform.Find("Animation/Effects") ?? root.transform.Find("Animation") ?? root.transform : null;
            using (new EditorGUI.DisabledScope(EditorApplication.isPlayingOrWillChangePlaymode || p && !root))
            {
                for (int i = 0; i < labels.Length; i++) if (GUILayout.Button(labels[i])) Create((Preset)i, parent);
            }
            if (p && !root) ToolkitGUI.Hint("「ライブの編集」から対象シーンを開いてください。");
            ToolkitGUI.Section("Max Particles");
            var targets = Selection.gameObjects.Where(go => go.scene.IsValid()).SelectMany(go => go.GetComponentsInChildren<ParticleSystem>(true)).Distinct().ToArray();
            EditorGUILayout.LabelField("選択階層の ParticleSystem", targets.Length.ToString());
            using (new EditorGUI.DisabledScope(targets.Length == 0 || EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()))
                if (GUILayout.Button("必要数を計算して適用"))
                {
                    Undo.IncrementCurrentGroup();
                    int group = Undo.GetCurrentGroup();
                    result = string.Join("\n", targets.Select(ps => ParticleCapacity.Apply(ps, p)));
                    Undo.CollapseUndoOperations(group);
                }
            if (AnimationMode.InAnimationMode()) ToolkitGUI.Hint("適用するにはアニメーションのプレビューを終了してください。");
            if (!string.IsNullOrEmpty(result)) EditorGUILayout.HelpBox(result, MessageType.Info);
        }

        internal static GameObject Create(Preset preset, Transform parent)
        {
            string[] names = { "Collider Floor", "Particle", "Trail Particle", "Burst 100", "Snow" };
            var go = new GameObject(names[(int)preset]);
            if (parent) go.transform.SetParent(parent, false);
            GameObjectUtility.EnsureUniqueNameForSibling(go);
            if (preset == Preset.Floor)
            {
                var collider = go.AddComponent<BoxCollider>();
                collider.size = new Vector3(10, 0.1f, 10);
                collider.center = Vector3.down * 0.05f;
            }
            else
            {
                var ps = go.AddComponent<ParticleSystem>();
                var renderer = go.GetComponent<ParticleSystemRenderer>();
                var material = renderer.sharedMaterial ? renderer.sharedMaterial :
                    AssetDatabase.GetBuiltinExtraResource<Material>("Default-ParticleSystem.mat");
                renderer.sharedMaterial = material;
                if (preset == Preset.Trail)
                {
                    var trails = ps.trails; trails.enabled = true;
                    renderer.trailMaterial = material;
                }
                if (preset == Preset.Burst)
                {
                    var emission = ps.emission; emission.rateOverTime = 0;
                    emission.SetBursts(new[] { new ParticleSystem.Burst(0, (short)100) });
                }
                if (preset == Preset.Snow)
                {
                    var main = ps.main;
                    main.startSpeed = 0;
                    main.startSize = new ParticleSystem.MinMaxCurve(0.05f, 0.12f);
                    main.startLifetime = 6;
                    main.gravityModifier = 0.12f;
                    var shape = ps.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Box;
                    shape.scale = new Vector3(20, 0.1f, 20);
                    shape.position = Vector3.up * 8;
                    var emission = ps.emission; emission.rateOverTime = 25;
                }
            }
            Undo.RegisterCreatedObjectUndo(go, names[(int)preset] + " を追加");
            Selection.activeGameObject = go;
            return go;
        }
    }
}
