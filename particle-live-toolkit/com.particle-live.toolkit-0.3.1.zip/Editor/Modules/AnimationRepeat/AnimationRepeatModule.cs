using System;
using System.Collections.Generic;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// ④ Animation Editor(範囲リピート複製)。入力と描画だけを持ち、計算は RangeRepeater、
    /// 入力の保存と Animation ウィンドウとのやり取りは AnimationRepeatController に任せる。
    /// </summary>
    public sealed class AnimationRepeatModule : IToolkitModule
    {
        static readonly string[] CurveModeLabels = { "すべてのカーブ", "選んだカーブだけ" };

        static readonly string[] PolicyLabels =
        {
            "複製先の範囲を消してから貼る",
            "既存のキーを残して空いている所だけ貼る",
            "中止(複製先にキーがあれば実行しない)",
        };

        static readonly string[] PolicyDescriptions =
        {
            "コピーごとに、貼り付け先の範囲にある既存のキーを消してから貼ります。",
            "キー単位で判断します: 同じ時刻に既存のキーがある所だけ貼らず、それ以外は貼ります(既存のキーは消しません)。",
            "貼り付け先の範囲に既存のキーが 1 つでもあれば、何も変更せずに中止します。",
        };

        const string IntervalInputWarning = "間隔には 0 〜 100000 秒になる値を入れてください(入力した値は使いません)。";

        const float WindowButtonWidth = 150f;
        const float CurveListHeight = 180f;

        string _rangeInputWarning;
        string _intervalInputWarning;

        AnimationRepeatController _controller;
        ToolkitContext _ctx;
        bool _undoHooked;
        Vector2 _curveScroll;

        // 対象カーブ一覧の表示用キャッシュ(毎フレーム AnimationUtility を呼ばない)
        AnimationClip _curvesClip;
        int _curvesDirty = -1;
        List<ClipCurveRef> _curves = new List<ClipCurveRef>();
        List<string> _curveLabels = new List<string>();
        HashSet<string> _curveKeys = new HashSet<string>(StringComparer.Ordinal);
        List<string> _curveKeyList = new List<string>();
        List<string> _curveRotationGroups = new List<string>(); // 回転カーブなら組のキー、それ以外は null
        bool _hasRotationCurves;

        public string Id
        {
            get { return ToolkitModuleIds.AnimationRepeat; }
        }

        public string DisplayName
        {
            get { return "Animation"; }
        }

        public int Order
        {
            get { return ToolkitModuleIds.AnimationRepeatOrder; }
        }

        public void OnEnable(ToolkitContext ctx)
        {
            Init(ctx);
            if (!_undoHooked)
            {
                Undo.undoRedoPerformed += OnUndoRedo;
                _undoHooked = true;
            }
        }

        public void OnDisable()
        {
            if (_undoHooked)
            {
                Undo.undoRedoPerformed -= OnUndoRedo;
                _undoHooked = false;
            }
        }

        void Init(ToolkitContext ctx)
        {
            _ctx = ctx;
            if (_controller == null && ctx != null) _controller = new AnimationRepeatController(ctx.State(Id), new AnimationWindowBridge());
        }

        void OnUndoRedo()
        {
            _controller?.InvalidatePreview();
            _curvesDirty = -1;
            _ctx?.Repaint();
        }

        public void OnGUI(ToolkitContext ctx)
        {
            Init(ctx);
            if (_controller == null) return;

            AnimationClip clip = DrawClipSection(ctx);
            DrawRangeSection(ctx);
            DrawIntervalSection(ctx);
            DrawTargetSection(clip);
            DrawOptionSection(clip);
            DrawPreviewSection(ctx, clip);
        }

        // ---------- クリップ ----------

        AnimationClip DrawClipSection(ToolkitContext ctx)
        {
            ToolkitGUI.Section("クリップ");
            AnimationClip clip = _controller.ResolveClip(ctx);
            bool windowOk = _controller.Bridge.IsWindowAvailable(out string windowReason);

            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUI.BeginChangeCheck();
                var picked = (AnimationClip)EditorGUILayout.ObjectField("クリップ", clip, typeof(AnimationClip), false);
                if (EditorGUI.EndChangeCheck())
                {
                    _controller.ExplicitClip = picked;
                    clip = _controller.ResolveClip(ctx);
                }
                using (new EditorGUI.DisabledScope(!windowOk))
                {
                    if (GUILayout.Button("Animation ウィンドウから取得", GUILayout.Width(WindowButtonWidth)))
                    {
                        _controller.TakeWindowClip(out string message);
                        ctx.ShowNotification(message);
                        clip = _controller.ResolveClip(ctx);
                    }
                }
            }
            if (!windowOk) ReasonLabel(windowReason);

            ParticleLiveProject project = ctx.ActiveProject;
            AnimationClip mainClip = project != null ? project.mainClip : null;
            if (_controller.ExplicitClip == null && mainClip != null)
            {
                EditorGUILayout.LabelField("ライブの mainClip を使っています。", EditorStyles.miniLabel);
            }
            else if (mainClip != null && _controller.ExplicitClip != mainClip)
            {
                if (GUILayout.Button("ライブの mainClip に戻す", GUILayout.ExpandWidth(false)))
                {
                    _controller.ExplicitClip = null;
                    clip = _controller.ResolveClip(ctx);
                }
            }

            if (clip == null)
            {
                ToolkitGUI.Hint("複製するクリップを指定してください(上部バーでライブを選ぶと、その mainClip が入ります)。");
            }
            else if (!ClipEditUtility.IsEditable(clip, out string notEditable))
            {
                ToolkitGUI.Warning(notEditable);
            }
            return clip;
        }

        // ---------- 範囲 ----------

        void DrawRangeSection(ToolkitContext ctx)
        {
            ToolkitGUI.Section("範囲");
            bool canSelect = _controller.Bridge.CanGetSelectedKeys(out string selectReason);
            bool windowOk = _controller.Bridge.IsWindowAvailable(out string windowReason);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(!canSelect))
                {
                    if (GUILayout.Button("選択中のキーから取得"))
                    {
                        _controller.ImportSelection(out string message);
                        ctx.ShowNotification(message);
                        GUI.FocusControl(null); // 数値欄の編集中の値で上書きされないように
                    }
                }
                using (new EditorGUI.DisabledScope(!windowOk))
                {
                    if (GUILayout.Button("再生ヘッドを開始へ"))
                    {
                        _controller.SetStartFromPlayhead(out string message);
                        ctx.ShowNotification(message);
                        GUI.FocusControl(null);
                    }
                    if (GUILayout.Button("再生ヘッドを終了へ"))
                    {
                        _controller.SetEndFromPlayhead(out string message);
                        ctx.ShowNotification(message);
                        GUI.FocusControl(null);
                    }
                }
            }
            if (!canSelect) ReasonLabel(selectReason);
            else if (!windowOk) ReasonLabel(windowReason);

            EditorGUI.BeginChangeCheck();
            double start = EditorGUILayout.DoubleField("開始(秒)", _controller.StartSeconds);
            if (EditorGUI.EndChangeCheck()) AcceptSeconds(start, "開始(秒)", v => _controller.StartSeconds = v);

            EditorGUI.BeginChangeCheck();
            double end = EditorGUILayout.DoubleField("終了(秒)", _controller.EndSeconds);
            if (EditorGUI.EndChangeCheck()) AcceptSeconds(end, "終了(秒)", v => _controller.EndSeconds = v);
            if (_rangeInputWarning != null) ToolkitGUI.Warning(_rangeInputWarning);

            EditorGUI.BeginChangeCheck();
            bool includeEnd = EditorGUILayout.Toggle("終了時刻ちょうどのキーも含める", _controller.IncludeEndKey);
            if (EditorGUI.EndChangeCheck()) _controller.IncludeEndKey = includeEnd;

            double length = _controller.EndSeconds - _controller.StartSeconds;
            if (length > 0.0)
            {
                EditorGUILayout.LabelField("範囲の長さ: " + SecondsText.Format(length) + " 秒(" + SecondsText.Format(length / BeatMath.BeatSeconds(ctx.Bpm), 3) + " 拍)",
                    EditorStyles.miniLabel);
            }
        }

        void AcceptSeconds(double value, string label, Action<double> store)
        {
            if (AnimationRepeatController.IsStorableSeconds(value))
            {
                store(value);
                _rangeInputWarning = null;
            }
            else
            {
                _rangeInputWarning = label + "には -100000 〜 100000 の数値を入れてください(入力した値は使いません)。";
            }
        }

        // ---------- 間隔と回数 ----------

        void DrawIntervalSection(ToolkitContext ctx)
        {
            if (ctx.HasProject && _controller.ResolveClip(ctx) == ctx.ActiveProject.mainClip)
            {
                ParticleLiveToolkit.Modules.Music.MarkerModule.Pick("開始マーカー", ctx.ActiveProject, t => _controller.StartSeconds = t);
                ParticleLiveToolkit.Modules.Music.MarkerModule.Pick("終了マーカー", ctx.ActiveProject, t => _controller.EndSeconds = t);
            }
            ParticleLiveToolkit.Modules.Music.BeatSnapModule.DrawMove(ctx);
            ToolkitGUI.Section("間隔と回数");
            BeatInterval interval = _controller.Interval;
            BeatInterval next = interval;
            try
            {
                next = BeatIntervalGUI.Field("間隔", interval, ctx);
            }
            catch (Exception e) when (!(e is ExitGUIException))
            {
                // Core の入力欄は換算結果の表示で、極端な値(decimal に入らない秒数)だと例外を投げる。
                // 値は保存せず(この呼び出しは値を返さない)、理由を表示してタブを使える状態に保つ
                _intervalInputWarning = IntervalInputWarning;
            }
            if (!next.Equals(interval))
            {
                if (AnimationRepeatController.IsStorableInterval(next) && AnimationRepeatController.IsStorableSeconds(next.ToSeconds(ctx.Bpm)))
                {
                    _controller.Interval = next;
                    _intervalInputWarning = null;
                }
                else
                {
                    _intervalInputWarning = IntervalInputWarning;
                }
            }
            if (_intervalInputWarning != null) ToolkitGUI.Warning(_intervalInputWarning);

            EditorGUI.BeginChangeCheck();
            int count = EditorGUILayout.IntField("回数", _controller.Count);
            if (EditorGUI.EndChangeCheck()) _controller.Count = Mathf.Clamp(count, 1, RangeRepeater.MaxCount);
            EditorGUILayout.LabelField("コピー k 個目 = 元の時刻 + k × 間隔(k = 1 〜 回数)。回数は 1 〜 " + RangeRepeater.MaxCount + "。",
                EditorStyles.miniLabel);
        }

        // ---------- 対象カーブ ----------

        void DrawTargetSection(AnimationClip clip)
        {
            ToolkitGUI.Section("対象カーブ");
            int mode = GUILayout.Toolbar(_controller.UseAllCurves ? 0 : 1, CurveModeLabels);
            if (mode != (_controller.UseAllCurves ? 0 : 1)) _controller.UseAllCurves = mode == 0;
            if (_controller.UseAllCurves)
            {
                EditorGUILayout.LabelField("範囲内にキーがあるカーブがすべて対象になります。", EditorStyles.miniLabel);
                return;
            }
            if (clip == null) return;

            RefreshCurveList(clip);
            IReadOnlyCollection<string> selected = _controller.SelectedCurveKeys; // 保存文字列が変わったときだけ作り直されるキャッシュ
            int missing = 0;
            foreach (string k in selected)
                if (!_curveKeys.Contains(k)) missing++;

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("すべて選択", GUILayout.ExpandWidth(false))) _controller.SelectedCurves = _curves.ToList();
                if (GUILayout.Button("すべて解除", GUILayout.ExpandWidth(false))) _controller.SelectedCurves = Array.Empty<ClipCurveRef>();
                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField(selected.Count - missing + " / " + _curves.Count + " 本", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
            }

            if (_curves.Count == 0)
            {
                ToolkitGUI.Hint("このクリップにはカーブがありません。");
                return;
            }

            int toggled = -1;
            bool toggledOn = false;
            using (var scroll = new EditorGUILayout.ScrollViewScope(_curveScroll, GUILayout.MaxHeight(CurveListHeight)))
            {
                _curveScroll = scroll.scrollPosition;
                for (int i = 0; i < _curves.Count; i++)
                {
                    bool on = selected.Contains(_curveKeyList[i]);
                    bool next = EditorGUILayout.ToggleLeft(_curveLabels[i], on);
                    if (next == on || toggled >= 0) continue;
                    toggled = i;
                    toggledOn = next;
                }
            }
            if (toggled >= 0)
            {
                // 回転は成分の一部だけを選べないよう、同じパスの回転カーブをまとめて切り替える
                var nextSelected = new HashSet<string>(selected, StringComparer.Ordinal);
                string group = _curveRotationGroups[toggled];
                for (int i = 0; i < _curves.Count; i++)
                {
                    bool member = i == toggled || (group != null && _curveRotationGroups[i] == group);
                    if (!member) continue;
                    if (toggledOn) nextSelected.Add(_curveKeyList[i]);
                    else nextSelected.Remove(_curveKeyList[i]);
                }
                // クリップの並び順で保存し、クリップに無いカーブ(別クリップで選んだもの)は外す
                var list = new List<ClipCurveRef>();
                for (int i = 0; i < _curves.Count; i++)
                    if (nextSelected.Contains(_curveKeyList[i])) list.Add(_curves[i]);
                _controller.SelectedCurves = list;
            }
            else if (missing > 0)
            {
                EditorGUILayout.LabelField("選んだカーブのうち " + missing + " 本はこのクリップにありません(対象になりません)。", EditorStyles.wordWrappedMiniLabel);
            }
            if (_hasRotationCurves)
                EditorGUILayout.LabelField("回転のカーブは成分(x / y / z / w)をまとめて選択・解除します。", EditorStyles.wordWrappedMiniLabel);
        }

        void RefreshCurveList(AnimationClip clip)
        {
            int dirty = EditorUtility.GetDirtyCount(clip);
            if (clip == _curvesClip && dirty == _curvesDirty) return;
            _curvesClip = clip;
            _curvesDirty = dirty;
            _curves = ClipEditUtility.GetAllCurves(clip).ToList();
            _curveLabels = _curves.Select(CurveLabel).ToList();
            _curveKeyList = _curves.Select(CurveRefKey.Of).ToList();
            _curveKeys = new HashSet<string>(_curveKeyList, StringComparer.Ordinal);
            _curveRotationGroups = _curves.Select(c => RotationCurves.IsRotation(c) ? RotationCurves.GroupKey(c) : null).ToList();
            _hasRotationCurves = _curveRotationGroups.Any(g => g != null);
        }

        static string CurveLabel(ClipCurveRef c)
        {
            EditorCurveBinding b = c.Binding;
            string path = string.IsNullOrEmpty(b.path) ? "(ルート)" : b.path;
            string type = b.type != null ? b.type.Name : "?";
            return path + " : " + type + "." + b.propertyName + (c.IsObjectReference ? "(参照)" : "");
        }

        // ---------- オプション ----------

        void DrawOptionSection(AnimationClip clip)
        {
            ToolkitGUI.Section("オプション");
            EditorGUI.BeginChangeCheck();
            int policy = EditorGUILayout.Popup("複製先にキーがあるとき", (int)_controller.Policy, PolicyLabels);
            if (EditorGUI.EndChangeCheck()) _controller.Policy = (RepeatConflictPolicy)policy;
            EditorGUILayout.LabelField(PolicyDescriptions[(int)_controller.Policy], EditorStyles.wordWrappedMiniLabel);

            EditorGUI.BeginChangeCheck();
            string snapLabel = "フレームに合わせる" + (clip != null ? "(" + clip.frameRate.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + " fps)" : "");
            bool snap = EditorGUILayout.Toggle(snapLabel, _controller.SnapToFrames);
            if (EditorGUI.EndChangeCheck()) _controller.SnapToFrames = snap;
            if (!_controller.SnapToFrames)
            {
                EditorGUILayout.LabelField("キーの時刻はフレームに丸めません(BPM から計算した時刻をそのまま使います)。", EditorStyles.wordWrappedMiniLabel);
            }
        }

        // ---------- プレビューと実行 ----------

        void DrawPreviewSection(ToolkitContext ctx, AnimationClip clip)
        {
            ToolkitGUI.Section("プレビュー");
            RepeatPreview p = _controller.GetPreview(clip, ctx.Bpm);

            if (p.TargetCurveCount > 0)
            {
                EditorGUILayout.LabelField("対象カーブ", p.TargetCurveCount + " 本(範囲内のキー " + p.SourceKeyCount + " 個)");
                EditorGUILayout.LabelField("追加されるキー", p.AddedKeyCount + " 個");
                EditorGUILayout.LabelField("消えるキー", p.RemovedKeyCount + " 個");
                EditorGUILayout.LabelField("クリップの長さ", SecondsText.Format(p.OriginalLength, 3) + " 秒 → " + SecondsText.Format(p.ResultLength, 3) + " 秒");

                if (p.HasSeamOverlap)
                {
                    ToolkitGUI.Warning("終了時刻のキーと次のコピーの先頭キーが同じ時刻に重なります。後から貼る先頭キーを優先します"
                        + (p.SeamReplacedKeyCount > 0 ? "(元の終了時刻のキー " + p.SeamReplacedKeyCount + " 個が消えます)" : "") + "。");
                }
                if (p.SkippedKeyCount > 0) ToolkitGUI.Hint("既存のキーと同じ時刻の " + p.SkippedKeyCount + " 個は貼りません。");
                if (p.SnapMergedKeyCount > 0) ToolkitGUI.Hint("フレームに合わせると同じフレームに重なるキー " + p.SnapMergedKeyCount + " 個は、後のキーだけを貼ります。");
            }
            if (p.MissingTargetCurveCount > 0) ToolkitGUI.Hint("選んだカーブのうち " + p.MissingTargetCurveCount + " 本はこのクリップにありません。");
            if (p.RotationAddedCurveCount > 0) ToolkitGUI.Hint("回転は成分をまとめて複製するため、回転のカーブ " + p.RotationAddedCurveCount + " 本を対象に加えました。");

            string disabledReason = p.Reason;
            if (disabledReason == null && p.AddedKeyCount == 0 && p.RemovedKeyCount == 0) disabledReason = "この設定では変わるキーがありません。";
            if (ToolkitGUI.PrimaryButton("複製を実行", disabledReason))
            {
                RepeatPreview result = _controller.Apply(clip, ctx.Bpm);
                if (result.CanExecute)
                {
                    ctx.ShowNotification(result.AddedKeyCount + " 個のキーを複製しました"
                        + (result.RemovedKeyCount > 0 ? "(消えたキー " + result.RemovedKeyCount + " 個)" : "") + "。Undo で元に戻せます。");
                }
                else
                {
                    ctx.ShowNotification(result.Reason);
                }
                _curvesDirty = -1;
            }
        }

        static void ReasonLabel(string reason)
        {
            if (!string.IsNullOrEmpty(reason)) EditorGUILayout.LabelField(reason, EditorStyles.wordWrappedMiniLabel);
        }
    }
}
