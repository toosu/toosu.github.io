using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>「選択中のキーから取得」の結果。</summary>
    public sealed class SelectionImportResult
    {
        /// <summary>取得できない理由(日本語)。取得できたら null。</summary>
        public string Reason { get; internal set; }

        public bool Success
        {
            get { return Reason == null; }
        }

        /// <summary>選択キーのクリップ。</summary>
        public AnimationClip Clip { get; internal set; }

        /// <summary>選択キーのうち最も早い時刻。</summary>
        public double StartSeconds { get; internal set; }

        /// <summary>選択キーのうち最も遅い時刻。</summary>
        public double EndSeconds { get; internal set; }

        /// <summary>常に true(選択キーから取得したときは終了時刻のキーも含める)。</summary>
        public bool IncludeEndKey { get; internal set; }

        /// <summary>選択キーがあるカーブ(クリップに実在するものだけ。重複なし、選択順)。</summary>
        public IReadOnlyList<ClipCurveRef> Curves { get; internal set; }

        public int KeyCount { get; internal set; }

        /// <summary>クリップに見つからなかったため除いたカーブ数。</summary>
        public int DroppedCurveCount { get; internal set; }

        /// <summary>
        /// 回転は成分をまとめて複製するため、選択に加えて対象にした回転カーブの数
        /// (一部の成分だけが選択されていた場合や、Animation ウィンドウの表示用の別名で返された場合)。
        /// </summary>
        public int RotationAddedCount { get; internal set; }
    }

    /// <summary>Animation ウィンドウの選択キーから、クリップ・範囲・対象カーブを決める(純粋関数)。</summary>
    public static class SelectionImport
    {
        public static SelectionImportResult FromBridge(IAnimationWindowBridge bridge)
        {
            if (bridge == null) return Fail("Animation ウィンドウとの連携が使えません。");
            var keys = new List<SelectedKeyInfo>();
            if (!bridge.TryGetSelectedKeys(keys, out string reason))
                return Fail(string.IsNullOrEmpty(reason) ? "選択中のキーを取得できませんでした。" : reason);
            return FromKeys(keys);
        }

        public static SelectionImportResult FromKeys(IReadOnlyList<SelectedKeyInfo> keys)
        {
            if (keys == null || keys.Count == 0) return Fail("Animation ウィンドウでキーが選択されていません。複製したい範囲のキーを選択してください。");

            AnimationClip clip = null;
            foreach (SelectedKeyInfo k in keys)
            {
                if (k.Clip == null) return Fail("選択中のキーのクリップが分かりません。");
                if (clip == null) clip = k.Clip;
                else if (clip != k.Clip) return Fail("複数のクリップのキーが選択されています。1 つのクリップのキーだけを選択してください。");
            }

            double start = double.PositiveInfinity, end = double.NegativeInfinity;
            var selectedCurves = new List<ClipCurveRef>(keys.Count);
            foreach (SelectedKeyInfo k in keys)
            {
                start = Math.Min(start, k.Time);
                end = Math.Max(end, k.Time);
                selectedCurves.Add(k.Curve);
            }
            // パス・型・プロパティ名でクリップのカーブに突き合わせる。回転は成分をまとめ、表示用の別名もクリップの回転カーブに対応付ける
            List<ClipCurveRef> curves = RotationCurves.Resolve(selectedCurves, ClipEditUtility.GetAllCurves(clip), out int dropped, out int rotationAdded);

            if (curves.Count == 0) return Fail("選択中のキーのカーブがクリップに見つかりません。");
            if (!(end - start > CurveKeyUtility.TimeEpsilon))
                return Fail("選択中のキーがすべて同じ時刻です。範囲にするには、時刻の違う 2 つ以上のキーを選択してください。");

            return new SelectionImportResult
            {
                Clip = clip,
                StartSeconds = start,
                EndSeconds = end,
                IncludeEndKey = true,
                Curves = curves,
                KeyCount = keys.Count,
                DroppedCurveCount = dropped,
                RotationAddedCount = rotationAdded,
            };
        }

        static SelectionImportResult Fail(string reason)
        {
            return new SelectionImportResult { Reason = reason, Curves = Array.Empty<ClipCurveRef>() };
        }
    }
}
