using System;
using System.Collections.Generic;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// 範囲リピート複製の計画と適用(UI なし)。Preview と Apply は同じ計算(Plan)を通り、
    /// Apply は Plan が作った ClipEditSession を Commit するだけ。したがってプレビューの件数と適用結果は必ず一致する。
    ///
    /// 規則:
    ///  - 範囲は半開区間 [開始, 終了)。IncludeEndKey なら終了時刻ちょうどのキーも含む(CurveKeyUtility と同じ許容誤差)。
    ///  - コピー k 個目(k = 1..回数)のキー時刻 = 元の時刻 + k × 間隔(double で計算してから float。CurveKeyUtility.CopyRange の offset に k × 間隔を渡す)。
    ///  - 範囲内にキーがあるカーブだけが対象(範囲内にキーが無いカーブは、複製先の範囲にキーがあっても触らない)。
    ///  - 元の範囲のキーとコピー同士は「後から貼る方が勝つ」。元の範囲のキーが消えるのは、
    ///    終了時刻のキーが次のコピーの先頭キーと同じ時刻になる場合(終了キーを含める かつ 間隔 = 範囲の長さ)だけ。
    ///  - 衝突ポリシーは「既存キー」= 元の範囲の外にあった実行前のキーにだけ適用する。
    ///  - AnimationEvent は触らない。
    /// </summary>
    public static class RangeRepeater
    {
        public const int MaxCount = 1000;
        public const string UndoName = "範囲リピート複製";

        /// <summary>開始・終了・間隔・最後のコピーの時刻として受け付ける絶対値の上限(秒)。</summary>
        public const double MaxSeconds = 100000.0;

        const double Eps = CurveKeyUtility.TimeEpsilon;

        /// <summary>適用したときに起きることを計算する。クリップは一切変更しない。</summary>
        public static RepeatPreview Preview(RepeatRequest request)
        {
            return Plan(request, out _);
        }

        /// <summary>
        /// Preview と同じ計算をして、実行できるならクリップへ書き込む(バックアップ + Undo 1 回)。
        /// 実行できない場合は何もせず、Reason 付きの結果を返す。
        /// </summary>
        public static RepeatPreview Apply(RepeatRequest request)
        {
            RepeatPreview preview = Plan(request, out ClipEditSession session);
            if (preview.CanExecute && session != null) session.Commit(UndoName);
            return preview;
        }

        // ------------------------------------------------------------------
        // 計画
        // ------------------------------------------------------------------

        static RepeatPreview Plan(RepeatRequest r, out ClipEditSession session)
        {
            session = null;
            string reason = ValidateInputs(r);
            if (reason != null) return RepeatPreview.Fail(reason);

            var settings = new Settings(r);
            var s = new ClipEditSession(r.Clip);
            var preview = new RepeatPreview { OriginalLength = r.Clip.length };

            int missing = 0, rotationAdded = 0;
            List<ClipCurveRef> targets = r.CapturedSource
                ? r.TargetCurves.Where(s.Curves.Contains).Distinct().ToList()
                : ResolveTargets(s.Curves, r.TargetCurves, out missing, out rotationAdded);
            preview.MissingTargetCurveCount = missing;
            preview.RotationAddedCurveCount = rotationAdded;
            if (targets.Count == 0)
            {
                if (r.TargetCurves == null) return RepeatPreview.Fail("クリップにキーがありません。");
                return RepeatPreview.Fail(r.TargetCurves.Count == 0
                    ? "対象のカーブが選ばれていません。"
                    : "選んだカーブがクリップにありません。");
            }

            var floatAccess = new FloatKeyAccess();
            var objectAccess = new ObjectKeyAccess();
            var planned = new HashSet<ClipCurveRef>();
            float lastFloat = float.NegativeInfinity;
            float lastObject = float.NegativeInfinity;

            foreach (ClipCurveRef target in targets)
            {
                if (target.IsObjectReference)
                {
                    ObjectReferenceKeyframe[] keys = s.GetObjectCurve(target.Binding) ?? Array.Empty<ObjectReferenceKeyframe>();
                    var captured = r.CapturedSource ? AnimationUtility.GetObjectReferenceCurve(r.CapturedSource, target.Binding) : null;
                    var result = CurvePlanner<ObjectReferenceKeyframe>.Run(keys, objectAccess, settings, captured);
                    if (!result.Participates) continue;
                    Accumulate(preview, result);
                    planned.Add(target);
                    lastObject = Math.Max(lastObject, LastTime(result.Keys, objectAccess));
                    if (result.Changed) s.SetObjectCurve(target.Binding, result.Keys);
                }
                else
                {
                    AnimationCurve curve = s.GetFloatCurve(target.Binding);
                    if (curve == null) continue;
                    var captured = r.CapturedSource ? AnimationUtility.GetEditorCurve(r.CapturedSource, target.Binding)?.keys : null;
                    var result = CurvePlanner<Keyframe>.Run(curve.keys, floatAccess, settings, captured);
                    if (!result.Participates) continue;
                    Accumulate(preview, result);
                    planned.Add(target);
                    lastFloat = Math.Max(lastFloat, LastTime(result.Keys, floatAccess));
                    if (result.Changed)
                    {
                        // 作業用コピーにキーを一括代入する(接線は再計算されない。ラップモードなどカーブの設定は保たれる)
                        curve.keys = result.Keys;
                        s.SetFloatCurve(target.Binding, curve);
                    }
                }
            }

            if (preview.TargetCurveCount == 0)
            {
                return RepeatPreview.Fail("範囲内にキーがありません(" + SecondsText.Format(r.StartSeconds) + " 〜 "
                    + SecondsText.Format(r.EndSeconds) + " 秒" + (r.IncludeEndKey ? "、終了時刻を含む" : "") + ")。");
            }

            // 複製後のクリップ長(Unity の実測: float カーブは最後のキー、ObjectReference カーブは最後のキーの 1 フレーム後。開始は 0)
            foreach (ClipCurveRef c in s.Curves)
            {
                if (planned.Contains(c)) continue;
                if (c.IsObjectReference) lastObject = Math.Max(lastObject, LastTime(s.GetObjectCurve(c.Binding), objectAccess));
                else lastFloat = Math.Max(lastFloat, LastTime(s.GetFloatCurve(c.Binding)?.keys, floatAccess));
            }
            float stop = lastFloat;
            if (!float.IsNegativeInfinity(lastObject) && r.Clip.frameRate > 0f) stop = Math.Max(stop, lastObject + 1f / r.Clip.frameRate);
            preview.ResultLength = Math.Max(0f, float.IsNegativeInfinity(stop) ? 0f : stop);

            if (r.Policy == RepeatConflictPolicy.Abort && preview.ConflictingKeyCount > 0)
            {
                preview.Reason = "複製先に既存のキーが " + preview.ConflictingKeyCount + " 個あります。衝突時の動作が「中止」のため実行しません。";
                return preview;
            }

            session = s;
            return preview;
        }

        static string ValidateInputs(RepeatRequest r)
        {
            if (r == null || r.Clip == null) return "クリップを指定してください。";
            if (!ClipEditUtility.IsEditable(r.Clip, out string notEditable)) return notEditable;
            if (!IsFinite(r.StartSeconds) || !IsFinite(r.EndSeconds)) return "開始と終了には数値を入れてください。";
            if (Math.Abs(r.StartSeconds) > MaxSeconds || Math.Abs(r.EndSeconds) > MaxSeconds)
                return "開始と終了は -100000 〜 100000 秒の範囲で入れてください。";
            if (r.EndSeconds < r.StartSeconds || (r.EndSeconds == r.StartSeconds && !r.CapturedSource)) return "終了は開始より後の時刻にしてください。";
            if (!(r.IntervalSeconds > 0.0) || double.IsInfinity(r.IntervalSeconds)) return "間隔は 0 より大きい値にしてください。";
            if (r.IntervalSeconds > MaxSeconds) return "間隔は 100000 秒以下にしてください。";
            if (r.Count < 1 || r.Count > MaxCount) return "回数は 1 〜 " + MaxCount + " にしてください。";
            if (r.EndSeconds + r.PreviousOffset + r.Count * r.IntervalSeconds > MaxSeconds)
                return "最後のコピーが 100000 秒を超えます。回数か間隔を減らしてください。";
            double length = r.EndSeconds - r.StartSeconds;
            if (r.IntervalSeconds < length - Eps)
            {
                return "間隔(" + SecondsText.Format(r.IntervalSeconds) + " 秒)が範囲の長さ(" + SecondsText.Format(length)
                    + " 秒)より短いため、コピー同士が重なります。間隔を範囲の長さ以上にしてください。";
            }
            if (r.SnapToFrames && !(r.Clip.frameRate > 0f && !float.IsInfinity(r.Clip.frameRate)))
                return "クリップのフレームレートが正しくないため、フレームに合わせられません。";
            return null;
        }

        static bool IsFinite(double v)
        {
            return !double.IsNaN(v) && !double.IsInfinity(v);
        }

        /// <summary>
        /// 対象カーブ(null = 全部)をクリップに実在するものに絞る(パス・型・プロパティ名で突き合わせ、重複は 1 つ)。
        /// 回転は成分の一部だけを複製すると壊れるため、どれか 1 成分(または表示用の別名)が含まれていれば
        /// 同じパスの回転カーブを全部対象にする(RotationCurves)。
        /// </summary>
        static List<ClipCurveRef> ResolveTargets(IReadOnlyList<ClipCurveRef> all, IReadOnlyList<ClipCurveRef> requested, out int missing, out int rotationAdded)
        {
            if (requested == null)
            {
                missing = 0;
                rotationAdded = 0;
                return all.ToList();
            }
            return RotationCurves.Resolve(requested, all, out missing, out rotationAdded);
        }

        static void Accumulate<T>(RepeatPreview p, CurvePlanResult<T> r)
        {
            p.TargetCurveCount++;
            p.SourceKeyCount += r.Source;
            p.AddedKeyCount += r.Added;
            p.RemovedKeyCount += r.Removed;
            p.SeamReplacedKeyCount += r.SeamReplaced;
            p.ConflictingKeyCount += r.Conflicting;
            p.SkippedKeyCount += r.Skipped;
            p.SnapMergedKeyCount += r.SnapMerged;
            if (r.SeamReplaced > 0 || r.Displaced > 0) p.HasSeamOverlap = true;
        }

        static float LastTime<T>(T[] keys, IKeyAccess<T> access)
        {
            float last = float.NegativeInfinity;
            if (keys == null) return last;
            foreach (T k in keys) last = Math.Max(last, access.Time(k));
            return last;
        }

        // ------------------------------------------------------------------
        // 1 本のカーブの計画(float / ObjectReference 共通)
        // ------------------------------------------------------------------

        /// <summary>計算に使う値をまとめたもの。複製先の範囲 [Lo[c], Hi[c]) は c = 0 がコピー 1 個目。</summary>
        internal sealed class Settings
        {
            public readonly double Start;
            public readonly double EndExclusive; // IncludeEndKey なら終了 + 2ε(終了時刻ちょうどのキーを含める)
            public readonly double Interval;
            public readonly double PreviousOffset;
            public readonly int Count;
            public readonly bool Snap;
            public readonly double FrameRate;
            public readonly RepeatConflictPolicy Policy;
            public readonly double[] Lo;
            public readonly double[] Hi;

            public Settings(RepeatRequest r)
            {
                Start = r.StartSeconds;
                EndExclusive = r.IncludeEndKey ? r.EndSeconds + 2.0 * Eps : r.EndSeconds;
                Interval = r.IntervalSeconds;
                PreviousOffset = r.PreviousOffset;
                Count = r.Count;
                Snap = r.SnapToFrames;
                FrameRate = r.Clip.frameRate;
                Policy = r.Policy;
                Lo = new double[Count];
                Hi = new double[Count];
                for (int c = 0; c < Count; c++)
                {
                    double offset = PreviousOffset + (c + 1) * Interval;
                    if (Snap)
                    {
                        Lo[c] = SnapTime(Start + offset);
                        Hi[c] = SnapTime(r.EndSeconds + offset) + (r.IncludeEndKey ? 2.0 * Eps : 0.0);
                    }
                    else
                    {
                        Lo[c] = Start + offset;
                        Hi[c] = EndExclusive + offset;
                    }
                }
            }

            public double SnapTime(double t)
            {
                return Math.Round(t * FrameRate, MidpointRounding.AwayFromZero) / FrameRate;
            }

            /// <summary>どれかのコピーの複製先範囲に入るか(判定は CurveKeyUtility と同じ: t ≥ 開始 − ε かつ t &lt; 終了 − ε)。</summary>
            public bool InAnyDestination(double t)
            {
                // Lo / Hi は c について単調非減少。Lo[c] − ε ≤ t となる最大の c だけ調べればよい
                int lo = 0, hi = Count - 1, found = -1;
                while (lo <= hi)
                {
                    int mid = (lo + hi) >> 1;
                    if (Lo[mid] - Eps <= t)
                    {
                        found = mid;
                        lo = mid + 1;
                    }
                    else
                    {
                        hi = mid - 1;
                    }
                }
                return found >= 0 && t < Hi[found] - Eps;
            }
        }

        internal static bool InRange(double t, double start, double endExclusive)
        {
            return t >= start - Eps && t < endExclusive - Eps;
        }

        /// <summary>昇順の times に、t と「同じ時刻」(差が ε 以下)のものがあるか。</summary>
        static bool Collides(double[] sortedTimes, double t)
        {
            int lo = 0, hi = sortedTimes.Length;
            double min = t - Eps;
            while (lo < hi)
            {
                int mid = (lo + hi) >> 1;
                if (sortedTimes[mid] < min) lo = mid + 1;
                else hi = mid;
            }
            return lo < sortedTimes.Length && sortedTimes[lo] <= t + Eps;
        }

        internal interface IKeyAccess<T>
        {
            float Time(T key);
            T WithTime(T key, float time);

            /// <summary>source の範囲内のキーを offset 秒ずらしたもの(CurveKeyUtility.CopyRange を空の貼り付け先に使う)。時刻昇順。</summary>
            T[] Shift(T[] source, double start, double endExclusive, double offset);
        }

        sealed class FloatKeyAccess : IKeyAccess<Keyframe>
        {
            readonly AnimationCurve _src = new AnimationCurve();
            readonly AnimationCurve _dst = new AnimationCurve();

            public float Time(Keyframe key) { return key.time; }

            public Keyframe WithTime(Keyframe key, float time)
            {
                key.time = time; // 構造体のコピー: 接線・重み・接線モードはそのまま
                return key;
            }

            public Keyframe[] Shift(Keyframe[] source, double start, double endExclusive, double offset)
            {
                _src.keys = source;
                _dst.keys = Array.Empty<Keyframe>();
                CurveKeyUtility.CopyRange(_src, start, endExclusive, offset, _dst, true);
                return _dst.keys;
            }
        }

        sealed class ObjectKeyAccess : IKeyAccess<ObjectReferenceKeyframe>
        {
            public float Time(ObjectReferenceKeyframe key) { return key.time; }

            public ObjectReferenceKeyframe WithTime(ObjectReferenceKeyframe key, float time)
            {
                key.time = time;
                return key;
            }

            public ObjectReferenceKeyframe[] Shift(ObjectReferenceKeyframe[] source, double start, double endExclusive, double offset)
            {
                return CurveKeyUtility.CopyRange(source, start, endExclusive, offset, Array.Empty<ObjectReferenceKeyframe>(), out _, true);
            }
        }

        internal sealed class CurvePlanResult<T>
        {
            public bool Participates;
            public bool Changed;
            public T[] Keys;
            public int Source, Added, Removed, SeamReplaced, Conflicting, Skipped, SnapMerged, Displaced;
        }

        static class CurvePlanner<T>
        {
            /// <summary>
            /// 実行前のキー orig から実行後のキーを作る。キーは 3 種類に分けて扱う:
            ///  S = 元の範囲のキー / E = 範囲外の既存キー / P = 貼るキー(全コピー)。
            /// 件数は「どの S・E が残り、どの P が残るか」から数えるので、実行前後の差と必ず一致する。
            /// </summary>
            public static CurvePlanResult<T> Run(T[] orig, IKeyAccess<T> access, Settings st, T[] captured = null)
            {
                var result = new CurvePlanResult<T>();
                var source = new List<T>();
                var existing = new List<T>();
                foreach (T k in orig)
                {
                    if (InRange(access.Time(k), st.Start, st.EndExclusive)) source.Add(k);
                    else existing.Add(k);
                }
                T[] sourceArr = captured == null ? source.OrderBy(access.Time).ToArray()
                    : captured.Where(k => InRange(access.Time(k), st.Start, st.EndExclusive)).OrderBy(access.Time).ToArray();
                if (sourceArr.Length == 0) return result;
                result.Participates = true;
                result.Source = sourceArr.Length;

                // P: コピーを 1 個目から順に重ねる。同じ時刻に先のコピーのキーがあれば後のコピーで置き換える。
                var pasted = new List<T>();
                for (int c = 0; c < st.Count; c++)
                {
                    T[] copy = st.Snap
                        ? SnapShift(sourceArr, st.PreviousOffset + (c + 1) * st.Interval, access, st, ref result.SnapMerged)
                        : access.Shift(sourceArr, st.Start, st.EndExclusive, st.PreviousOffset + (c + 1) * st.Interval);
                    if (copy.Length == 0) continue;
                    double[] copyTimes = Times(copy, access);
                    result.Displaced += RemoveColliding(pasted, copyTimes, access);
                    bool needsSort = pasted.Count > 0 && access.Time(pasted[pasted.Count - 1]) > copyTimes[0];
                    pasted.AddRange(copy);
                    if (needsSort) pasted = pasted.OrderBy(access.Time).ToList();
                }

                // E と P の衝突をポリシーで解決する
                var existingAlive = new List<T>(existing.Count);
                List<T> pastedAlive;
                if (st.Policy == RepeatConflictPolicy.KeepExisting)
                {
                    double[] existingTimes = Times(existing, access);
                    Array.Sort(existingTimes);
                    pastedAlive = new List<T>(pasted.Count);
                    foreach (T p in pasted)
                    {
                        if (Collides(existingTimes, access.Time(p))) result.Skipped++;
                        else pastedAlive.Add(p);
                    }
                    existingAlive.AddRange(existing);
                }
                else
                {
                    // 消してから貼る / 中止: 複製先の範囲にある既存キーと、貼るキーと同じ時刻の既存キーが衝突
                    double[] pastedTimes = Times(pasted, access);
                    foreach (T e in existing)
                    {
                        double t = access.Time(e);
                        if (st.InAnyDestination(t) || Collides(pastedTimes, t)) result.Conflicting++;
                        else existingAlive.Add(e);
                    }
                    pastedAlive = pasted;
                }

                // S は後から貼る P と同じ時刻なら置き換わる(終了キー と 次のコピーの先頭 の重なり)
                double[] aliveTimes = Times(pastedAlive, access);
                var sourceAlive = new List<T>(source.Count);
                foreach (T k in source)
                {
                    if (Collides(aliveTimes, access.Time(k))) result.SeamReplaced++;
                    else sourceAlive.Add(k);
                }

                result.Added = pastedAlive.Count;
                result.Removed = result.SeamReplaced + (existing.Count - existingAlive.Count);
                result.Changed = result.Added > 0 || result.Removed > 0;
                // 同じ時刻は「元からあったキー → 貼ったキー」の順(OrderBy は安定ソート)
                result.Keys = sourceAlive.Concat(existingAlive).Concat(pastedAlive).OrderBy(access.Time).ToArray();
                return result;
            }

            /// <summary>「フレームに合わせる」: 元の時刻 + offset を double で計算し、フレームに丸めてから float にする。同じフレームに重なったら後のキーを残す。</summary>
            static T[] SnapShift(T[] sourceSorted, double offset, IKeyAccess<T> access, Settings st, ref int merged)
            {
                var list = new List<T>(sourceSorted.Length);
                foreach (T k in sourceSorted)
                {
                    float time = (float)st.SnapTime((double)access.Time(k) + offset);
                    T moved = access.WithTime(k, time);
                    if (list.Count > 0 && Math.Abs((double)access.Time(list[list.Count - 1]) - time) <= Eps)
                    {
                        list[list.Count - 1] = moved;
                        merged++;
                    }
                    else
                    {
                        list.Add(moved);
                    }
                }
                return list.ToArray();
            }

            /// <summary>pasted(昇順)のうち copyTimes のどれかと同じ時刻のキーを取り除き、その数を返す。調べるのは末尾側だけ。</summary>
            static int RemoveColliding(List<T> pasted, double[] copyTimes, IKeyAccess<T> access)
            {
                if (pasted.Count == 0) return 0;
                double min = copyTimes[0] - Eps;
                int removed = 0;
                for (int i = pasted.Count - 1; i >= 0; i--)
                {
                    double t = access.Time(pasted[i]);
                    if (t < min) break;
                    if (Collides(copyTimes, t))
                    {
                        pasted.RemoveAt(i);
                        removed++;
                    }
                }
                return removed;
            }

            static double[] Times(IReadOnlyList<T> keys, IKeyAccess<T> access)
            {
                var times = new double[keys.Count];
                for (int i = 0; i < keys.Count; i++) times[i] = access.Time(keys[i]);
                return times;
            }
        }
    }
}
