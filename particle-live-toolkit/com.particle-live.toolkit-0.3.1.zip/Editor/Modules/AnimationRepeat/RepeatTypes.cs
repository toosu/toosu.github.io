using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>複製先に既存のキーがあるときの扱い。</summary>
    public enum RepeatConflictPolicy
    {
        /// <summary>各コピーの貼り付け先範囲にある既存キーを消してから貼る(既定)。</summary>
        ClearDestination = 0,

        /// <summary>既存キーを残し、同じ時刻に既存キーがある所には貼らない。</summary>
        KeepExisting = 1,

        /// <summary>複製先に既存キーが 1 つでもあれば実行しない。</summary>
        Abort = 2,
    }

    /// <summary>範囲リピート複製の入力。</summary>
    public sealed class RepeatRequest
    {
        public AnimationClip Clip;

        /// <summary>範囲の開始(秒)。範囲は半開区間 [開始, 終了)。</summary>
        public double StartSeconds;

        /// <summary>範囲の終了(秒)。</summary>
        public double EndSeconds;

        /// <summary>true なら終了時刻ちょうどのキーも範囲に含める。</summary>
        public bool IncludeEndKey;

        /// <summary>コピー同士の間隔(秒)。コピー k 個目は元の時刻 + k × 間隔。</summary>
        public double IntervalSeconds;

        /// <summary>コピーの回数(1〜RangeRepeater.MaxCount)。</summary>
        public int Count = 1;
        // Quick repeat keeps the originally captured keys and advances only its destination.
        internal AnimationClip CapturedSource;
        internal double PreviousOffset;

        /// <summary>対象カーブ。null ならクリップの全カーブ。クリップに無いカーブは無視する。</summary>
        public IReadOnlyList<ClipCurveRef> TargetCurves;

        public RepeatConflictPolicy Policy = RepeatConflictPolicy.ClearDestination;

        /// <summary>true なら貼り付け先の時刻をクリップのフレームレートのグリッドに丸める。</summary>
        public bool SnapToFrames;
    }

    /// <summary>
    /// 複製のプレビュー(= 適用したときに起きることの件数)。RangeRepeater.Apply も同じ計算の結果を返す。
    /// 件数はすべて「実行前のクリップ」と「実行後のクリップ」の差として数える。
    /// </summary>
    public sealed class RepeatPreview
    {
        /// <summary>実行できない理由(日本語)。実行できるなら null。</summary>
        public string Reason { get; internal set; }

        public bool CanExecute
        {
            get { return Reason == null; }
        }

        /// <summary>複製の対象になるカーブ数(対象カーブのうち、範囲内にキーがあるもの)。</summary>
        public int TargetCurveCount { get; internal set; }

        /// <summary>範囲内のキー数(コピー 1 回ぶん、全対象カーブの合計)。</summary>
        public int SourceKeyCount { get; internal set; }

        /// <summary>実行後のクリップに増えるキー数(貼ったキーのうち最終的に残るもの)。</summary>
        public int AddedKeyCount { get; internal set; }

        /// <summary>実行前からあったキーのうち、実行後に消えるもの(上書きされるものを含む)。</summary>
        public int RemovedKeyCount { get; internal set; }

        /// <summary>
        /// RemovedKeyCount のうち、元の範囲の終了時刻のキーが次のコピーの先頭キーで上書きされて消える数
        /// (「終了キーを含める」かつ 間隔 = 範囲の長さ のときに起きる)。
        /// </summary>
        public int SeamReplacedKeyCount { get; internal set; }

        /// <summary>コピー同士やコピーと元の範囲が同じ時刻で重なり、後から貼る方を優先したか。</summary>
        public bool HasSeamOverlap { get; internal set; }

        /// <summary>複製先にある既存キーの数(「中止」で止まる原因になるキー。「消してから貼る」で消えるキー)。</summary>
        public int ConflictingKeyCount { get; internal set; }

        /// <summary>「既存キーを残す」で、既存キーと同じ時刻だったため貼らなかったキー数。</summary>
        public int SkippedKeyCount { get; internal set; }

        /// <summary>「フレームに合わせる」で同じフレームに重なり、1 つにまとめたキー数(後のキーを残す)。</summary>
        public int SnapMergedKeyCount { get; internal set; }

        /// <summary>対象カーブとして指定されたが、クリップに無かったカーブ数。</summary>
        public int MissingTargetCurveCount { get; internal set; }

        /// <summary>回転の成分をまとめて複製するために、指定に加えて対象にした回転カーブの数。</summary>
        public int RotationAddedCurveCount { get; internal set; }

        /// <summary>実行前のクリップ長(秒)。</summary>
        public float OriginalLength { get; internal set; }

        /// <summary>実行後のクリップ長(秒)。</summary>
        public float ResultLength { get; internal set; }

        internal static RepeatPreview Fail(string reason)
        {
            return new RepeatPreview { Reason = reason };
        }
    }
}
