using System;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEditor.ShortcutManagement;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    internal static class ActiveKeyShortcut
    {
        internal const string Id = "Particle Live/選択オブジェクトを現在のフレームでオン";

        [Shortcut(Id, typeof(AnimationWindow), KeyCode.R, ShortcutModifiers.Control)]
        static void Record(ShortcutArguments args)
        {
            var window = args.context as AnimationWindow;
            if (!window || EditorGUIUtility.editingTextField || EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (!TryRecord(window.animationClip, AnimationWindowBridge.GetEditedRoot(window),
                Selection.activeGameObject, window.time, out string reason))
                window.ShowNotification(new GUIContent(reason));
            window.Repaint();
        }

        internal static bool TryRecord(AnimationClip clip, GameObject root, GameObject selected, float localTime, out string reason)
        {
            if (!ClipEditUtility.IsEditable(clip, out reason)) return false;
            if (!root || !selected || !selected.transform.IsChildOf(root.transform))
            {
                reason = "編集中の Animation のルート、またはその子を Hierarchy で選択してください。";
                return false;
            }
            if (!AssetDatabase.Contains(clip) || !AssetDatabase.IsOpenForEdit(clip))
            {
                reason = "書き込み可能な AnimationClip を選択してください。";
                return false;
            }
            var binding = AnimationUtility.GetAnimatableBindings(selected, root)
                .FirstOrDefault(b => b.type == typeof(GameObject) && b.propertyName == "m_IsActive");
            if (binding.type == null || AnimationUtility.GetAnimatedObject(root, binding) != selected)
            {
                reason = "このオブジェクトの Active を特定できません。階層の名前と編集ルートを確認してください。";
                return false;
            }
            double fps = clip.frameRate;
            double frame = Math.Round((double)localTime * fps, MidpointRounding.AwayFromZero);
            if (!(fps > 0 && frame >= 0 && frame <= int.MaxValue))
            {
                reason = "クリップの範囲内に編集位置を移動してください。";
                return false;
            }
            var on = (float)(frame / fps);
            var off = (float)((frame - 1) / fps);
            if (frame > 0 && on == off)
            {
                reason = "この位置では隣り合うフレームを別のキーとして記録できません。";
                return false;
            }

            var edit = new ClipEditSession(clip);
            var curve = edit.GetFloatCurve(binding) ?? new AnimationCurve();
            var insert = new AnimationCurve();
            if (frame > 0) insert.AddKey(new Keyframe(off, 0));
            insert.AddKey(new Keyframe(on, 1));
            for (int i = 0; i < insert.length; i++)
            {
                AnimationUtility.SetKeyLeftTangentMode(insert, i, AnimationUtility.TangentMode.Constant);
                AnimationUtility.SetKeyRightTangentMode(insert, i, AnimationUtility.TangentMode.Constant);
            }
            double epsilon = Math.Min(CurveKeyUtility.TimeEpsilon, 0.001 / fps);
            curve.keys = curve.keys.Where(k => Math.Abs((double)k.time - on) > epsilon &&
                (frame == 0 || Math.Abs((double)k.time - off) > epsilon))
                .Concat(insert.keys).OrderBy(k => k.time).ToArray();
            edit.SetFloatCurve(binding, curve);
            edit.Commit("選択オブジェクトのオン・オフを記録");
            AssetDatabase.SaveAssetIfDirty(clip);
            return true;
        }
    }
}
