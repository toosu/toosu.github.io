using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// カーブを「パス・型・プロパティ名・ObjectReference か」だけで識別する文字列キー。
    /// EditorCurveBinding の等価判定は離散カーブなどの内部フラグも比べるため、保存から復元したバインディングや
    /// Animation ウィンドウから取ったバインディングをクリップのカーブと突き合わせるときはこのキーを使う。
    /// </summary>
    internal static class CurveRefKey
    {
        const char FieldSeparator = '\u001F';
        const char RecordSeparator = '\u001E';

        public static string Of(ClipCurveRef c)
        {
            EditorCurveBinding b = c.Binding;
            return (c.IsObjectReference ? "P" : "F") + FieldSeparator + (b.path ?? "") + FieldSeparator
                + (b.type != null ? b.type.AssemblyQualifiedName : "") + FieldSeparator + (b.propertyName ?? "");
        }

        /// <summary>クリップのカーブ一覧をキー → カーブの辞書にする(同じキーは最初のもの)。</summary>
        public static Dictionary<string, ClipCurveRef> Index(IReadOnlyList<ClipCurveRef> curves)
        {
            var d = new Dictionary<string, ClipCurveRef>(StringComparer.Ordinal);
            foreach (ClipCurveRef c in curves)
            {
                string key = Of(c);
                if (!d.ContainsKey(key)) d.Add(key, c);
            }
            return d;
        }

        /// <summary>カーブの一覧を 1 つの文字列にする(ModuleState 保存用)。</summary>
        public static string Encode(IReadOnlyList<ClipCurveRef> curves)
        {
            if (curves == null || curves.Count == 0) return "";
            var parts = new string[curves.Count];
            for (int i = 0; i < curves.Count; i++) parts[i] = Of(curves[i]);
            return string.Join(RecordSeparator.ToString(), parts);
        }

        /// <summary>Encode の逆。型が見つからないものは除く。</summary>
        public static List<ClipCurveRef> Decode(string encoded)
        {
            var result = new List<ClipCurveRef>();
            if (string.IsNullOrEmpty(encoded)) return result;
            foreach (string record in encoded.Split(RecordSeparator))
            {
                string[] f = record.Split(FieldSeparator);
                if (f.Length != 4) continue;
                Type type = string.IsNullOrEmpty(f[2]) ? null : Type.GetType(f[2], false);
                if (type == null) continue;
                bool pptr = f[0] == "P";
                EditorCurveBinding b = pptr ? EditorCurveBinding.PPtrCurve(f[1], type, f[3]) : EditorCurveBinding.FloatCurve(f[1], type, f[3]);
                result.Add(new ClipCurveRef(b, pptr));
            }
            return result;
        }
    }
}
