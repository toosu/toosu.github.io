using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// 回転カーブを「成分をまとめて 1 組」として扱うための規則。
    ///
    /// 組: 同じパスにある Transform(RectTransform を含む)の float カーブのうち、プロパティ名が次で始まるもの全部。
    ///   m_LocalRotation.(x/y/z/w)        … Quaternion で保存された回転
    ///   localEulerAnglesRaw.(x/y/z)      … Euler で保存された回転
    ///   localEulerAnglesBaked.(x/y/z)    … Animation ウィンドウが Quaternion 回転を Euler で見せるときの名前
    ///   localEulerAngles.(x/y/z)         … Animation ウィンドウが Euler 回転を見せるときの名前
    /// 一部の成分だけを複製すると回転が壊れるため、どれか 1 つが対象になったら、クリップ上にあるその組の全成分を対象にする。
    /// 指定されたバインディングがクリップに無い名前(上の別名)でも、同じパスの回転カーブに対応付ける。
    /// </summary>
    internal static class RotationCurves
    {
        static readonly string[] Prefixes = { "m_LocalRotation.", "localEulerAnglesRaw.", "localEulerAnglesBaked.", "localEulerAngles." };

        public static bool IsRotation(ClipCurveRef c)
        {
            EditorCurveBinding b = c.Binding;
            if (c.IsObjectReference || b.type == null || b.propertyName == null) return false;
            if (!typeof(Transform).IsAssignableFrom(b.type)) return false;
            foreach (string p in Prefixes)
                if (b.propertyName.StartsWith(p, StringComparison.Ordinal)) return true;
            return false;
        }

        /// <summary>回転の組を識別するキー(パス)。IsRotation が true のカーブにだけ使う。</summary>
        public static string GroupKey(ClipCurveRef c)
        {
            return c.Binding.path ?? "";
        }

        /// <summary>
        /// 指定されたカーブを、クリップに実在するカーブ(クリップの並び順、重複なし)に対応付ける。
        ///  - パス・型・プロパティ名が一致するものはそのクリップのカーブ。
        ///  - 回転の成分(または別名)が含まれていれば、同じパスにあるクリップ上の回転カーブを全部加える。
        ///    直接指定されていなかったのに加えた数を rotationAdded に返す。
        ///  - どれにも対応しなかった指定(同じキーは 1 回)の数を missing に返す。
        /// </summary>
        public static List<ClipCurveRef> Resolve(IEnumerable<ClipCurveRef> requested, IReadOnlyList<ClipCurveRef> clipCurves,
            out int missing, out int rotationAdded)
        {
            missing = 0;
            rotationAdded = 0;
            Dictionary<string, ClipCurveRef> index = CurveRefKey.Index(clipCurves);
            var chosen = new HashSet<string>(StringComparer.Ordinal);
            var requestedKeys = new HashSet<string>(StringComparer.Ordinal);
            var rotationPaths = new HashSet<string>(StringComparer.Ordinal);
            var aliasKeysByPath = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

            if (requested != null)
            {
                foreach (ClipCurveRef r in requested)
                {
                    string key = CurveRefKey.Of(r);
                    if (!requestedKeys.Add(key)) continue;
                    if (index.TryGetValue(key, out ClipCurveRef actual))
                    {
                        chosen.Add(key);
                        if (IsRotation(actual)) rotationPaths.Add(GroupKey(actual));
                    }
                    else if (IsRotation(r))
                    {
                        // クリップに無い回転の名前(Animation ウィンドウの表示用の別名など)。同じパスの回転カーブに対応付ける
                        string path = GroupKey(r);
                        rotationPaths.Add(path);
                        if (!aliasKeysByPath.TryGetValue(path, out var set)) aliasKeysByPath[path] = set = new HashSet<string>(StringComparer.Ordinal);
                        set.Add(key);
                    }
                    else
                    {
                        missing++;
                    }
                }
            }

            var result = new List<ClipCurveRef>();
            var pathsWithRotation = new HashSet<string>(StringComparer.Ordinal);
            foreach (ClipCurveRef c in clipCurves)
            {
                string key = CurveRefKey.Of(c);
                bool rotation = IsRotation(c);
                if (rotation) pathsWithRotation.Add(GroupKey(c));
                if (chosen.Contains(key))
                {
                    result.Add(c);
                }
                else if (rotation && rotationPaths.Contains(GroupKey(c)))
                {
                    result.Add(c);
                    chosen.Add(key);
                    rotationAdded++;
                }
            }

            // 別名で指定されたが、そのパスに回転カーブが 1 本も無いもの
            foreach (var kv in aliasKeysByPath)
                if (!pathsWithRotation.Contains(kv.Key)) missing += kv.Value.Count;

            return result;
        }
    }
}
