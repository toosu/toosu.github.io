using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// Animation Editor モジュールの入力と操作(IMGUI なし)。入力値は ModuleState に保存するので、
    /// 再コンパイルでインスタンスが作り直されても残る。プレビューは入力・クリップの変更があったときだけ計算し直す。
    /// </summary>
    public sealed class AnimationRepeatController
    {
        const string ClipKey = "clip";
        const string StartKey = "start";
        const string EndKey = "end";
        const string IncludeEndStateKey = "includeEnd";
        const string IntervalPrefix = "interval";
        const string CountKey = "count";
        const string AllCurvesKey = "allCurves";
        const string CurvesKey = "curves";
        const string PolicyKey = "policy";
        const string SnapKey = "snap";

        readonly ModuleState _state;
        readonly IAnimationWindowBridge _bridge;

        string _previewSignature;
        RepeatPreview _preview;
        int _invalidation;

        string _selectedCurvesRaw;
        IReadOnlyList<ClipCurveRef> _selectedCurves;
        HashSet<string> _selectedCurveKeys;

        public AnimationRepeatController(ModuleState state, IAnimationWindowBridge bridge)
        {
            _state = state ?? throw new ArgumentNullException(nameof(state));
            _bridge = bridge ?? new AnimationWindowBridge();
        }

        public IAnimationWindowBridge Bridge
        {
            get { return _bridge; }
        }

        /// <summary>手動で選んだクリップ。null なら ResolveClip はライブの mainClip を使う。</summary>
        public AnimationClip ExplicitClip
        {
            get
            {
                return LiveSettings.Resolve<AnimationClip>(_state.GetString(ClipKey));
            }
            set { _state.SetString(ClipKey, LiveSettings.Identifier(value)); }
        }

        /// <summary>対象クリップ: 手動で選んだクリップ、無ければ編集中のライブの mainClip。</summary>
        public AnimationClip ResolveClip(ToolkitContext ctx)
        {
            AnimationClip clip = ExplicitClip;
            if (clip != null) return clip;
            ParticleLiveProject project = ctx != null ? ctx.ActiveProject : null;
            return project != null && project.mainClip != null ? project.mainClip : null;
        }

        /// <summary>
        /// 保存してよい秒数の絶対値の上限。これを超える値・NaN・無限大は保存せず、保存領域から読んだ場合は既定値に戻す
        /// (RangeRepeater.MaxSeconds を超えて StoredSecondsLimit 以下の値は保存し、実行できない理由として表示する)。
        /// </summary>
        public const double StoredSecondsLimit = 1e9;

        /// <summary>保存してよい秒数か(有限かつ絶対値が StoredSecondsLimit 以下)。</summary>
        public static bool IsStorableSeconds(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && Math.Abs(value) <= StoredSecondsLimit;
        }

        /// <summary>保存してよい間隔か(秒数直指定の秒数と倍率が 0 以上で、IsStorableSeconds を満たす)。</summary>
        public static bool IsStorableInterval(BeatInterval value)
        {
            return IsStorableSeconds(value.customSeconds) && value.customSeconds >= 0.0
                && IsStorableSeconds(value.multiplier) && value.multiplier >= 0.0;
        }

        /// <summary>開始(秒)。保存できない値の代入は無視する。</summary>
        public double StartSeconds
        {
            get { return ReadSeconds(StartKey); }
            set { if (IsStorableSeconds(value)) _state.SetDouble(StartKey, value); }
        }

        /// <summary>終了(秒)。保存できない値の代入は無視する。</summary>
        public double EndSeconds
        {
            get { return ReadSeconds(EndKey); }
            set { if (IsStorableSeconds(value)) _state.SetDouble(EndKey, value); }
        }

        double ReadSeconds(string key)
        {
            double v = _state.GetDouble(key, 0.0);
            return IsStorableSeconds(v) ? v : 0.0;
        }

        public bool IncludeEndKey
        {
            get { return _state.GetBool(IncludeEndStateKey, false); }
            set { _state.SetBool(IncludeEndStateKey, value); }
        }

        /// <summary>間隔。保存できない値の代入は無視し、保存領域の値が不正なら該当項目を既定値に戻して返す。</summary>
        public BeatInterval Interval
        {
            get
            {
                BeatInterval v = BeatInterval.Load(_state, IntervalPrefix, BeatInterval.Default);
                BeatInterval d = BeatInterval.Default;
                if (!IsStorableSeconds(v.customSeconds) || v.customSeconds < 0.0) v.customSeconds = d.customSeconds;
                if (!IsStorableSeconds(v.multiplier) || v.multiplier < 0.0) v.multiplier = d.multiplier;
                return v;
            }
            set { if (IsStorableInterval(value)) value.Save(_state, IntervalPrefix); }
        }

        public int Count
        {
            get { return _state.GetInt(CountKey, 1); }
            set { _state.SetInt(CountKey, value); }
        }

        /// <summary>true ならクリップの全カーブが対象。false なら SelectedCurves だけ。</summary>
        public bool UseAllCurves
        {
            get { return _state.GetBool(AllCurvesKey, true); }
            set { _state.SetBool(AllCurvesKey, value); }
        }

        /// <summary>UseAllCurves が false のときの対象カーブ。</summary>
        /// <remarks>復元(Type.GetType を含む)は保存文字列が変わったときだけ行い、結果をキャッシュする。</remarks>
        public IReadOnlyList<ClipCurveRef> SelectedCurves
        {
            get
            {
                RefreshSelectedCurveCache();
                return _selectedCurves;
            }
            set { _state.SetString(CurvesKey, CurveRefKey.Encode(value)); }
        }

        /// <summary>SelectedCurves の識別キー(CurveRefKey.Of)の集合。キャッシュを返すので変更しないこと。</summary>
        internal IReadOnlyCollection<string> SelectedCurveKeys
        {
            get
            {
                RefreshSelectedCurveCache();
                return _selectedCurveKeys;
            }
        }

        /// <summary>SelectedCurves の復元が実際に行われた回数(キャッシュの確認用)。</summary>
        internal int SelectedCurvesDecodeCount { get; private set; }

        string SelectedCurvesRaw
        {
            get { return _state.GetString(CurvesKey, ""); }
        }

        void RefreshSelectedCurveCache()
        {
            string raw = SelectedCurvesRaw;
            if (_selectedCurves != null && raw == _selectedCurvesRaw) return;
            List<ClipCurveRef> decoded = CurveRefKey.Decode(raw);
            _selectedCurves = decoded.AsReadOnly();
            _selectedCurveKeys = new HashSet<string>(decoded.Select(CurveRefKey.Of), StringComparer.Ordinal);
            _selectedCurvesRaw = raw;
            SelectedCurvesDecodeCount++;
        }

        public RepeatConflictPolicy Policy
        {
            get
            {
                int v = _state.GetInt(PolicyKey, (int)RepeatConflictPolicy.ClearDestination);
                return Enum.IsDefined(typeof(RepeatConflictPolicy), v) ? (RepeatConflictPolicy)v : RepeatConflictPolicy.ClearDestination;
            }
            set { _state.SetInt(PolicyKey, (int)value); }
        }

        public bool SnapToFrames
        {
            get { return _state.GetBool(SnapKey, false); }
            set { _state.SetBool(SnapKey, value); }
        }

        /// <summary>現在の入力から RangeRepeater の入力を作る(間隔は bpm で秒に換算)。</summary>
        public RepeatRequest BuildRequest(AnimationClip clip, double bpm)
        {
            return new RepeatRequest
            {
                Clip = clip,
                StartSeconds = StartSeconds,
                EndSeconds = EndSeconds,
                IncludeEndKey = IncludeEndKey,
                IntervalSeconds = Interval.ToSeconds(bpm),
                Count = Count,
                TargetCurves = UseAllCurves ? null : SelectedCurves,
                Policy = Policy,
                SnapToFrames = SnapToFrames,
            };
        }

        /// <summary>
        /// プレビュー。入力・BPM・クリップ(EditorUtility.GetDirtyCount)が前回と同じなら前回の結果を返す。
        /// </summary>
        public RepeatPreview GetPreview(AnimationClip clip, double bpm)
        {
            RepeatRequest request = BuildRequest(clip, bpm);
            string signature = Signature(request);
            if (_preview != null && signature == _previewSignature) return _preview;
            _preview = RangeRepeater.Preview(request);
            _previewSignature = signature;
            return _preview;
        }

        /// <summary>次の GetPreview で必ず計算し直す(Undo / Redo のあとなど)。</summary>
        public void InvalidatePreview()
        {
            _invalidation++;
            _preview = null;
        }

        /// <summary>現在の入力で複製を実行する(実行時にもう一度計算する)。結果の件数は実際に適用した件数。</summary>
        public RepeatPreview Apply(AnimationClip clip, double bpm)
        {
            RepeatPreview result = RangeRepeater.Apply(BuildRequest(clip, bpm));
            InvalidatePreview();
            return result;
        }

        /// <summary>Animation ウィンドウで選択中のキーから、クリップ・範囲(終了キーを含める)・対象カーブを取り込む。</summary>
        public bool ImportSelection(out string message)
        {
            SelectionImportResult r = SelectionImport.FromBridge(_bridge);
            if (!r.Success)
            {
                message = r.Reason;
                return false;
            }
            ExplicitClip = r.Clip;
            StartSeconds = r.StartSeconds;
            EndSeconds = r.EndSeconds;
            IncludeEndKey = r.IncludeEndKey;
            UseAllCurves = false;
            SelectedCurves = r.Curves;
            message = "選択中のキー " + r.KeyCount + " 個から範囲を取得しました(" + SecondsText.Format(r.StartSeconds) + " 〜 "
                + SecondsText.Format(r.EndSeconds) + " 秒、カーブ " + r.Curves.Count + " 本)"
                + (r.RotationAddedCount > 0 ? "。回転は成分をまとめて複製するため、" + r.RotationAddedCount + " 本を追加しました" : "")
                + (r.DroppedCurveCount > 0 ? "。クリップに無いカーブ " + r.DroppedCurveCount + " 本は除きました" : "") + "。";
            InvalidatePreview();
            return true;
        }

        /// <summary>Animation ウィンドウに表示中のクリップを対象にする。</summary>
        public bool TakeWindowClip(out string message)
        {
            if (!_bridge.TryGetClip(out AnimationClip clip, out string reason) || clip == null)
            {
                message = string.IsNullOrEmpty(reason) ? "Animation ウィンドウのクリップを取得できませんでした。" : reason;
                return false;
            }
            ExplicitClip = clip;
            message = "クリップ「" + clip.name + "」を対象にしました。";
            InvalidatePreview();
            return true;
        }

        public bool SetStartFromPlayhead(out string message)
        {
            if (!TryGetPlayhead(out double t, out message)) return false;
            StartSeconds = t;
            message = "開始を " + SecondsText.Format(t) + " 秒にしました。";
            return true;
        }

        public bool SetEndFromPlayhead(out string message)
        {
            if (!TryGetPlayhead(out double t, out message)) return false;
            EndSeconds = t;
            message = "終了を " + SecondsText.Format(t) + " 秒にしました。";
            return true;
        }

        bool TryGetPlayhead(out double time, out string message)
        {
            if (!_bridge.TryGetTime(out time, out string reason))
            {
                message = string.IsNullOrEmpty(reason) ? "Animation ウィンドウの再生ヘッドを取得できませんでした。" : reason;
                return false;
            }
            message = null;
            return true;
        }

        string Signature(RepeatRequest r)
        {
            var inv = CultureInfo.InvariantCulture;
            int clipId = r.Clip != null ? r.Clip.GetInstanceID() : 0;
            int dirty = r.Clip != null ? EditorUtility.GetDirtyCount(r.Clip) : 0;
            float fps = r.Clip != null ? r.Clip.frameRate : 0f;
            string curves = r.TargetCurves == null ? "*" : SelectedCurvesRaw;
            return string.Join("|",
                clipId.ToString(inv), dirty.ToString(inv), BitConverter.SingleToInt32Bits(fps).ToString(inv),
                BitConverter.DoubleToInt64Bits(r.StartSeconds).ToString(inv), BitConverter.DoubleToInt64Bits(r.EndSeconds).ToString(inv),
                r.IncludeEndKey ? "1" : "0", BitConverter.DoubleToInt64Bits(r.IntervalSeconds).ToString(inv),
                r.Count.ToString(inv), ((int)r.Policy).ToString(inv), r.SnapToFrames ? "1" : "0",
                _invalidation.ToString(inv), curves);
        }

        /// <summary>ModuleState に保存するキーの一覧(テストの後片付け用)。</summary>
        internal static IEnumerable<string> StateKeys()
        {
            return new[] { ClipKey, StartKey, EndKey, IncludeEndStateKey, CountKey, AllCurvesKey, CurvesKey, PolicyKey, SnapKey }
                .Concat(BeatInterval.StateKeys(IntervalPrefix));
        }
    }
}
