using System;
using ParticleLiveToolkit.Core;

namespace ParticleLiveToolkit.Modules.AnimationRepeat
{
    /// <summary>
    /// 表示用の秒数の書式化。BeatMath.FormatSeconds は NaN・無限大・decimal に入らない極端な値で例外を投げるため、
    /// このモジュールでは必ずここを通し、表示できない値は "-" にする(OnGUI から例外を出さない)。
    /// </summary>
    internal static class SecondsText
    {
        /// <summary>これより絶対値が大きい値は表示しない("-")。</summary>
        const double DisplayLimit = 1e12;

        public static string Format(double seconds, int decimals = 6)
        {
            if (double.IsNaN(seconds) || double.IsInfinity(seconds) || Math.Abs(seconds) > DisplayLimit) return "-";
            try
            {
                return BeatMath.FormatSeconds(seconds, decimals);
            }
            catch (ArgumentException)
            {
                return "-";
            }
            catch (OverflowException)
            {
                return "-";
            }
        }
    }
}
