using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;
using UnityEngine.Timeline;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    internal static class SceneSetup
    {
        internal static void Save(Scene scene, GenerationPaths paths)
        {
            if (!EditorSceneManager.SaveScene(scene, paths.LiveFolder + "/" + paths.LiveName + ".unity"))
                throw new InvalidOperationException("新規シーンを保存できません。");
        }

        internal static void Configure(GenerationPaths paths, Animator animator,
            AudioSource audio, AnimationClip clip, Transform anchor)
        {
            var shader = Shader.Find("Skybox/Procedural");
            if (!shader) throw new InvalidOperationException("Skybox/Procedural が見つかりません。");
            var sky = new Material(shader);
            sky.SetFloat("_Exposure", 0f);
            sky.SetColor("_GroundColor", Color.black);
            sky.SetColor("_SkyTint", Color.black);
            AssetDatabase.CreateAsset(sky, paths.LiveFolder + "/BlackSkybox.mat");
            RenderSettings.skybox = sky;

            if (anchor)
            {
                var cameraObject = new GameObject("Preview Camera");
                cameraObject.tag = "EditorOnly";
                cameraObject.transform.SetParent(anchor, false);
                cameraObject.transform.localPosition = Vector3.up * LiveProjectGenerator.DefaultEyeHeight;
                cameraObject.AddComponent<Camera>().enabled = false;
            }

            var timeline = ScriptableObject.CreateInstance<TimelineAsset>();
            timeline.editorSettings.frameRate = clip.frameRate;
            AssetDatabase.CreateAsset(timeline, paths.AnimationsFolder + "/" + paths.LiveName + ".playable");
            // Both editor windows now resolve the same Animation root. Exclude only the
            // authoring Director from builds, so the runtime Animator and effects survive.
            var director = animator.gameObject.AddComponent<PlayableDirector>();
            director.hideFlags |= HideFlags.DontSaveInBuild;
            director.playOnAwake = false;
            director.playableAsset = timeline;
            var animationTrack = timeline.CreateTrack<AnimationTrack>(null, "演出");
            var animation = animationTrack.CreateClip(clip);
            animation.start = 0;
            animation.duration = Math.Max(1.0 / clip.frameRate, clip.length);
            director.SetGenericBinding(animationTrack, animator);
            var audioTrack = timeline.CreateTrack<AudioTrack>(null, "楽曲");
            director.SetGenericBinding(audioTrack, audio);
            if (audio.clip)
            {
                var music = audioTrack.CreateClip<AudioPlayableAsset>();
                ((AudioPlayableAsset)music.asset).clip = audio.clip;
                music.start = 0;
                music.duration = audio.clip.length;
                music.displayName = audio.clip.name;
                EditorUtility.SetDirty(music.asset);
            }
            EditorUtility.SetDirty(timeline);
            EditorUtility.SetDirty(director);
        }

        internal sealed class SongImport
        {
            private readonly string path;
            private bool background;
            private AudioImporterSampleSettings original;
            private bool changed;

            internal SongImport(AudioClip song)
            {
                path = song ? AssetDatabase.GetAssetPath(song) : null;
            }

            internal void Enable()
            {
                if (string.IsNullOrEmpty(path)) return;
                var importer = AssetImporter.GetAtPath(path) as AudioImporter;
                if (!importer) throw new InvalidOperationException("音源のインポート設定を変更できません。");
                original = importer.defaultSampleSettings;
                background = importer.loadInBackground;
                if (background && original.preloadAudioData) return;
                var settings = original;
                settings.preloadAudioData = true;
                changed = true;
                importer.defaultSampleSettings = settings;
                importer.loadInBackground = true;
                importer.SaveAndReimport();
            }

            internal void Restore()
            {
                if (!changed) return;
                var importer = (AudioImporter)AssetImporter.GetAtPath(path);
                importer.defaultSampleSettings = original;
                importer.loadInBackground = background;
                importer.SaveAndReimport();
            }
        }
    }
}
