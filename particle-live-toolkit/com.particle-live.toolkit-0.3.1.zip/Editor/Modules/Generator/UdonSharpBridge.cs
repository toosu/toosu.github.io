using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>VRChat Worlds SDK / UdonSharp の検出結果。</summary>
    public sealed class PlayerSupport
    {
        /// <summary>VRChat Worlds SDK(VRC.Udon.UdonBehaviour / VRC.SDKBase.Networking)が見つかった。</summary>
        public bool HasWorldsSdk;

        /// <summary>UdonSharp(実行時と Editor の両方)が見つかった。</summary>
        public bool HasUdonSharp;

        /// <summary>自動取り付けに使うメンバーがすべて見つかった。</summary>
        public bool CanAutoAttach;

        /// <summary>画面に出す説明。</summary>
        public string Summary = "";

        /// <summary>再生スクリプトを書き出せるか(SDK と UdonSharp の両方がある)。</summary>
        public bool CanWriteScript
        {
            get { return HasWorldsSdk && HasUdonSharp; }
        }

        /// <summary>SDK も UdonSharp も無い扱い(テストや手動手順のみにしたい場合)。</summary>
        public static PlayerSupport None()
        {
            return new PlayerSupport
            {
                Summary = "VRChat SDK - Worlds(UdonSharp)が見つかりません。Animator と AudioSource だけを作り、手動の手順を README_setup.txt に書き出します。",
            };
        }
    }

    /// <summary>
    /// UdonSharp / VRChat SDK へのリフレクションをこのクラスに閉じ込める(型を直接参照しない)。
    /// 使う公開メンバー(UdonSharp 1.x、VRChat SDK 3.10 で確認):
    ///  - UdonSharp.UdonSharpBehaviour(UdonSharp.Runtime)
    ///  - UdonSharp.UdonSharpProgramAsset.sourceCsScript(UdonSharp.Editor、public フィールド)
    ///  - UdonSharp.Compiler.UdonSharpCompilerV1.CompileSync(UdonSharpCompileOptions)
    ///  - UdonSharpEditor.UdonSharpUndo.AddComponent(GameObject, Type)
    ///  - UdonSharpEditor.UdonSharpEditorUtility.CopyProxyToUdon(UdonSharpBehaviour) / GetBackingUdonBehaviour(UdonSharpBehaviour)
    ///  - VRC.Udon.UdonBehaviour.programSource / publicVariables.TryGetVariableValue(string, out object)
    ///  - VRC.SDKBase.Networking(検出のみ)
    /// どれかが見つからない・例外が出た場合は「使えない」を返し、例外は外へ出さない。
    /// </summary>
    public static class UdonSharpBridge
    {
        internal const string UdonSharpBehaviourTypeName = "UdonSharp.UdonSharpBehaviour";
        internal const string ProgramAssetTypeName = "UdonSharp.UdonSharpProgramAsset";
        internal const string UndoTypeName = "UdonSharpEditor.UdonSharpUndo";
        internal const string EditorUtilityTypeName = "UdonSharpEditor.UdonSharpEditorUtility";
        internal const string CompilerTypeName = "UdonSharp.Compiler.UdonSharpCompilerV1";
        internal const string CompileOptionsTypeName = "UdonSharp.Compiler.UdonSharpCompileOptions";
        internal const string UdonBehaviourTypeName = "VRC.Udon.UdonBehaviour";
        internal const string NetworkingTypeName = "VRC.SDKBase.Networking";

        /// <summary>SDK / UdonSharp の有無を調べる。例外は出さない。</summary>
        public static PlayerSupport Detect()
        {
            try
            {
                var support = new PlayerSupport
                {
                    HasWorldsSdk = FindType(UdonBehaviourTypeName) != null && FindType(NetworkingTypeName) != null,
                    HasUdonSharp = FindType(UdonSharpBehaviourTypeName) != null && FindType(ProgramAssetTypeName) != null,
                };
                support.CanAutoAttach = support.CanWriteScript && ResolveAttachMembers(out _);
                if (!support.HasWorldsSdk || !support.HasUdonSharp)
                {
                    support.Summary = PlayerSupport.None().Summary;
                }
                else if (!support.CanAutoAttach)
                {
                    support.Summary = "VRChat SDK と UdonSharp は見つかりましたが、自動取り付けに使う機能が見つかりません。再生スクリプトを書き出し、取り付けの手順を README_setup.txt に書き出します。";
                }
                else
                {
                    support.Summary = "VRChat SDK と UdonSharp が見つかりました。再生スクリプトを書き出し、コンパイル後に System へ自動で取り付けます。";
                }
                return support;
            }
            catch (Exception)
            {
                return PlayerSupport.None();
            }
        }

        /// <summary>読み込み済みアセンブリから型を探す。無ければ null。</summary>
        internal static Type FindType(string fullName)
        {
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type;
                try
                {
                    type = assembly.GetType(fullName, false);
                }
                catch (Exception)
                {
                    continue;
                }
                if (type != null) return type;
            }
            return null;
        }

        private sealed class AttachMembers
        {
            public Type UdonSharpBehaviour;
            public Type ProgramAsset;
            public FieldInfo SourceCsScript;
            public MethodInfo AddComponent;
            public MethodInfo CopyProxyToUdon;
            public MethodInfo GetBackingUdonBehaviour;
            public MethodInfo CompileSync;
        }

        private static bool ResolveAttachMembers(out AttachMembers members)
        {
            members = null;
            try
            {
                Type usb = FindType(UdonSharpBehaviourTypeName);
                Type programAsset = FindType(ProgramAssetTypeName);
                Type undo = FindType(UndoTypeName);
                Type util = FindType(EditorUtilityTypeName);
                if (usb == null || programAsset == null || undo == null || util == null) return false;

                const BindingFlags PublicStatic = BindingFlags.Public | BindingFlags.Static;
                var m = new AttachMembers
                {
                    UdonSharpBehaviour = usb,
                    ProgramAsset = programAsset,
                    SourceCsScript = programAsset.GetField("sourceCsScript", BindingFlags.Public | BindingFlags.Instance),
                    AddComponent = undo.GetMethod("AddComponent", PublicStatic, null, new[] { typeof(GameObject), typeof(Type) }, null),
                    CopyProxyToUdon = util.GetMethod("CopyProxyToUdon", PublicStatic, null, new[] { usb }, null),
                    GetBackingUdonBehaviour = util.GetMethod("GetBackingUdonBehaviour", PublicStatic, null, new[] { usb }, null),
                };
                Type compiler = FindType(CompilerTypeName);
                Type options = FindType(CompileOptionsTypeName);
                if (compiler != null && options != null)
                {
                    m.CompileSync = compiler.GetMethod("CompileSync", PublicStatic, null, new[] { options }, null);
                }
                if (m.SourceCsScript == null || m.SourceCsScript.FieldType != typeof(MonoScript)) return false;
                if (m.AddComponent == null || m.CopyProxyToUdon == null || m.GetBackingUdonBehaviour == null) return false;
                members = m;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>script が UdonSharpBehaviour の具象サブクラスを定義しているか(コンパイル済みであること)。</summary>
        internal static bool IsUdonSharpBehaviourScript(MonoScript script)
        {
            try
            {
                Type usb = FindType(UdonSharpBehaviourTypeName);
                Type cls = script != null ? script.GetClass() : null;
                return usb != null && cls != null && !cls.IsAbstract && usb.IsAssignableFrom(cls);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// プログラムアセットの作成・検索に要る型とフィールドだけを解決する(Undo / Utility の有無に左右されない)。
        /// </summary>
        private static bool ResolveProgramAssetMembers(out Type programAsset, out FieldInfo sourceCsScript)
        {
            sourceCsScript = null;
            programAsset = FindType(ProgramAssetTypeName);
            if (programAsset == null) return false;
            try
            {
                sourceCsScript = programAsset.GetField("sourceCsScript", BindingFlags.Public | BindingFlags.Instance);
            }
            catch (Exception)
            {
                return false;
            }
            return sourceCsScript != null && sourceCsScript.FieldType == typeof(MonoScript);
        }

        /// <summary>script を参照している UdonSharpProgramAsset のパス。無ければ null。</summary>
        internal static string FindProgramAssetPath(MonoScript script)
        {
            if (script == null) return null;
            try
            {
                if (!ResolveProgramAssetMembers(out Type programAsset, out FieldInfo source)) return null;
                foreach (string guid in AssetDatabase.FindAssets("t:" + programAsset.Name))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    Object asset = AssetDatabase.LoadAssetAtPath(path, programAsset);
                    if (asset == null) continue;
                    var value = source.GetValue(asset) as MonoScript;
                    if (value != null && value == script) return path;
                }
            }
            catch (Exception)
            {
                // 見つからない扱い
            }
            return null;
        }

        /// <summary>
        /// script 用の UdonSharpProgramAsset を用意する(UdonSharp の「Create &gt; U# Script」と同じ手順)。
        /// script を参照するプログラムアセットが既にあればそのパスを返す(created = false)。
        /// 無ければ assetPath に作る(created = true)。assetPath に既に何かある場合は上書きせず、null と理由を返す。
        /// </summary>
        internal static string EnsureProgramAsset(MonoScript script, string assetPath, out bool created, out string error)
        {
            created = false;
            error = null;
            try
            {
                string existing = FindProgramAssetPath(script);
                if (existing != null) return existing;
                if (File.Exists(assetPath) || AssetDatabase.LoadMainAssetAtPath(assetPath) != null)
                {
                    error = assetPath + " に既に別のファイルがあるため、U# プログラムアセットを作りませんでした";
                    return null;
                }
                if (!ResolveProgramAssetMembers(out Type programAsset, out FieldInfo source))
                {
                    error = "UdonSharp のプログラムアセットを作る機能が見つかりません";
                    return null;
                }
                var asset = ScriptableObject.CreateInstance(programAsset);
                source.SetValue(asset, script);
                AssetDatabase.CreateAsset(asset, assetPath);
                created = true;
                return assetPath;
            }
            catch (Exception e)
            {
                error = "UdonSharp のプログラムアセットを作れませんでした: " + Unwrap(e).Message;
                return null;
            }
        }

        /// <summary>
        /// プログラムアセットと、UdonSharp がそれ用に自動で作る Assets/SerializedUdonPrograms/&lt;GUID&gt;.asset を消す(片付け用)。
        /// </summary>
        internal static void DeleteProgramAsset(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return;
            string guid = AssetDatabase.AssetPathToGUID(assetPath);
            if (!string.IsNullOrEmpty(guid))
            {
                string serialized = "Assets/SerializedUdonPrograms/" + guid + ".asset";
                if (File.Exists(serialized)) AssetDatabase.DeleteAsset(serialized);
            }
            if (File.Exists(assetPath)) AssetDatabase.DeleteAsset(assetPath);
        }

        /// <summary>
        /// system に script の UdonSharpBehaviour を(Undo 可能に)取り付け、public フィールドに参照を入れる。
        /// 既に同じ型が付いていればそれを使う。成功したら true。失敗の理由は error。
        /// fieldValues は「フィールド名 → 値」の組(偶数個: name, value, name, value...)。
        /// </summary>
        internal static bool AttachBehaviour(GameObject system, MonoScript script, out string error, params object[] fieldValues)
        {
            error = null;
            try
            {
                if (system == null)
                {
                    error = "取り付け先のオブジェクトが見つかりません";
                    return false;
                }
                if (!ResolveAttachMembers(out AttachMembers m))
                {
                    error = "UdonSharp の取り付け機能が見つかりません";
                    return false;
                }
                Type cls = script != null ? script.GetClass() : null;
                if (cls == null || cls.IsAbstract || !m.UdonSharpBehaviour.IsAssignableFrom(cls))
                {
                    error = "再生スクリプトがまだコンパイルされていないか、UdonSharpBehaviour ではありません";
                    return false;
                }

                // U# のコンパイルを済ませてから付ける(プログラムが未コンパイルのままだと取り付け直後に警告が出るため)。
                if (m.CompileSync != null)
                {
                    m.CompileSync.Invoke(null, new object[] { null });
                }

                Component proxy = system.GetComponent(cls);
                if (proxy == null)
                {
                    proxy = m.AddComponent.Invoke(null, new object[] { system, cls }) as Component;
                }
                if (proxy == null)
                {
                    error = "UdonSharpBehaviour を追加できませんでした";
                    return false;
                }

                Undo.RecordObject(proxy, "再生スクリプトの設定");
                for (int i = 0; i + 1 < fieldValues.Length; i += 2)
                {
                    string fieldName = fieldValues[i] as string;
                    FieldInfo field = fieldName != null ? cls.GetField(fieldName, BindingFlags.Public | BindingFlags.Instance) : null;
                    if (field == null)
                    {
                        error = "再生スクリプトにフィールド " + fieldName + " がありません";
                        return false;
                    }
                    field.SetValue(proxy, fieldValues[i + 1]);
                }
                m.CopyProxyToUdon.Invoke(null, new object[] { proxy });

                var backing = m.GetBackingUdonBehaviour.Invoke(null, new object[] { proxy }) as Component;
                if (backing == null)
                {
                    error = "UdonBehaviour が作られませんでした";
                    return false;
                }
                if (!HasProgramSource(backing))
                {
                    error = "UdonBehaviour に U# プログラムが設定されていません";
                    return false;
                }
                for (int i = 0; i + 1 < fieldValues.Length; i += 2)
                {
                    if (!PublicVariableEquals(backing, (string)fieldValues[i], fieldValues[i + 1] as Object))
                    {
                        error = "UdonBehaviour に " + fieldValues[i] + " の参照が入りませんでした";
                        return false;
                    }
                }
                EditorUtility.SetDirty(proxy);
                EditorUtility.SetDirty(backing);
                return true;
            }
            catch (Exception e)
            {
                error = "自動取り付けに失敗しました: " + Unwrap(e).Message;
                return false;
            }
        }

        /// <summary>UdonBehaviour.programSource が設定されているか。</summary>
        internal static bool HasProgramSource(Component udonBehaviour)
        {
            if (udonBehaviour == null) return false;
            object value = ReadMember(udonBehaviour, "programSource");
            return value is Object obj && obj != null;
        }

        /// <summary>UdonBehaviour.publicVariables の値が expected と同じオブジェクトか。</summary>
        internal static bool PublicVariableEquals(Component udonBehaviour, string symbol, Object expected)
        {
            try
            {
                object table = ReadMember(udonBehaviour, "publicVariables");
                if (table == null) return false;
                MethodInfo tryGet = FindTryGetVariableValue(table.GetType());
                if (tryGet == null) return false;
                object[] args = { symbol, null };
                bool found = (bool)tryGet.Invoke(table, args);
                return found && args[1] is Object actual && actual == expected;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// public なインスタンスメンバーを、フィールド → プロパティの順に読む(SDK 3.10 ではどちらもフィールド)。
        /// 見つからなければ null。
        /// </summary>
        internal static object ReadMember(object target, string name)
        {
            if (target == null) return null;
            try
            {
                Type type = target.GetType();
                const BindingFlags Flags = BindingFlags.Public | BindingFlags.Instance;
                FieldInfo field = type.GetField(name, Flags);
                if (field != null) return field.GetValue(target);
                PropertyInfo prop = type.GetProperty(name, Flags);
                if (prop != null && prop.CanRead && prop.GetIndexParameters().Length == 0) return prop.GetValue(target);
            }
            catch (Exception)
            {
                // 読めない扱い
            }
            return null;
        }

        /// <summary>TryGetVariableValue(string, out object) を探す(ジェネリック版は除く)。無ければ null。</summary>
        private static MethodInfo FindTryGetVariableValue(Type tableType)
        {
            var candidates = new System.Collections.Generic.List<Type> { tableType };
            candidates.AddRange(tableType.GetInterfaces());
            foreach (Type t in candidates)
            {
                foreach (MethodInfo method in t.GetMethods(BindingFlags.Public | BindingFlags.Instance))
                {
                    if (method.Name != "TryGetVariableValue" || method.IsGenericMethodDefinition) continue;
                    ParameterInfo[] ps = method.GetParameters();
                    if (ps.Length == 2 && ps[0].ParameterType == typeof(string) && ps[1].ParameterType == typeof(object).MakeByRefType())
                        return method;
                }
            }
            return null;
        }

        private static Exception Unwrap(Exception e)
        {
            while (e is TargetInvocationException && e.InnerException != null) e = e.InnerException;
            return e;
        }
    }
}
