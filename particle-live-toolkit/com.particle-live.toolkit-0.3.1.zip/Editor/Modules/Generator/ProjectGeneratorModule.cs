using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>Project Generator(新しいライブの一式を作る)の画面。入力と描画だけを持ち、生成は LiveProjectGenerator に任せる。</summary>
    public sealed class ProjectGeneratorModule : IToolkitModule
    {
        private const string NameKey = "Name";
        private const string BpmKey = "Bpm";
        private const string FolderKey = "Folder";
        private const string SongKey = "SongGuid";
        private const string TemplateKey = "TemplateGuid";

        /// <summary>入力が変わらなくても、この秒数ごとに検証(フォルダやシーンの状態)をやり直す。</summary>
        private const double RevalidateSeconds = 1.0;

        private PlayerSupport _support;
        private Vector2 _scroll;

        // 検証とプレビューは入力が変わったとき(または一定時間ごと)だけ計算し直す。
        private ProjectTemplate _defaultTemplate;
        private string _cacheKey;
        private double _cacheTime;
        private string _cachedReason;
        private List<string> _cachedPlan = new List<string>();

        public string Id
        {
            get { return ToolkitModuleIds.Project; }
        }

        public string DisplayName
        {
            get { return "Project"; }
        }

        public int Order
        {
            get { return ToolkitModuleIds.ProjectOrder; }
        }

        public void OnEnable(ToolkitContext ctx)
        {
            _support = UdonSharpBridge.Detect();
        }

        public void OnDisable()
        {
            if (_defaultTemplate != null) Object.DestroyImmediate(_defaultTemplate);
            _defaultTemplate = null;
            _cacheKey = null;
        }

        public void OnGUI(ToolkitContext ctx)
        {
            ModuleState state = ctx.State(Id);
            if (_support == null) _support = UdonSharpBridge.Detect();

            ProjectGenerationRequest request = ReadRequest(state, ctx);

            _scroll = EditorGUILayout.BeginScrollView(_scroll);

            ToolkitGUI.Section("新しいライブ");
            EditorGUI.BeginChangeCheck();
            request.liveName = EditorGUILayout.TextField("ライブ名", request.liveName);
            request.bpm = EditorGUILayout.DoubleField("BPM", request.bpm);
            request.song = (AudioClip)EditorGUILayout.ObjectField("楽曲(任意)", request.song, typeof(AudioClip), false);
            using (new EditorGUILayout.HorizontalScope())
            {
                request.outputFolder = EditorGUILayout.TextField("出力先フォルダ", request.outputFolder);
                if (GUILayout.Button("選ぶ…", GUILayout.Width(56f)))
                {
                    string picked = PickFolder(request.outputFolder);
                    if (picked != null) request.outputFolder = picked;
                    // モーダルのダイアログを開いたあとは IMGUI のレイアウトが崩れるので、保存して描画をやり直す。
                    WriteRequest(state, request);
                    GUIUtility.ExitGUI();
                }
            }
            request.template = (ProjectTemplate)EditorGUILayout.ObjectField("構成テンプレート", request.template, typeof(ProjectTemplate), false);
            if (request.template == null)
            {
                EditorGUILayout.LabelField(" ", "空欄なら既定の構成を使います", EditorStyles.miniLabel);
            }
            if (EditorGUI.EndChangeCheck())
            {
                WriteRequest(state, request);
            }

            ToolkitGUI.Section("再生の仕組み");
            if (_support.CanAutoAttach)
            {
                ToolkitGUI.Hint(_support.Summary);
            }
            else
            {
                ToolkitGUI.Warning(_support.Summary);
            }
            if (PlayerSetup.HasPendingAttach)
            {
                ToolkitGUI.Hint("再生スクリプトのコンパイル待ちです。終わると System に自動で取り付けます。");
            }

            RefreshCache(state, request);

            ToolkitGUI.Section("作られるもの");
            List<string> plan = _cachedPlan;
            if (plan.Count == 0)
            {
                ToolkitGUI.Warning("テンプレートに問題があるため、作られるものを表示できません。");
            }
            else
            {
                EditorGUILayout.HelpBox(string.Join("\n", plan), MessageType.None);
            }

            // Play Mode / コンパイル中 / 取り付け待ちは毎回見る(安い判定なので)。
            string reason = ProjectGenerationValidator.EditorBusyReason() ?? _cachedReason;
            if (ToolkitGUI.PrimaryButton("ライブを生成", reason))
            {
                Generate(ctx, state, request);
            }

            string last = state.GetString(PlayerSetup.ResultStateKey, "");
            if (!string.IsNullOrEmpty(last))
            {
                ToolkitGUI.Section("結果");
                EditorGUILayout.HelpBox(last, MessageType.None);
                if (GUILayout.Button("結果を消す", GUILayout.Width(96f)))
                {
                    state.SetString(PlayerSetup.ResultStateKey, null);
                }
            }

            EditorGUILayout.EndScrollView();
        }

        /// <summary>
        /// 入力(またはエディタの状態)が変わったとき、または一定時間たったときだけ、検証とプレビューを計算し直す。
        /// 計算は Layout イベントでだけ行い、Repaint とで描く内容がずれないようにする。
        /// </summary>
        private void RefreshCache(ModuleState state, ProjectGenerationRequest request)
        {
            if (Event.current != null && Event.current.type != EventType.Layout && _cacheKey != null) return;

            string key = string.Join("|", new[]
            {
                request.liveName ?? "",
                request.bpm.ToString("R", System.Globalization.CultureInfo.InvariantCulture),
                request.outputFolder ?? "",
                state.GetString(SongKey, ""),
                state.GetString(TemplateKey, ""),
                request.template != null ? EditorUtility.GetDirtyCount(request.template).ToString() : "-",
                _support.CanWriteScript.ToString(),
                ProjectGenerationValidator.EditorBusyReason() ?? "",
            });
            double now = EditorApplication.timeSinceStartup;
            if (key == _cacheKey && now - _cacheTime < RevalidateSeconds) return;
            _cacheKey = key;
            _cacheTime = now;

            if (_defaultTemplate == null) _defaultTemplate = ProjectTemplate.CreateDefault();
            ProjectTemplate template = request.template != null ? request.template : _defaultTemplate;
            List<string> errors = ProjectGenerationValidator.Validate(request, template, out _);
            _cachedReason = errors.Count > 0 ? errors[0] : null;
            _cachedPlan = LiveProjectGenerator.DescribePlan(request, _support);
        }

        private void Generate(ToolkitContext ctx, ModuleState state, ProjectGenerationRequest request)
        {
            _support = UdonSharpBridge.Detect();
            for (int i = 0; i < UnityEngine.SceneManagement.SceneManager.sceneCount; i++)
            {
                var scene = UnityEngine.SceneManagement.SceneManager.GetSceneAt(i);
                if (scene.isLoaded && string.IsNullOrEmpty(scene.path) && scene.isDirty &&
                    !UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene))
                {
                    ctx.ShowNotification("現在の未保存シーンを保持して Setup を中止しました");
                    return;
                }
            }
            GenerationResult result = LiveProjectGenerator.Generate(request, ctx, _support);
            var lines = new List<string>();
            if (result.Success)
            {
                lines.Add("「" + request.liveName + "」を作りました。");
                foreach (string created in result.Created) lines.Add("・" + created);
                if (!string.IsNullOrEmpty(result.PlayerDetail)) lines.Add(result.PlayerDetail);
                lines.Add("編集用 Timeline の演出クリップをダブルクリックして編集します。楽曲付き再生は Timeline の再生ボタンを使います。");
                ctx.ShowNotification("ライブを生成しました");
                // Work in the newly generated scene. Keep any scene with unsaved edits open.
                for (int i = UnityEngine.SceneManagement.SceneManager.sceneCount - 1; i >= 0; i--)
                {
                    var other = UnityEngine.SceneManagement.SceneManager.GetSceneAt(i);
                    if (other != result.Root.scene && other.isLoaded && !other.isDirty)
                        UnityEditor.SceneManagement.EditorSceneManager.CloseScene(other, true);
                }
                var director = result.Root.GetComponentInChildren<UnityEngine.Playables.PlayableDirector>(true);
                if (director)
                {
                    Selection.activeGameObject = director.gameObject;
                    EditorApplication.ExecuteMenuItem("Window/Sequencing/Timeline");
                }
                state.SetString(NameKey, "");
            }
            else
            {
                lines.Add("生成できませんでした。");
                foreach (string error in result.Errors) lines.Add("・" + error);
                ctx.ShowNotification("生成できませんでした");
            }
            state.SetString(PlayerSetup.ResultStateKey, string.Join("\n", lines));
            _cacheKey = null;
            GUIUtility.ExitGUI();
        }

        private static string PickFolder(string current)
        {
            string start = string.IsNullOrEmpty(current) ? "Assets" : current;
            string absolute = EditorUtility.OpenFolderPanel("出力先フォルダ", start, "");
            if (string.IsNullOrEmpty(absolute)) return null;
            string projectRoot = System.IO.Path.GetFullPath(System.IO.Path.Combine(Application.dataPath, "..")).Replace('\\', '/').TrimEnd('/');
            string normalized = absolute.Replace('\\', '/').TrimEnd('/');
            if (normalized.StartsWith(projectRoot + "/", System.StringComparison.OrdinalIgnoreCase))
            {
                return normalized.Substring(projectRoot.Length + 1);
            }
            // プロジェクト外が選ばれた場合はそのまま入れ、検証で理由を見せる。
            return normalized;
        }

        private static ProjectGenerationRequest ReadRequest(ModuleState state, ToolkitContext ctx)
        {
            var request = new ProjectGenerationRequest
            {
                liveName = state.GetString(NameKey, ""),
                bpm = state.GetDouble(BpmKey, ctx.Bpm),
                outputFolder = state.GetString(FolderKey, ProjectGenerationRequest.DefaultOutputFolder),
                song = LoadByGuid<AudioClip>(state.GetString(SongKey, "")),
                template = LoadByGuid<ProjectTemplate>(state.GetString(TemplateKey, "")),
            };
            return request;
        }

        private static void WriteRequest(ModuleState state, ProjectGenerationRequest request)
        {
            state.SetString(NameKey, request.liveName ?? "");
            state.SetDouble(BpmKey, request.bpm);
            state.SetString(FolderKey, request.outputFolder ?? "");
            state.SetString(SongKey, GuidOf(request.song));
            state.SetString(TemplateKey, GuidOf(request.template));
        }

        private static string GuidOf(Object asset)
        {
            if (asset == null) return "";
            return AssetDatabase.TryGetGUIDAndLocalFileIdentifier(asset, out string guid, out long _) ? guid : "";
        }

        private static T LoadByGuid<T>(string guid) where T : Object
        {
            if (string.IsNullOrEmpty(guid)) return null;
            string path = AssetDatabase.GUIDToAssetPath(guid);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<T>(path);
        }
    }
}
