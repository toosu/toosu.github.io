using System;
using System.Collections.Generic;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>シーン階層のノードの役割。役割によって付けるコンポーネントが決まる。</summary>
    public enum SceneNodeRole
    {
        /// <summary>空のオブジェクト(まとめ用)。</summary>
        Empty = 0,

        /// <summary>楽曲の AudioSource を付ける(必須・1 つだけ)。</summary>
        Music = 1,

        /// <summary>演出の Animator を付ける(必須・1 つだけ)。</summary>
        Animation = 2,

        /// <summary>観客視点の目印。プロジェクト設定の視点がこのノードを指す(0 か 1 つ)。</summary>
        Viewpoint = 3,

        /// <summary>再生制御。再生スクリプトを取り付ける(0 か 1 つ)。</summary>
        System = 4,
    }

    /// <summary>シーン階層の 1 ノード。path はライブルートからの相対パス("Cameras/Viewpoint_Default")。</summary>
    [Serializable]
    public sealed class TemplateNode
    {
        [Tooltip("ライブルートからの相対パス。親ノードも一覧に入れてください")]
        public string path = "";

        public SceneNodeRole role = SceneNodeRole.Empty;

        public Vector3 localPosition = Vector3.zero;

        public Vector3 localEulerAngles = Vector3.zero;

        public TemplateNode()
        {
        }

        public TemplateNode(string path, SceneNodeRole role)
        {
            this.path = path;
            this.role = role;
        }
    }

    /// <summary>
    /// Project Generator が作るフォルダとシーン階層の構成。アセットとして自作すれば構成を差し替えられる。
    /// 何も指定しなければ CreateDefault() の構成(spec 6 章①)を使う。
    /// </summary>
    [CreateAssetMenu(menuName = "Particle Live/Project Template", fileName = "ParticleLiveProjectTemplate")]
    public sealed class ProjectTemplate : ScriptableObject
    {
        public const string DefaultAnimationsFolder = "Animations";
        public const string DefaultScriptsFolder = "Scripts";
        public const string DefaultViewpointPath = "Cameras/Viewpoint_Default";

        [Tooltip("ライブのフォルダの中に作るフォルダ(\"/\" 区切りで入れ子も可)")]
        public List<string> folders = DefaultFolders();

        [Tooltip("<名>_Main.anim と <名>.controller を置くフォルダ(folders に無ければ追加で作ります)")]
        public string animationsFolder = DefaultAnimationsFolder;

        [Tooltip("再生スクリプトを置くフォルダ(folders に無ければ必要なときだけ作ります)")]
        public string scriptsFolder = DefaultScriptsFolder;

        [Tooltip("ライブルートの下に作るオブジェクト")]
        public List<TemplateNode> nodes = DefaultNodes();

        /// <summary>
        /// spec 6 章①の既定構成を持つ一時インスタンスを作る(アセットファイルには依存しない)。
        /// フィールドの初期値も同じ構成なので、Create メニューで作ったテンプレートもこの構成から編集を始められる。
        /// </summary>
        public static ProjectTemplate CreateDefault()
        {
            var template = CreateInstance<ProjectTemplate>();
            template.name = "既定の構成";
            template.hideFlags = HideFlags.DontSave;
            template.folders = DefaultFolders();
            template.animationsFolder = DefaultAnimationsFolder;
            template.scriptsFolder = DefaultScriptsFolder;
            template.nodes = DefaultNodes();
            return template;
        }

        private static List<string> DefaultFolders()
        {
            return new List<string> { DefaultAnimationsFolder, "Audio", "Materials", "Prefabs", DefaultScriptsFolder };
        }

        private static List<TemplateNode> DefaultNodes()
        {
            return new List<TemplateNode>
            {
                new TemplateNode("Music", SceneNodeRole.Music),
                new TemplateNode("Animation", SceneNodeRole.Animation),
                new TemplateNode("Animation/Effects", SceneNodeRole.Empty),
                new TemplateNode("Cameras", SceneNodeRole.Empty),
                // 観客視点はステージ(原点)の 10m 手前から +Z 方向を見る位置に置く。
                new TemplateNode(DefaultViewpointPath, SceneNodeRole.Viewpoint) { localPosition = new Vector3(0f, 0f, -10f) },
                new TemplateNode("System", SceneNodeRole.System),
            };
        }
    }
}
