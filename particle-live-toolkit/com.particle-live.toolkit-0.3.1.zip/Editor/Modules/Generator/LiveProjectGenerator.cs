using System;
using System.Collections.Generic;
using System.IO;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>生成の結果。</summary>
    public sealed class GenerationResult
    {
        public bool Success;

        /// <summary>失敗の理由(検証で落ちた理由、または生成中の例外)。成功時は空。</summary>
        public List<string> Errors = new List<string>();

        public GenerationPaths Paths;
        public ParticleLiveProject Project;
        public GameObject Root;
        public PlayerSetupStage PlayerStage;

        /// <summary>再生の仕組みについての説明(画面表示用)。</summary>
        public string PlayerDetail = "";

        /// <summary>書き出した再生スクリプトのパス。書き出さなかった場合は null。</summary>
        public string WrittenScriptPath;

        /// <summary>作ったもの(画面表示用、1 行 1 件)。</summary>
        public List<string> Created = new List<string>();

        internal static GenerationResult Fail(IEnumerable<string> errors)
        {
            var result = new GenerationResult();
            result.Errors.AddRange(errors);
            return result;
        }
    }

    internal static class GeneratorFolders
    {
        /// <summary>
        /// "Assets/A/B" のようなフォルダを親から順に作る。新しく作ったフォルダを created に追加する(null 可)。
        /// AssetDatabase に無くてもディスクに既にあるフォルダは、取り込むだけで created に入れない。
        /// </summary>
        internal static void CreateFolderRecursive(string folder, List<string> created)
        {
            string[] segments = folder.Split('/');
            string current = segments[0];
            for (int i = 1; i < segments.Length; i++)
            {
                string next = current + "/" + segments[i];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    if (Directory.Exists(next))
                    {
                        // ディスクには前からある(未インポート)フォルダ。取り込むだけで「作った」扱いにしない。
                        AssetDatabase.ImportAsset(next, ImportAssetOptions.ForceSynchronousImport);
                        if (!AssetDatabase.IsValidFolder(next))
                            throw new InvalidOperationException("フォルダ " + next + " を取り込めませんでした");
                        current = next;
                        continue;
                    }
                    string guid = AssetDatabase.CreateFolder(current, segments[i]);
                    if (string.IsNullOrEmpty(guid) || !AssetDatabase.IsValidFolder(next))
                        throw new InvalidOperationException("フォルダ " + next + " を作れませんでした");
                    created?.Add(next);
                }
                current = next;
            }
        }
    }

    /// <summary>
    /// 新しいパーティクルライブのフォルダ・アセット・シーン階層・再生の仕組みを一括で作る(UI なし)。
    /// 検証に落ちたら何も書かない。途中で例外が出たら作りかけを片付けて失敗を返す。
    /// </summary>
    public static class LiveProjectGenerator
    {
        /// <summary>
        /// テスト用: 生成の各段階の直後に段階名で呼ばれる。例外を投げると途中失敗を再現できる。
        /// </summary>
        internal static Action<string> FaultInjection;

        internal static readonly string[] Steps = { "folders", "clip", "controller", "project", "scene", "player" };

        /// <summary>Animator のパラメータ名(楽曲の経過秒。メインクリップの長さを楽曲に合わせるために使う)。</summary>
        public const string SongTimeParameter = "SongTime";

        public const string MainStateName = "Main";
        public const float DefaultEyeHeight = 1.5f;

        /// <summary>SDK を実際に検出して生成する。</summary>
        public static GenerationResult Generate(ProjectGenerationRequest request, ToolkitContext ctx)
        {
            return Generate(request, ctx, UdonSharpBridge.Detect());
        }

        /// <summary>SDK の検出結果を指定して生成する(テストでは PlayerSupport.None() を渡す)。</summary>
        public static GenerationResult Generate(ProjectGenerationRequest request, ToolkitContext ctx, PlayerSupport support)
        {
            ProjectTemplate defaultTemplate = null;
            try
            {
                ProjectTemplate template = request != null ? request.template : null;
                if (template == null) template = defaultTemplate = ProjectTemplate.CreateDefault();

                List<string> errors = ProjectGenerationValidator.Validate(request, template, out GenerationPaths paths);
                if (errors.Count > 0) return GenerationResult.Fail(errors);
                return GenerateValidated(request, template, paths, ctx, support ?? PlayerSupport.None());
            }
            finally
            {
                if (defaultTemplate != null) Object.DestroyImmediate(defaultTemplate);
            }
        }

        /// <summary>これから作られるもの(プレビュー表示用)。検証に落ちる入力でも分かる範囲で返す。</summary>
        public static List<string> DescribePlan(ProjectGenerationRequest request, PlayerSupport support)
        {
            var lines = new List<string>();
            ProjectTemplate defaultTemplate = null;
            try
            {
                ProjectTemplate template = request.template;
                if (template == null) template = defaultTemplate = ProjectTemplate.CreateDefault();
                if (ProjectGenerationValidator.ValidateTemplate(template).Count > 0) return lines;
                string name = string.IsNullOrWhiteSpace(request.liveName) ? "<ライブ名>" : request.liveName;
                ProjectGenerationValidator.ValidateOutputFolder(request.outputFolder, out string parent);
                if (parent.Length == 0) parent = ProjectGenerationRequest.DefaultOutputFolder;
                GenerationPaths p = GenerationPaths.Build(name, parent, template);

                lines.Add(p.LiveFolder + "/");
                foreach (string folder in p.Folders) lines.Add("  " + folder.Substring(p.LiveFolder.Length + 1) + "/");
                lines.Add("  " + Relative(p, p.MainClipPath) + (request.song != null ? "(長さ = 楽曲 " + request.song.length.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + " 秒)" : "(空)"));
                lines.Add("  " + Relative(p, p.ControllerPath) + "(Main を再生する 1 ステート)");
                lines.Add("  " + Relative(p, p.ProjectAssetPath) + "(BPM " + request.bpm.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + ")");
                if (support != null && support.CanWriteScript)
                {
                    string scriptPath = PlayerSetup.ResolveScriptPath(p, out bool exists);
                    lines.Add("再生スクリプト(全ライブ共通): " + scriptPath + (exists ? "(既にあるものを使う)" : "(新しく書き出す)"));
                }
                else
                {
                    lines.Add("  " + PlayerSetup.ReadmeFileName + "(手動セットアップ手順。再生スクリプトの置き場所: " + p.SharedScriptPath + ")");
                }
                lines.Add("新規シーン: " + name + ".unity（未保存の変更があるシーンは保持）");
                lines.Add("黒い Skybox・観客カメラ・音楽と演出の Timeline");
                if (request.song) lines.Add("選択音源: Load In Background／Preload Audio Data を有効化");
                foreach (TemplateNode node in SortedNodes(template))
                {
                    string path = GenerationPaths.NormalizeRelative(node.path);
                    int depth = path.Split('/').Length;
                    string label = new string(' ', depth * 2) + path.Substring(path.LastIndexOf('/') + 1);
                    string role = RoleLabel(node.role, support);
                    lines.Add(role.Length > 0 ? label + "  " + role : label);
                }
            }
            catch (Exception)
            {
                // プレビューは出せる範囲だけ
            }
            finally
            {
                if (defaultTemplate != null) Object.DestroyImmediate(defaultTemplate);
            }
            return lines;
        }

        private static string Relative(GenerationPaths p, string path)
        {
            return path.Substring(p.LiveFolder.Length + 1);
        }

        private static string RoleLabel(SceneNodeRole role, PlayerSupport support)
        {
            switch (role)
            {
                case SceneNodeRole.Music: return "AudioSource(楽曲、Play On Awake = オフ)";
                case SceneNodeRole.Animation: return "Animator(上の controller)";
                case SceneNodeRole.Viewpoint: return "観客視点の目印(視点の高さ 1.5m)";
                case SceneNodeRole.System:
                    return support != null && support.CanWriteScript ? "再生制御(" + PlayerSetup.PlayerClassName + ")" : "再生制御(README の手順で設定)";
                default: return "";
            }
        }

        /// <summary>親が先に来るよう深さ順(同じ深さは元の順)に並べる。</summary>
        private static List<TemplateNode> SortedNodes(ProjectTemplate template)
        {
            var list = new List<TemplateNode>(template.nodes ?? new List<TemplateNode>());
            var order = new Dictionary<TemplateNode, int>();
            for (int i = 0; i < list.Count; i++) order[list[i]] = i;
            list.Sort((a, b) =>
            {
                int da = GenerationPaths.NormalizeRelative(a.path).Split('/').Length;
                int db = GenerationPaths.NormalizeRelative(b.path).Split('/').Length;
                return da != db ? da.CompareTo(db) : order[a].CompareTo(order[b]);
            });
            return list;
        }

        private static GenerationResult GenerateValidated(ProjectGenerationRequest request, ProjectTemplate template,
            GenerationPaths paths, ToolkitContext ctx, PlayerSupport support)
        {
            var createdFolders = new List<string>();
            var artifacts = new PlayerSetupArtifacts();
            GameObject root = null;
            var previousScene = SceneManager.GetActiveScene();
            Scene liveScene = default;
            var songImport = new SceneSetup.SongImport(request.song);
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("ライブを生成");

            try
            {
                var result = new GenerationResult { Paths = paths };

                // 1. フォルダ
                GeneratorFolders.CreateFolderRecursive(paths.LiveFolder, createdFolders);
                foreach (string folder in paths.Folders) GeneratorFolders.CreateFolderRecursive(folder, createdFolders);
                result.Created.Add(paths.LiveFolder + "/");
                Fault("folders");

                // 2. メインクリップ
                AnimationClip clip = CreateMainClip(request.song);
                AssetDatabase.CreateAsset(clip, paths.MainClipPath);
                result.Created.Add(paths.MainClipPath);
                Fault("clip");

                // 3. コントローラー
                AnimatorController controller = CreateController(paths.ControllerPath, clip, request.song != null);
                result.Created.Add(paths.ControllerPath);
                Fault("controller");

                // 4. プロジェクト設定
                var project = ScriptableObject.CreateInstance<ParticleLiveProject>();
                project.bpm = request.bpm;
                project.song = request.song;
                project.mainClip = clip;
                project.viewpoints = new List<Viewpoint>();
                AssetDatabase.CreateAsset(project, paths.ProjectAssetPath);
                result.Created.Add(paths.ProjectAssetPath);
                Fault("project");

                // 5. シーン階層
                // Unity rejects additive creation beside an untitled scene. A pristine initial
                // scene can be replaced; the UI first saves any edited untitled scene.
                bool initialScene = SceneManager.sceneCount == 1 && string.IsNullOrEmpty(previousScene.path) && !previousScene.isDirty;
                liveScene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, initialScene ? NewSceneMode.Single : NewSceneMode.Additive);
                SceneSetup.Save(liveScene, paths);
                if (SceneManager.GetActiveScene() != liveScene) SceneManager.SetActiveScene(liveScene);
                if (SceneManager.GetActiveScene() != liveScene) throw new InvalidOperationException("新規シーンを選択できません。");
                var nodeObjects = BuildHierarchy(paths.LiveName, template, request.song, controller, out root);
                Undo.RegisterCreatedObjectUndo(root, "ライブを生成");
                string musicPath = PathOfRole(template, SceneNodeRole.Music);
                string animationPath = PathOfRole(template, SceneNodeRole.Animation);
                string viewpointPath = PathOfRole(template, SceneNodeRole.Viewpoint);
                string systemPath = PathOfRole(template, SceneNodeRole.System);

                var viewpoint = new Viewpoint
                {
                    name = viewpointPath != null ? viewpointPath.Substring(viewpointPath.LastIndexOf('/') + 1) : "Viewpoint_Default",
                    anchorPath = viewpointPath ?? "",
                    eyeHeight = DefaultEyeHeight,
                };
                if (viewpointPath != null && nodeObjects.TryGetValue(viewpointPath, out GameObject vpObject))
                {
                    viewpoint.position = vpObject.transform.position;
                    viewpoint.eulerAngles = vpObject.transform.eulerAngles;
                }
                project.viewpoints.Add(viewpoint);
                EditorUtility.SetDirty(project);
                SceneSetup.Configure(paths, nodeObjects[animationPath].GetComponent<Animator>(),
                    nodeObjects[musicPath].GetComponent<AudioSource>(), clip,
                    viewpointPath != null ? nodeObjects[viewpointPath].transform : null);
                SceneSetup.Save(liveScene, paths);
                ProjectSceneUtility.SetRoot(project, root);
                EditorUtility.SetDirty(project);
                EditorSceneManager.MarkSceneDirty(root.scene);
                result.Created.Add("シーン: " + paths.LiveName + "(" + nodeObjects.Count + " 個の子オブジェクト)");
                Fault("scene");

                // 6. 再生の仕組み
                result.PlayerStage = PlayerSetup.Run(paths, support, root, systemPath, musicPath, animationPath,
                    artifacts, out string detail);
                result.PlayerDetail = detail;
                result.WrittenScriptPath = artifacts.WrittenScriptPath;
                if (artifacts.WrittenScriptPath != null) result.Created.Add(artifacts.WrittenScriptPath + "(全ライブ共通の再生スクリプト)");
                if (artifacts.CreatedProgramAssetPath != null) result.Created.Add(artifacts.CreatedProgramAssetPath + "(U# プログラム)");
                if (File.Exists(paths.ReadmePath)) result.Created.Add(paths.ReadmePath);
                Fault("player");

                songImport.Enable();
                SceneSetup.Save(liveScene, paths);
                result.Created.Add(liveScene.path);
                result.Created.Add("BlackSkybox.mat・編集用 Timeline（楽曲／演出トラック）");
                AssetDatabase.SaveAssets();
                Undo.CollapseUndoOperations(undoGroup);

                result.Success = true;
                result.Project = project;
                result.Root = root;
                ctx?.SetActiveProject(project);
                return result;
            }
            catch (Exception e)
            {
                try { songImport.Restore(); }
                finally
                {
                    if (liveScene.IsValid() && liveScene.isLoaded)
                    {
                        if (previousScene.IsValid() && previousScene.isLoaded)
                        {
                            SceneManager.SetActiveScene(previousScene);
                            EditorSceneManager.CloseScene(liveScene, true);
                        }
                        else EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
                    }
                    Cleanup(undoGroup, root, createdFolders, artifacts);
                }
                string message = e.Message;
                return GenerationResult.Fail(new[] { "生成の途中で失敗したため、作りかけを片付けました: " + message });
            }
        }

        private static void Fault(string step)
        {
            FaultInjection?.Invoke(step);
        }

        private static void Cleanup(int undoGroup, GameObject root, List<string> createdFolders, PlayerSetupArtifacts artifacts)
        {
            if (artifacts.Reserved) PlayerSetup.ClearPending();
            if (root != null)
            {
                // シーンへの記録がある場合だけ戻す(空のグループで戻すと利用者の直前の操作まで戻しかねない)。
                try
                {
                    Undo.CollapseUndoOperations(undoGroup);
                    Undo.RevertAllDownToGroup(undoGroup);
                }
                catch (Exception)
                {
                    // 下で直接消す
                }
                if (root != null) Object.DestroyImmediate(root);
            }

            // 今回作った共有の再生スクリプトとプログラムアセット(前からあったものは残す)。
            if (artifacts.CreatedProgramAssetPath != null) UdonSharpBridge.DeleteProgramAsset(artifacts.CreatedProgramAssetPath);
            if (artifacts.WrittenScriptPath != null && File.Exists(artifacts.WrittenScriptPath)) AssetDatabase.DeleteAsset(artifacts.WrittenScriptPath);
            for (int i = artifacts.CreatedFolders.Count - 1; i >= 0; i--)
            {
                if (AssetDatabase.IsValidFolder(artifacts.CreatedFolders[i])) AssetDatabase.DeleteAsset(artifacts.CreatedFolders[i]);
            }

            // 作ったフォルダを、深いもの(後に作ったもの)から消す。中のアセットも一緒に消える。
            for (int i = createdFolders.Count - 1; i >= 0; i--)
            {
                if (AssetDatabase.IsValidFolder(createdFolders[i])) AssetDatabase.DeleteAsset(createdFolders[i]);
            }
        }

        private static AnimationClip CreateMainClip(AudioClip song)
        {
            var clip = new AnimationClip();
            AnimationClipSettings settings = AnimationUtility.GetAnimationClipSettings(clip);
            settings.loopTime = false;
            AnimationUtility.SetAnimationClipSettings(clip, settings);

            if (song != null && song.length > 0f)
            {
                // 長さを楽曲に合わせるため、Animator パラメータ SongTime(楽曲の経過秒)を 0 → 曲の長さで直線に動かす。
                // コントローラーに同名の Float パラメータを用意するので、シーンの何にも影響しない。
                // 新規クリップの初期内容なので ClipEditSession(既存クリップの書き換え用)は使わない。
                float length = song.length;
                var curve = AnimationCurve.Linear(0f, 0f, length, length);
                clip.SetCurve("", typeof(Animator), SongTimeParameter, curve);
            }
            return clip;
        }

        private static AnimatorController CreateController(string path, AnimationClip clip, bool hasSongTime)
        {
            AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(path);
            if (controller == null) throw new InvalidOperationException("AnimatorController " + path + " を作れませんでした");
            if (hasSongTime) controller.AddParameter(SongTimeParameter, AnimatorControllerParameterType.Float);
            AnimatorStateMachine machine = controller.layers[0].stateMachine;
            AnimatorState state = machine.AddState(MainStateName);
            state.motion = clip;
            machine.defaultState = state;
            EditorUtility.SetDirty(controller);
            return controller;
        }

        private static string PathOfRole(ProjectTemplate template, SceneNodeRole role)
        {
            foreach (TemplateNode node in template.nodes)
            {
                if (node != null && node.role == role) return GenerationPaths.NormalizeRelative(node.path);
            }
            return null;
        }

        /// <summary>ライブルートと子ノードを作る(まだ Undo に登録しない)。ノードのパス → オブジェクト。</summary>
        private static Dictionary<string, GameObject> BuildHierarchy(string liveName, ProjectTemplate template,
            AudioClip song, AnimatorController controller, out GameObject root)
        {
            root = new GameObject(liveName);
            SceneManager.MoveGameObjectToScene(root, SceneManager.GetActiveScene());
            var map = new Dictionary<string, GameObject>(StringComparer.Ordinal);
            foreach (TemplateNode node in SortedNodes(template))
            {
                string path = GenerationPaths.NormalizeRelative(node.path);
                int slash = path.LastIndexOf('/');
                Transform parent = slash < 0 ? root.transform : map[path.Substring(0, slash)].transform;
                var go = new GameObject(path.Substring(slash + 1));
                go.transform.SetParent(parent, false);
                go.transform.localPosition = node.localPosition;
                go.transform.localEulerAngles = node.localEulerAngles;
                map.Add(path, go);

                switch (node.role)
                {
                    case SceneNodeRole.Music:
                        var audio = go.AddComponent<AudioSource>();
                        audio.clip = song;
                        audio.playOnAwake = false;
                        audio.loop = false;
                        break;
                    case SceneNodeRole.Animation:
                        var animator = go.AddComponent<Animator>();
                        animator.runtimeAnimatorController = controller;
                        animator.applyRootMotion = false;
                        animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                        break;
                }
            }
            return map;
        }
    }
}
