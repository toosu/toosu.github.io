using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>再生の仕組みをどこまで用意できたか。</summary>
    public enum PlayerSetupStage
    {
        /// <summary>SDK / UdonSharp が無い(または System ノードが無い)。Animator と AudioSource と README だけ。</summary>
        ReadmeOnly = 0,

        /// <summary>スクリプトはある(または書き出した)が、取り付けは README の手順で手動。</summary>
        ScriptAndReadme = 1,

        /// <summary>コンパイル後に自動で取り付ける予約をした(結果は再コンパイル後に出る)。</summary>
        AttachPending = 2,

        /// <summary>System に取り付け済み。</summary>
        Attached = 3,
    }

    /// <summary>今回の生成で新しく作った、再生の仕組みまわりのもの(失敗時の片付け用)。</summary>
    internal sealed class PlayerSetupArtifacts
    {
        /// <summary>新しく作ったフォルダ(作った順)。</summary>
        public readonly List<string> CreatedFolders = new List<string>();

        /// <summary>今回書き出した再生スクリプト。書き出さなかったら null。</summary>
        public string WrittenScriptPath;

        /// <summary>今回作った U# プログラムアセット。作らなかったら null。</summary>
        public string CreatedProgramAssetPath;

        /// <summary>取り付けの予約をしたか。</summary>
        public bool Reserved;
    }

    /// <summary>
    /// 同期再生スクリプト(UdonSharp)の書き出し・取り付け・手動手順の README。
    ///
    /// 配置: 再生スクリプトと U# プログラムアセットは全ライブ共通で、ライブのフォルダの外の
    /// &lt;出力先&gt;/_Shared/Scripts/ParticleLivePlayer.cs(と同名の .asset)に 1 つだけ置く。
    /// ライブごとの Scripts/ は利用者用の空フォルダ。
    /// 既に同名のスクリプトがプロジェクトの別の場所にある場合は、同じクラス名の 2 つ目を書くとコンパイルエラーになるため、
    /// 書き出さずにそれを使い、場所を画面・README に明記する。
    ///
    /// .cs を書き出すと再コンパイル(ドメインリロード)が起きるので、取り付けは SessionState に予約して
    /// リロード後に [InitializeOnLoad] から再開する。予約は作成から PendingLifetime を過ぎたもの・
    /// 別のシーンのものは実行せずに捨てる。
    /// </summary>
    public static class PlayerSetup
    {
        /// <summary>再生スクリプトのクラス名(ライブ名に依存しない固定名)。</summary>
        public const string PlayerClassName = "ParticleLivePlayer";

        public const string TemplateFileName = "ParticleLivePlayer.cs.txt";
        public const string ReadmeFileName = "README_setup.txt";

        /// <summary>取り付け予約の有効期間。これを過ぎた予約は実行しない。</summary>
        public static readonly TimeSpan PendingLifetime = TimeSpan.FromMinutes(10);

        internal const string PendingKey = "PLT.project.PendingAttach";
        internal const string AudioFieldName = "audioSource";
        internal const string AnimatorFieldName = "animator";

        /// <summary>最後の結果を UI に見せるための保存先(ModuleState と同じキー空間)。</summary>
        internal const string ResultStateKey = "LastResult";

        /// <summary>テスト用: 現在時刻の差し替え(null なら DateTime.UtcNow)。</summary>
        internal static Func<DateTime> UtcNowProbe;

        private static DateTime UtcNow
        {
            get { return UtcNowProbe != null ? UtcNowProbe() : DateTime.UtcNow; }
        }

        /// <summary>プロジェクト内にある ParticleLivePlayer.cs(ファイル名で判定)。無ければ null。</summary>
        public static MonoScript FindExistingPlayerScript()
        {
            foreach (string guid in AssetDatabase.FindAssets(PlayerClassName + " t:MonoScript"))
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (!string.Equals(Path.GetFileName(path), PlayerClassName + ".cs", StringComparison.OrdinalIgnoreCase)) continue;
                var script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
                if (script != null) return script;
            }
            return null;
        }

        /// <summary>
        /// 使う再生スクリプトの場所。共有の場所にあればそれ、無ければプロジェクトの別の場所にある同名スクリプト、
        /// どちらも無ければ共有の場所(これから書き出す)。exists はスクリプトが既にあるか。
        /// </summary>
        public static string ResolveScriptPath(GenerationPaths paths, out bool exists)
        {
            if (File.Exists(paths.SharedScriptPath))
            {
                exists = true;
                return paths.SharedScriptPath;
            }
            MonoScript other = FindExistingPlayerScript();
            if (other != null)
            {
                exists = true;
                return AssetDatabase.GetAssetPath(other);
            }
            exists = false;
            return paths.SharedScriptPath;
        }

        /// <summary>テンプレートの中身。見つからなければ null。</summary>
        public static string LoadTemplate()
        {
            return ToolkitPaths.LoadTemplateText(TemplateFileName);
        }

        /// <summary>テンプレートのパス(README に書く用)。</summary>
        internal static string TemplateAssetPath
        {
            get
            {
                string folder = ToolkitPaths.TemplatesFolder;
                return folder != null ? folder + "/" + TemplateFileName : "Editor/Templates/" + TemplateFileName;
            }
        }

        /// <summary>
        /// 生成の最後に呼ぶ。SDK の有無に応じてスクリプトの書き出し・取り付け・README の書き出しを行う。
        /// 新しく作ったものは artifacts に記録する(例外時は呼び出し側がそれを片付ける)。
        /// </summary>
        internal static PlayerSetupStage Run(GenerationPaths paths, PlayerSupport support, GameObject root,
            string systemPath, string musicPath, string animationPath, PlayerSetupArtifacts artifacts, out string detail)
        {
            var info = new ReadmeInfo
            {
                Paths = paths,
                SystemPath = systemPath,
                MusicPath = musicPath,
                AnimationPath = animationPath,
            };

            if (!support.CanWriteScript)
            {
                info.ScriptPath = paths.SharedScriptPath;
                WriteReadme(ReadmeKind.NoSdk, info);
                detail = "VRChat SDK - Worlds(UdonSharp)が見つからないため、再生スクリプトは書き出していません。手順を " + paths.ReadmePath + " に書き出しました。";
                return PlayerSetupStage.ReadmeOnly;
            }

            string scriptPath = ResolveScriptPath(paths, out bool exists);
            info.ScriptPath = scriptPath;

            if (string.IsNullOrEmpty(systemPath))
            {
                WriteReadme(ReadmeKind.NoSystemNode, info);
                detail = "テンプレートに System(再生制御)のノードが無いため、再生スクリプトは取り付けません。手順を " + paths.ReadmePath + " に書き出しました。";
                return PlayerSetupStage.ReadmeOnly;
            }

            MonoScript script;
            if (exists)
            {
                script = AssetDatabase.LoadAssetAtPath<MonoScript>(scriptPath);
                if (!UdonSharpBridge.IsUdonSharpBehaviourScript(script))
                {
                    // 同名の別スクリプト、コンパイルエラー中、または書き出し直後でまだコンパイルされていない。
                    // プログラムアセットは作らず(非 U# スクリプトを指すと U# のコンパイルエラーになる)、予約もせず、手順だけ出す。
                    WriteReadme(ReadmeKind.ExistingScriptUnusable, info);
                    detail = "再生スクリプト " + scriptPath + " が UdonSharpBehaviour としてコンパイルされていないため、取り付けていません。手順を " + paths.ReadmePath + " に書き出しました。";
                    return PlayerSetupStage.ScriptAndReadme;
                }
            }
            else
            {
                string text = LoadTemplate();
                if (text == null) throw new InvalidOperationException("再生スクリプトのテンプレート " + TemplateFileName + " が見つかりません");
                GeneratorFolders.CreateFolderRecursive(paths.SharedScriptsFolder, artifacts.CreatedFolders);
                File.WriteAllText(scriptPath, text, new UTF8Encoding(false));
                artifacts.WrittenScriptPath = scriptPath;
                AssetDatabase.ImportAsset(scriptPath, ImportAssetOptions.ForceSynchronousImport);
                script = AssetDatabase.LoadAssetAtPath<MonoScript>(scriptPath);
                if (script == null) throw new InvalidOperationException("書き出した " + scriptPath + " を読み込めません");
            }

            // README は先に書いておき、取り付けが成功したら消す(リロードが起きなかった場合も手順が残る)。
            WriteReadme(ReadmeKind.AttachManually, info);

            // UdonSharp の「Create > U# Script」と同じく、.cs の取り込み直後(リロード前)にプログラムアセットを作る。
            string programPath = Path.ChangeExtension(scriptPath, ".asset").Replace('\\', '/');
            UdonSharpBridge.EnsureProgramAsset(script, programPath, out bool created, out string programError);
            if (created) artifacts.CreatedProgramAssetPath = programPath;
            if (programError != null)
            {
                detail = programError + "。手順を " + paths.ReadmePath + " に書き出しました。";
                return PlayerSetupStage.ScriptAndReadme;
            }

            string where = (artifacts.WrittenScriptPath != null ? "全ライブ共通の再生スクリプトを " + scriptPath + " に書き出しました" : "全ライブ共通の再生スクリプト " + scriptPath + " を使います")
                + "(このファイルを消すと、すべてのライブの再生が動かなくなります)。";

            if (!support.CanAutoAttach)
            {
                detail = where + "取り付けの手順を " + paths.ReadmePath + " に書き出しました。";
                return PlayerSetupStage.ScriptAndReadme;
            }

            var pending = new PendingAttach
            {
                projectPath = paths.ProjectAssetPath,
                scriptPath = scriptPath,
                readmePath = paths.ReadmePath,
                systemPath = systemPath,
                musicPath = musicPath,
                animationPath = animationPath,
                scenePath = root != null ? root.scene.path : "",
                createdUtcTicks = UtcNow.Ticks,
            };

            if (artifacts.WrittenScriptPath == null)
            {
                // 既存のスクリプトはコンパイル済みなので、その場で取り付ける(リロード不要)。
                if (TryAttach(pending, out string attachError))
                {
                    detail = where + "System に取り付けました。";
                    return PlayerSetupStage.Attached;
                }
                detail = where + attachError + "。手順を " + paths.ReadmePath + " に書き出しました。";
                return PlayerSetupStage.ScriptAndReadme;
            }

            SessionState.SetString(PendingKey, JsonUtility.ToJson(pending));
            artifacts.Reserved = true;
            detail = where + "コンパイルが終わると System に自動で取り付けます。";
            return PlayerSetupStage.AttachPending;
        }

        /// <summary>有効な(期限内の)取り付け予約があるか。</summary>
        public static bool HasPendingAttach
        {
            get
            {
                PendingAttach pending = ReadPending();
                return pending != null && !IsExpired(pending);
            }
        }

        /// <summary>予約を消す。</summary>
        internal static void ClearPending()
        {
            SessionState.EraseString(PendingKey);
        }

        private static PendingAttach ReadPending()
        {
            string json = SessionState.GetString(PendingKey, "");
            if (string.IsNullOrEmpty(json)) return null;
            try
            {
                return JsonUtility.FromJson<PendingAttach>(json);
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static bool IsExpired(PendingAttach pending)
        {
            if (pending.createdUtcTicks <= 0) return true;
            TimeSpan age = UtcNow - new DateTime(pending.createdUtcTicks, DateTimeKind.Utc);
            return age < TimeSpan.Zero || age > PendingLifetime;
        }

        /// <summary>
        /// 予約された取り付けを実行する。予約は実行前に消す(失敗してもリロードのたびに再試行しない)。
        /// 期限切れ・シーンが違う予約は実行せずに捨て、その旨を結果に出す。予約が無ければ false。
        /// </summary>
        internal static bool RunPendingAttach()
        {
            if (string.IsNullOrEmpty(SessionState.GetString(PendingKey, ""))) return false;
            PendingAttach pending = ReadPending();
            ClearPending();
            if (pending == null) return false;

            string message;
            bool ok = false;
            if (IsExpired(pending))
            {
                message = "再生スクリプトの取り付け予約は、作ってから " + (int)PendingLifetime.TotalMinutes + " 分以上たったため実行しませんでした。手順は " + pending.readmePath + " を見てください。";
            }
            else if (!IsSameScene(pending, out string sceneProblem))
            {
                message = "再生スクリプトの取り付け予約は、" + sceneProblem + "ため実行しませんでした。手順は " + pending.readmePath + " を見てください。";
            }
            else
            {
                ok = TryAttach(pending, out string error);
                message = ok
                    ? "再生スクリプトを System に取り付けました(" + pending.scriptPath + ")。"
                    : "再生スクリプトを自動で取り付けられませんでした: " + error + "。手順は " + pending.readmePath + " を見てください。";
            }
            if (ok) Debug.Log("[Particle Live Toolkit] " + message);
            else Debug.LogWarning("[Particle Live Toolkit] " + message);
            AppendResult(message, AssetDatabase.LoadAssetAtPath<ParticleLiveProject>(pending.projectPath));
            return ok;
        }

        private static bool IsSameScene(PendingAttach pending, out string problem)
        {
            problem = null;
            var project = AssetDatabase.LoadAssetAtPath<ParticleLiveProject>(pending.projectPath);
            GameObject root = ProjectSceneUtility.FindRoot(project);
            if (root == null)
            {
                problem = "ライブのルートが開いているシーンに見つからない";
                return false;
            }
            if (!string.Equals(root.scene.path ?? "", pending.scenePath ?? "", StringComparison.Ordinal))
            {
                problem = "生成したときと別のシーン(" + (string.IsNullOrEmpty(root.scene.path) ? "未保存のシーン" : root.scene.path) + ")が開かれている";
                return false;
            }
            return true;
        }

        private static bool TryAttach(PendingAttach pending, out string error)
        {
            var project = AssetDatabase.LoadAssetAtPath<ParticleLiveProject>(pending.projectPath);
            GameObject root = ProjectSceneUtility.FindRoot(project);
            if (root == null)
            {
                error = "ライブのルートがシーンに見つかりません";
                return false;
            }
            Transform system = root.transform.Find(pending.systemPath);
            Transform music = string.IsNullOrEmpty(pending.musicPath) ? null : root.transform.Find(pending.musicPath);
            Transform animation = string.IsNullOrEmpty(pending.animationPath) ? null : root.transform.Find(pending.animationPath);
            if (system == null)
            {
                error = "System(" + pending.systemPath + ")が見つかりません";
                return false;
            }
            var script = AssetDatabase.LoadAssetAtPath<MonoScript>(pending.scriptPath);
            AudioSource audio = music != null ? music.GetComponent<AudioSource>() : null;
            Animator animator = animation != null ? animation.GetComponent<Animator>() : null;

            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("再生スクリプトの取り付け");
            bool ok = UdonSharpBridge.AttachBehaviour(system.gameObject, script, out error,
                AudioFieldName, audio, AnimatorFieldName, animator);
            if (ok)
            {
                // インタラクトにはコライダーが要る。体を押し返さないようトリガーにする。
                if (system.GetComponent<Collider>() == null)
                {
                    var box = Undo.AddComponent<BoxCollider>(system.gameObject);
                    box.isTrigger = true;
                    box.center = new Vector3(0f, 1f, 0f);
                    box.size = new Vector3(0.5f, 0.5f, 0.5f);
                }
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(system.gameObject.scene);
                if (!string.IsNullOrEmpty(pending.readmePath) && File.Exists(pending.readmePath))
                {
                    AssetDatabase.DeleteAsset(pending.readmePath);
                }
                Undo.CollapseUndoOperations(group);
            }
            else
            {
                // 中途半端に付いたコンポーネントを残さない(README の手順どおりに一から付けられるように)。
                Undo.CollapseUndoOperations(group);
                Undo.RevertAllDownToGroup(group);
            }
            return ok;
        }

        internal static void AppendResult(string message, ParticleLiveProject project = null)
        {
            var state = new ModuleState(ToolkitModuleIds.Project, () => project);
            string current = state.GetString(ResultStateKey, "");
            state.SetString(ResultStateKey, string.IsNullOrEmpty(current) ? message : current + "\n" + message);
        }

        internal enum ReadmeKind
        {
            NoSdk,
            NoSystemNode,
            AttachManually,
            ExistingScriptUnusable,
        }

        /// <summary>README の文面に使う情報。</summary>
        internal sealed class ReadmeInfo
        {
            public GenerationPaths Paths;
            public string SystemPath;
            public string MusicPath;
            public string AnimationPath;

            /// <summary>使う(または作るべき)再生スクリプトの場所。</summary>
            public string ScriptPath;
        }

        internal static void WriteReadme(ReadmeKind kind, ReadmeInfo info)
        {
            string text = BuildReadme(kind, info);
            File.WriteAllText(info.Paths.ReadmePath, text, new UTF8Encoding(false));
            AssetDatabase.ImportAsset(info.Paths.ReadmePath, ImportAssetOptions.ForceSynchronousImport);
        }

        internal static string BuildReadme(ReadmeKind kind, ReadmeInfo info)
        {
            GenerationPaths paths = info.Paths;
            string root = paths.LiveName;
            string system = root + "/" + (string.IsNullOrEmpty(info.SystemPath) ? "System" : info.SystemPath);
            string music = root + "/" + (info.MusicPath ?? "Music");
            string animation = root + "/" + (info.AnimationPath ?? "Animation");
            string scriptPath = string.IsNullOrEmpty(info.ScriptPath) ? paths.SharedScriptPath : info.ScriptPath;
            string scriptFolder = scriptPath.Substring(0, Math.Max(0, scriptPath.LastIndexOf('/')));
            var sb = new StringBuilder();
            sb.AppendLine("「" + paths.LiveName + "」再生の仕組み 手動セットアップ手順");
            sb.AppendLine("(Particle Live Toolkit が書き出しました)");
            sb.AppendLine();
            sb.AppendLine("再生スクリプトの場所: " + scriptPath);
            sb.AppendLine("このスクリプトは全ライブ共通です。消したり移動したりすると、すべてのライブの再生が動かなくなります。");
            sb.AppendLine("ライブのフォルダの Scripts/ は自由に使ってよい空のフォルダです。");
            sb.AppendLine();
            switch (kind)
            {
                case ReadmeKind.NoSdk:
                    sb.AppendLine("VRChat SDK - Worlds(UdonSharp)が見つからなかったため、再生スクリプトは書き出していません。");
                    sb.AppendLine();
                    sb.AppendLine("1. VRChat Creator Companion(VCC)でこのプロジェクトに「VRChat SDK - Worlds」を追加し、Unity のコンパイルが終わるまで待ちます。");
                    sb.AppendLine("2. Project ウィンドウで " + scriptFolder + " フォルダを作り(無ければ)、右クリック > Create > U# Script で「" + PlayerClassName + "」という名前のスクリプトを作ります。");
                    sb.AppendLine("3. 作られた " + PlayerClassName + ".cs を開き、中身をすべて " + TemplateAssetPath + " の内容に置き換えて保存します。");
                    AppendAttachSteps(sb, 4, system, music, animation);
                    break;
                case ReadmeKind.NoSystemNode:
                    sb.AppendLine("テンプレートに System(再生制御)のノードが無いため、再生スクリプトは取り付けていません。");
                    sb.AppendLine();
                    sb.AppendLine("1. Hierarchy で " + root + " を右クリックし、Create Empty で「System」を作ります。");
                    sb.AppendLine("2. " + scriptPath + " が無ければ、Project ウィンドウで " + scriptFolder + " を右クリック > Create > U# Script で「" + PlayerClassName + "」を作り、中身を " + TemplateAssetPath + " の内容に置き換えます。");
                    AppendAttachSteps(sb, 3, root + "/System", music, animation);
                    break;
                case ReadmeKind.ExistingScriptUnusable:
                    sb.AppendLine(scriptPath + " がありますが、UdonSharpBehaviour としてコンパイルされていないため、取り付けていません。");
                    sb.AppendLine();
                    sb.AppendLine("1. Unity のコンパイルが終わるまで待ち、Console にコンパイルエラーがあれば先に直します。");
                    sb.AppendLine("2. " + scriptPath + " が再生用ではない別のスクリプトなら、中身をすべて " + TemplateAssetPath + " の内容に置き換えて保存します。");
                    sb.AppendLine("3. Project ウィンドウで " + PlayerClassName + ".cs の隣に同じ名前の .asset(U# プログラム)が無ければ、" + PlayerClassName + ".cs を右クリック > Create > VRChat > Udon > Udon C# Program Asset で作り、Source Script に " + PlayerClassName + ".cs を入れます。");
                    AppendAttachSteps(sb, 4, system, music, animation);
                    break;
                default:
                    sb.AppendLine("自動の取り付けが終わるとこのファイルは消えます。残っている場合は次の手順で取り付けてください。");
                    sb.AppendLine();
                    sb.AppendLine("1. Unity 右下のコンパイル表示が消えるまで待ちます。Console にエラーがあれば先に直します。");
                    sb.AppendLine("2. Project ウィンドウで " + scriptPath + " の隣に同じ名前の .asset(U# プログラム)があるか確認します。無ければ " + PlayerClassName + ".cs を右クリック > Create > VRChat > Udon > Udon C# Program Asset で作り、Source Script に " + PlayerClassName + ".cs を入れます。");
                    AppendAttachSteps(sb, 3, system, music, animation);
                    break;
            }
            sb.AppendLine();
            sb.AppendLine("確認: Play(ClientSim)で System をクリックし、曲とアニメーションが始まれば完了です。もう一度クリックすると止まり、曲が最後まで終わったあとは 1 回のクリックで頭から再生し直します。");
            sb.AppendLine();
            sb.AppendLine("注意:");
            sb.AppendLine("- 再生と停止はインスタンスの誰でも操作でき、全員の再生が同時に始まり / 止まります。");
            sb.AppendLine("- 操作用の Box Collider(Is Trigger、大きさ 0.5m、System の位置から高さ 1m)は見えません。押しやすい位置へ System を動かすか、目印のオブジェクトを置いてください。");
            return sb.ToString();
        }

        private static void AppendAttachSteps(StringBuilder sb, int firstNumber, string system, string music, string animation)
        {
            sb.AppendLine(firstNumber + ". Hierarchy で " + system + " を選び、Inspector の Add Component から " + PlayerClassName + " を追加します。Audio Source 欄に " + music + "、Animator 欄に " + animation + " をドラッグします。");
            sb.AppendLine((firstNumber + 1) + ". 同じオブジェクトに Box Collider を追加し、Is Trigger をオンにします(クリックで再生 / 停止するため)。");
        }

        [Serializable]
        internal sealed class PendingAttach
        {
            public string projectPath;
            public string scriptPath;
            public string readmePath;
            public string systemPath;
            public string musicPath;
            public string animationPath;

            /// <summary>生成したときのライブルートのシーンのパス(未保存シーンなら "")。</summary>
            public string scenePath;

            /// <summary>予約した時刻(UTC の Ticks)。</summary>
            public long createdUtcTicks;
        }
    }

    /// <summary>再コンパイル後に予約された取り付けを再開する。</summary>
    [InitializeOnLoad]
    internal static class PlayerSetupResume
    {
        static PlayerSetupResume()
        {
            if (string.IsNullOrEmpty(SessionState.GetString(PlayerSetup.PendingKey, ""))) return;
            EditorApplication.update -= Poll;
            EditorApplication.update += Poll;
        }

        private static void Poll()
        {
            // コンパイル・インポート・Play Mode 切り替えの最中は待つ。
            if (EditorApplication.isCompiling || EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode) return;
            EditorApplication.update -= Poll;
            try
            {
                PlayerSetup.RunPendingAttach();
            }
            catch (Exception e)
            {
                PlayerSetup.ClearPending();
                Debug.LogWarning("[Particle Live Toolkit] 再生スクリプトの自動取り付けに失敗しました: " + e.Message);
            }
        }
    }
}
