using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ParticleLiveToolkit.Modules.ProjectGenerator
{
    /// <summary>ウィザードの入力。</summary>
    public sealed class ProjectGenerationRequest
    {
        public const string DefaultOutputFolder = "Assets/ParticleLive";
        public const int MaxNameLength = 64;
        public const double MaxBpm = 999.0;

        public string liveName = "";
        public double bpm = ParticleLiveProject.DefaultBpm;

        /// <summary>楽曲(任意)。</summary>
        public AudioClip song;

        /// <summary>ライブのフォルダを作る場所(AssetDatabase 形式)。この下に &lt;ライブ名&gt;/ を作る。</summary>
        public string outputFolder = DefaultOutputFolder;

        /// <summary>null なら既定の構成。</summary>
        public ProjectTemplate template;
    }

    /// <summary>入力から求めた、作るもののパス一式。</summary>
    public sealed class GenerationPaths
    {
        /// <summary>出力先フォルダの中にある、全ライブ共通の置き場の名前(ライブ名には使えない)。</summary>
        public const string SharedFolderName = "_Shared";

        public string LiveName;
        public string OutputParent;
        public string LiveFolder;
        public string AnimationsFolder;
        public string ScriptsFolder;
        public string MainClipPath;
        public string ControllerPath;
        public string ProjectAssetPath;
        public string ReadmePath;

        /// <summary>全ライブ共通の置き場("&lt;出力先&gt;/_Shared")。</summary>
        public string SharedFolder;

        /// <summary>共通の再生スクリプトを置くフォルダ("&lt;出力先&gt;/_Shared/Scripts")。</summary>
        public string SharedScriptsFolder;

        /// <summary>共通の再生スクリプト("&lt;出力先&gt;/_Shared/Scripts/ParticleLivePlayer.cs")。</summary>
        public string SharedScriptPath;

        /// <summary>共通の U# プログラムアセット(スクリプトの隣の同名 .asset)。</summary>
        public string SharedProgramAssetPath;

        /// <summary>LiveFolder 配下に作るフォルダ(作る順。親が先)。</summary>
        public List<string> Folders = new List<string>();

        internal static GenerationPaths Build(string liveName, string outputParent, ProjectTemplate template)
        {
            var p = new GenerationPaths
            {
                LiveName = liveName,
                OutputParent = outputParent,
                LiveFolder = outputParent + "/" + liveName,
            };
            p.AnimationsFolder = p.LiveFolder + "/" + NormalizeRelative(template.animationsFolder);
            p.ScriptsFolder = p.LiveFolder + "/" + NormalizeRelative(template.scriptsFolder);
            p.MainClipPath = p.AnimationsFolder + "/" + liveName + "_Main.anim";
            p.ControllerPath = p.AnimationsFolder + "/" + liveName + ".controller";
            p.ProjectAssetPath = p.LiveFolder + "/" + liveName + "_Project.asset";
            p.ReadmePath = p.LiveFolder + "/README_setup.txt";
            p.SharedFolder = outputParent + "/" + SharedFolderName;
            p.SharedScriptsFolder = p.SharedFolder + "/Scripts";
            p.SharedScriptPath = p.SharedScriptsFolder + "/" + PlayerSetup.PlayerClassName + ".cs";
            p.SharedProgramAssetPath = p.SharedScriptsFolder + "/" + PlayerSetup.PlayerClassName + ".asset";

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var relatives = new List<string>();
            if (template.folders != null) relatives.AddRange(template.folders);
            relatives.Add(template.animationsFolder);
            foreach (string relative in relatives)
            {
                string normalized = NormalizeRelative(relative);
                if (normalized.Length == 0) continue;
                // 入れ子なら親から順に作る。
                string[] segments = normalized.Split('/');
                string current = p.LiveFolder;
                foreach (string segment in segments)
                {
                    current += "/" + segment;
                    if (seen.Add(current)) p.Folders.Add(current);
                }
            }
            return p;
        }

        internal static string NormalizeRelative(string relative)
        {
            return (relative ?? "").Replace('\\', '/').Trim().Trim('/');
        }
    }

    /// <summary>入力の検証(何も書かない)。</summary>
    public static class ProjectGenerationValidator
    {
        private static readonly string[] ReservedNames =
        {
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
        };

        /// <summary>ライブ名の検証。問題が無ければ null、あれば理由。</summary>
        public static string ValidateLiveName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "ライブ名を入力してください";
            if (name.IndexOf('/') >= 0 || name.IndexOf('\\') >= 0) return "ライブ名に / や \\ は使えません";
            if (name.Contains("..")) return "ライブ名に .. は使えません";
            if (string.Equals(name.Trim(), GenerationPaths.SharedFolderName, StringComparison.OrdinalIgnoreCase))
                return "ライブ名「" + GenerationPaths.SharedFolderName + "」は全ライブ共通の置き場に使うため使えません";
            return ValidateSegment(name, "ライブ名");
        }

        /// <summary>
        /// ファイル名・フォルダ名 1 つ分の検証(区切り文字を含まない前提)。問題が無ければ null。
        /// label は「ライブ名」「フォルダ名」など、理由の先頭に付ける語。
        /// </summary>
        internal static string ValidateSegment(string segment, string label)
        {
            if (string.IsNullOrWhiteSpace(segment)) return label + "が空です";
            if (segment == "." || segment == "..") return label + "に . や .. は使えません";
            if (segment.Length > ProjectGenerationRequest.MaxNameLength)
                return label + "は " + ProjectGenerationRequest.MaxNameLength + " 文字以内にしてください";
            char[] invalid = Path.GetInvalidFileNameChars();
            foreach (char c in segment)
            {
                // Windows でファイル名に使えない文字は OS によらず拒否する(プロジェクトを共有しても壊れないように)。
                if (Array.IndexOf(invalid, c) >= 0 || "<>:\"|?*".IndexOf(c) >= 0 || c < ' ')
                {
                    string shown = c < ' ' ? "制御文字" : c.ToString();
                    return label + "に使えない文字が含まれています: " + shown;
                }
            }
            if (segment[0] == ' ' || segment[segment.Length - 1] == ' ' || segment[segment.Length - 1] == '.')
                return label + "の先頭・末尾の空白や、末尾のピリオドは使えません";
            // Unity が取り込まない(無視する)名前。
            if (segment[0] == '.') return label + "をピリオドで始めることはできません(Unity が無視する名前です)";
            if (segment[segment.Length - 1] == '~') return label + "を ~ で終えることはできません(Unity が無視する名前です)";
            if (string.Equals(segment, "cvs", StringComparison.OrdinalIgnoreCase)) return label + "「cvs」は Unity が無視する名前です";
            if (segment.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase)) return label + "の末尾を .tmp にはできません(Unity が無視する名前です)";
            string stem = segment;
            int dot = stem.IndexOf('.');
            if (dot >= 0) stem = stem.Substring(0, dot);
            foreach (string reserved in ReservedNames)
            {
                if (string.Equals(stem, reserved, StringComparison.OrdinalIgnoreCase))
                    return label + "「" + segment + "」は Windows で使えない名前です";
            }
            return null;
        }

        /// <summary>出力先フォルダの検証と正規化("Assets" か "Assets/..." のみ)。</summary>
        public static string ValidateOutputFolder(string folder, out string normalized)
        {
            normalized = (folder ?? "").Replace('\\', '/').Trim().TrimEnd('/');
            if (normalized.Length == 0) return "出力先フォルダを指定してください";
            if (normalized != "Assets" && !normalized.StartsWith("Assets/", StringComparison.Ordinal))
                return "出力先フォルダは Assets フォルダの中を指定してください";
            string[] segments = normalized.Split('/');
            for (int i = 1; i < segments.Length; i++)
            {
                string reason = ValidateSegment(segments[i], "出力先フォルダの名前");
                if (reason != null) return reason;
                if (string.Equals(segments[i], "Editor", StringComparison.OrdinalIgnoreCase))
                    return "出力先フォルダを Editor フォルダの中にはできません(再生スクリプトがワールドに入らなくなります)";
                if (string.Equals(segments[i], GenerationPaths.SharedFolderName, StringComparison.OrdinalIgnoreCase))
                    return "出力先フォルダを " + GenerationPaths.SharedFolderName + " フォルダの中にはできません";
            }
            return null;
        }

        public static string ValidateBpm(double bpm)
        {
            if (double.IsNaN(bpm) || double.IsInfinity(bpm) || bpm <= 0.0) return "BPM は 0 より大きい数にしてください";
            if (bpm > ProjectGenerationRequest.MaxBpm) return "BPM は " + ProjectGenerationRequest.MaxBpm + " 以下にしてください";
            return null;
        }

        /// <summary>テンプレートの検証。問題が無ければ空。</summary>
        public static List<string> ValidateTemplate(ProjectTemplate template)
        {
            var errors = new List<string>();
            if (template == null)
            {
                errors.Add("テンプレートがありません");
                return errors;
            }

            if (template.folders != null)
            {
                foreach (string folder in template.folders)
                {
                    string reason = ValidateRelativePath(folder, "テンプレートのフォルダ");
                    if (reason != null) errors.Add(reason);
                }
            }
            string animReason = ValidateRelativePath(template.animationsFolder, "アニメーションの置き場所");
            if (animReason != null) errors.Add(animReason);
            string scriptReason = ValidateRelativePath(template.scriptsFolder, "スクリプトの置き場所");
            if (scriptReason != null) errors.Add(scriptReason);

            var paths = new HashSet<string>(StringComparer.Ordinal);
            var roleCount = new Dictionary<SceneNodeRole, int>();
            List<TemplateNode> nodes = template.nodes ?? new List<TemplateNode>();
            foreach (TemplateNode node in nodes)
            {
                if (node == null)
                {
                    errors.Add("テンプレートに空のノードがあります");
                    continue;
                }
                string reason = ValidateRelativePath(node.path, "ノード");
                if (reason != null)
                {
                    errors.Add(reason);
                    continue;
                }
                string path = GenerationPaths.NormalizeRelative(node.path);
                if (!paths.Add(path)) errors.Add("ノード「" + path + "」が重複しています");
                if (!Enum.IsDefined(typeof(SceneNodeRole), node.role))
                {
                    errors.Add("ノード「" + path + "」の役割が不正です");
                    continue;
                }
                roleCount.TryGetValue(node.role, out int count);
                roleCount[node.role] = count + 1;
            }
            foreach (TemplateNode node in nodes)
            {
                if (node == null || ValidateRelativePath(node.path, "ノード") != null) continue;
                string path = GenerationPaths.NormalizeRelative(node.path);
                int slash = path.LastIndexOf('/');
                if (slash > 0 && !paths.Contains(path.Substring(0, slash)))
                    errors.Add("ノード「" + path + "」の親「" + path.Substring(0, slash) + "」が一覧にありません");
            }

            RequireRole(roleCount, SceneNodeRole.Music, "Music(AudioSource)", true, errors);
            RequireRole(roleCount, SceneNodeRole.Animation, "Animation(Animator)", true, errors);
            RequireRole(roleCount, SceneNodeRole.Viewpoint, "Viewpoint(観客視点)", false, errors);
            RequireRole(roleCount, SceneNodeRole.System, "System(再生制御)", false, errors);
            return errors;
        }

        private static void RequireRole(Dictionary<SceneNodeRole, int> counts, SceneNodeRole role, string label, bool required, List<string> errors)
        {
            counts.TryGetValue(role, out int count);
            if (required && count == 0) errors.Add("テンプレートに役割 " + label + " のノードがありません");
            if (count > 1) errors.Add("役割 " + label + " のノードは 1 つだけにしてください");
        }

        private static string ValidateRelativePath(string relative, string label)
        {
            string raw = (relative ?? "").Replace('\\', '/').Trim();
            if (raw.Length == 0 || raw.Trim('/').Length == 0) return label + "のパスが空です";
            if (raw.StartsWith("/", StringComparison.Ordinal)) return label + "「" + raw + "」は相対パスで指定してください";
            foreach (string segment in raw.Trim('/').Split('/'))
            {
                string reason = ValidateSegment(segment, label + "「" + raw + "」の名前");
                if (reason != null) return reason;
            }
            return null;
        }

        /// <summary>
        /// 生成前の全検証。何も書かない。問題が無ければ空のリスト。
        /// template は null 不可(呼び出し側で既定を補う)。
        /// </summary>
        public static List<string> Validate(ProjectGenerationRequest request, ProjectTemplate template, out GenerationPaths paths)
        {
            paths = null;
            var errors = new List<string>();
            if (request == null)
            {
                errors.Add("入力がありません");
                return errors;
            }

            string nameReason = ValidateLiveName(request.liveName);
            if (nameReason != null) errors.Add(nameReason);
            string bpmReason = ValidateBpm(request.bpm);
            if (bpmReason != null) errors.Add(bpmReason);
            string folderReason = ValidateOutputFolder(request.outputFolder, out string outputParent);
            if (folderReason != null) errors.Add(folderReason);
            errors.AddRange(ValidateTemplate(template));
            if (errors.Count > 0) return errors;

            string liveName = request.liveName;
            GenerationPaths built = GenerationPaths.Build(liveName, outputParent, template);

            if (AssetDatabase.IsValidFolder(built.LiveFolder) || Directory.Exists(built.LiveFolder) || File.Exists(built.LiveFolder))
                errors.Add("出力先「" + built.LiveFolder + "」が既にあります。別のライブ名にするか、出力先を変えてください");
            else if (ExistsAsFile(outputParent))
                errors.Add("出力先「" + outputParent + "」はフォルダではありません");


            string asmdef = FindAssemblyDefinitionAbove(built.SharedScriptsFolder);
            if (asmdef != null)
                errors.Add("出力先フォルダがアセンブリ定義 " + asmdef + " の中にあります。再生スクリプトを置けないため、アセンブリ定義の無いフォルダを選んでください");

            string busy = EditorBusyReason();
            if (busy != null) errors.Add(busy);

            Scene active = SceneManager.GetActiveScene();
            if (!active.IsValid() || !active.isLoaded) errors.Add("シーンを開いてから実行してください");
            if (PrefabStageUtility.GetCurrentPrefabStage() != null) errors.Add("Prefab 編集モードを終了してから実行してください");

            if (errors.Count == 0) paths = built;
            return errors;
        }

        /// <summary>テスト用: Play Mode 判定の差し替え(null なら EditorApplication.isPlayingOrWillChangePlaymode)。</summary>
        internal static Func<bool> PlayModeProbe;

        /// <summary>テスト用: コンパイル中判定の差し替え(null なら EditorApplication.isCompiling)。</summary>
        internal static Func<bool> CompilingProbe;

        /// <summary>
        /// 今は生成できないエディタの状態(Play Mode / コンパイル中 / 前回の取り付け待ち)。生成できるなら null。
        /// </summary>
        public static string EditorBusyReason()
        {
            bool playing = PlayModeProbe != null ? PlayModeProbe() : EditorApplication.isPlayingOrWillChangePlaymode;
            if (playing) return "Play Mode を終了してから実行してください";
            bool compiling = CompilingProbe != null ? CompilingProbe() : EditorApplication.isCompiling;
            if (compiling) return "スクリプトのコンパイル中です。終わってから実行してください";
            if (PlayerSetup.HasPendingAttach) return "前に生成したライブの再生スクリプトの取り付け待ちです。コンパイルが終わるまで待ってください";
            return null;
        }

        /// <summary>
        /// folder(まだ無くてもよい)から Assets までの間にあるアセンブリ定義(.asmdef / .asmref)。無ければ null。
        /// ディスク上のファイルで調べる(未インポートでも見つける)。
        /// </summary>
        internal static string FindAssemblyDefinitionAbove(string folder)
        {
            string current = folder;
            while (!string.IsNullOrEmpty(current))
            {
                if (Directory.Exists(current))
                {
                    foreach (string pattern in new[] { "*.asmdef", "*.asmref" })
                    {
                        string[] found = Directory.GetFiles(current, pattern, SearchOption.TopDirectoryOnly);
                        if (found.Length > 0) return found[0].Replace('\\', '/');
                    }
                }
                if (current == "Assets") break;
                int slash = current.LastIndexOf('/');
                if (slash < 0) break;
                current = current.Substring(0, slash);
            }
            return null;
        }

        private static bool ExistsAsFile(string assetPath)
        {
            return File.Exists(assetPath) && !Directory.Exists(assetPath);
        }

        /// <summary>読み込み済みのシーンの直下にある、指定名のオブジェクト。無ければ null。</summary>
        internal static GameObject FindSceneRoot(string name)
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded) continue;
                foreach (GameObject go in scene.GetRootGameObjects())
                {
                    if (go.name == name) return go;
                }
            }
            return null;
        }
    }
}
