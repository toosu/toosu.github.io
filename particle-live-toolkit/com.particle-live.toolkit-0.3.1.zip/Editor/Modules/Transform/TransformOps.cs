using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ParticleLiveToolkit.Modules.TransformTools
{
    /// <summary>
    /// Transform のリストを受け取ってシーンに適用する操作。Selection には依存しない。
    /// どの操作も 1 回呼ぶと Undo 1 回で戻る。対象は TopLevel で絞られる(親子を同時に渡しても子は二重に動かない)。
    /// 戻り値は変更した(ミラー複製では作成した)個数。対象が足りない・入力が NaN / 無限大のときは何もせず 0。
    /// </summary>
    public static class TransformOps
    {
        public const string MoveUndoName = "Transform: 移動";
        public const string RotateUndoName = "Transform: 回転";
        public const string ScaleUndoName = "Transform: スケール";
        public const string DistributeUndoName = "Transform: 等間隔配置";
        public const string CircleUndoName = "Transform: 円形配置";
        public const string MirrorUndoName = "Transform: ミラー";

        /// <summary>相対移動。local が true なら各オブジェクト自身の軸で動かす。</summary>
        public static int Move(IEnumerable<Transform> targets, Vector3 delta, bool local)
        {
            if (!TransformMath.IsFinite(delta)) return 0;
            List<Transform> list = TransformTargets.TopLevel(targets);
            if (list.Count == 0) return 0;

            int group = BeginGroup(MoveUndoName);
            foreach (Transform t in list)
            {
                Undo.RecordObject(t, MoveUndoName);
                t.position += local ? t.TransformDirection(delta) : delta;
            }
            EndGroup(group);
            return list.Count;
        }

        /// <summary>pivot(ワールド座標)まわりにワールド軸で回転する。位置も回る。</summary>
        public static int Rotate(IEnumerable<Transform> targets, Vector3 eulerDegrees, Vector3 pivot, Quaternion? axes = null)
        {
            if (!TransformMath.IsFinite(eulerDegrees) || !TransformMath.IsFinite(pivot)) return 0;
            List<Transform> list = TransformTargets.TopLevel(targets);
            if (list.Count == 0) return 0;

            Quaternion basis = axes ?? Quaternion.identity;
            Quaternion delta = basis * Quaternion.Euler(eulerDegrees) * Quaternion.Inverse(basis);
            int group = BeginGroup(RotateUndoName);
            foreach (Transform t in list)
            {
                Undo.RecordObject(t, RotateUndoName);
                t.SetPositionAndRotation(TransformMath.RotateAround(t.position, pivot, delta), delta * t.rotation);
            }
            EndGroup(group);
            return list.Count;
        }

        /// <summary>
        /// pivot(ワールド座標)を基準に拡縮する。位置はワールド軸ごとに、localScale は各軸の倍率を掛ける
        /// (回転したオブジェクトに不均一な倍率を掛けると見た目は厳密な拡縮にならない)。
        /// </summary>
        public static int Scale(IEnumerable<Transform> targets, Vector3 factor, Vector3 pivot, Quaternion? axes = null)
        {
            if (!TransformMath.IsFinite(factor) || !TransformMath.IsFinite(pivot)) return 0;
            List<Transform> list = TransformTargets.TopLevel(targets);
            if (list.Count == 0) return 0;

            int group = BeginGroup(ScaleUndoName);
            foreach (Transform t in list)
            {
                Undo.RecordObject(t, ScaleUndoName);
                Quaternion basis = axes ?? Quaternion.identity;
                t.position = pivot + basis * Vector3.Scale(Quaternion.Inverse(basis) * (t.position - pivot), factor);
                t.localScale = Vector3.Scale(t.localScale, factor);
            }
            EndGroup(group);
            return list.Count;
        }

        /// <summary>
        /// 渡した順に start から end まで等間隔に並べる。start / end が null なら並び順の先頭 / 末尾の現在位置。
        /// 2 個未満なら何もしない。
        /// </summary>
        public static int Distribute(IEnumerable<Transform> orderedTargets, Vector3? start, Vector3? end)
        {
            List<Transform> list = TransformTargets.TopLevel(orderedTargets);
            if (list.Count < 2) return 0;

            Vector3 from = start ?? list[0].position;
            Vector3 to = end ?? list[list.Count - 1].position;
            if (!TransformMath.IsFinite(from) || !TransformMath.IsFinite(to)) return 0;

            Vector3[] positions = TransformMath.EvenSpacing(from, to, list.Count);
            int group = BeginGroup(DistributeUndoName);
            for (int i = 0; i < list.Count; i++)
            {
                Undo.RecordObject(list[i], DistributeUndoName);
                list[i].position = positions[i];
            }
            EndGroup(group);
            return list.Count;
        }

        /// <summary>渡した順に円周へ等角度で並べる。faceCenter なら forward を中心へ向ける(半径 0 では向きは変えない)。2 個未満なら何もしない。</summary>
        public static int ArrangeCircle(IEnumerable<Transform> orderedTargets, Vector3 center, float radius, TransformAxis axis, float startAngleDegrees, bool faceCenter, Quaternion? axes = null)
        {
            if (!TransformMath.IsFinite(center) || !TransformMath.IsFinite(radius) || !TransformMath.IsFinite(startAngleDegrees)) return 0;
            List<Transform> list = TransformTargets.TopLevel(orderedTargets);
            if (list.Count < 2) return 0;

            Vector3[] positions = TransformMath.CirclePositions(center, radius, axis, startAngleDegrees, list.Count);
            int group = BeginGroup(CircleUndoName);
            for (int i = 0; i < list.Count; i++)
            {
                Transform t = list[i];
                Undo.RecordObject(t, CircleUndoName);
                Quaternion basis = axes ?? Quaternion.identity;
                t.position = center + basis * (positions[i] - center);
                if (faceCenter && TransformMath.TryFacing(positions[i], center, axis, out Quaternion facing))
                {
                    t.rotation = basis * facing;
                }
            }
            EndGroup(group);
            return list.Count;
        }

        /// <summary>
        /// pivot を通り axis に垂直な面でミラーする(位置と回転。スケールはそのまま)。
        /// duplicate が true なら元は動かさず、複製を反対側に置いて作った Transform を返す。false なら元を動かす。
        /// </summary>
        public static List<Transform> Mirror(IEnumerable<Transform> targets, Vector3 pivot, TransformAxis axis, bool duplicate, Quaternion? axes = null)
        {
            var created = new List<Transform>();
            if (!TransformMath.IsFinite(pivot)) return created;
            List<Transform> list = TransformTargets.TopLevel(targets);
            if (list.Count == 0) return created;

            // 先に全部計算してから動かす(複製・移動で他の対象の座標が変わらないようにする)。
            var positions = new Vector3[list.Count];
            var rotations = new Quaternion[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                Quaternion basis = axes ?? Quaternion.identity;
                var inverse = Quaternion.Inverse(basis);
                positions[i] = pivot + basis * TransformMath.MirrorDirection(inverse * (list[i].position-pivot), axis);
                rotations[i] = basis * TransformMath.MirrorRotation(inverse * list[i].rotation, axis);
            }

            int group = BeginGroup(MirrorUndoName);
            for (int i = 0; i < list.Count; i++)
            {
                Transform source = list[i];
                if (duplicate)
                {
                    Transform copy = CreateCopy(source);
                    copy.SetPositionAndRotation(positions[i], rotations[i]);
                    created.Add(copy);
                }
                else
                {
                    Undo.RecordObject(source, MirrorUndoName);
                    source.SetPositionAndRotation(positions[i], rotations[i]);
                }
            }
            EndGroup(group);
            if (!duplicate)
            {
                created.AddRange(list);
            }
            return created;
        }

        private static Transform CreateCopy(Transform source)
        {
            GameObject original = source.gameObject;
            GameObject copy = Object.Instantiate(original, source.parent, false);
            Undo.RegisterCreatedObjectUndo(copy, MirrorUndoName);
            ReconnectPrefab(original, copy);
            // Unity の Duplicate と同じく、兄弟の中で重複しない名前にする(階層パスで曖昧にならないように)。
            // コピー自身は "(Clone)" 付きの名前なので、元の名前で衝突判定される。
            copy.name = GameObjectUtility.GetUniqueNameForSibling(source.parent, original.name);
            if (source.parent == null && copy.scene != original.scene && original.scene.IsValid())
            {
                SceneManager.MoveGameObjectToScene(copy, original.scene);
            }
            copy.transform.SetSiblingIndex(source.GetSiblingIndex() + 1);
            return copy.transform;
        }

        /// <summary>
        /// Object.Instantiate で作った複製はプレハブとのつながりを失う(実測)ため、元がプレハブインスタンスの
        /// 最上位なら、同じプレハブへつなぎ直す(元の上書きは一致するプロパティについて引き継ぐ)。
        /// 失敗してもミラー自体は続ける(つながりのない複製になる)。
        /// </summary>
        private static void ReconnectPrefab(GameObject original, GameObject copy)
        {
            try
            {
                if (!PrefabUtility.IsAnyPrefabInstanceRoot(original)) return;
                if (PrefabUtility.GetOutermostPrefabInstanceRoot(original) != original) return;
                GameObject asset = PrefabUtility.GetCorrespondingObjectFromSource(original);
                if (asset == null || PrefabUtility.IsAnyPrefabInstanceRoot(copy)) return;
                var settings = new ConvertToPrefabInstanceSettings
                {
                    recordPropertyOverridesOfMatches = true,
                    changeRootNameToAssetName = false,
                    objectMatchMode = ObjectMatchMode.ByHierarchy,
                    logInfo = false,
                };
                PrefabUtility.ConvertToPrefabInstance(copy, asset, settings, InteractionMode.AutomatedAction);
            }
            catch (System.Exception)
            {
                // プレハブとのつながりを保てなかっただけなので無視する。
            }
        }

        private static int BeginGroup(string name)
        {
            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName(name);
            return Undo.GetCurrentGroup();
        }

        private static void EndGroup(int group)
        {
            Undo.FlushUndoRecordObjects();
            Undo.CollapseUndoOperations(group);
        }
    }
}
