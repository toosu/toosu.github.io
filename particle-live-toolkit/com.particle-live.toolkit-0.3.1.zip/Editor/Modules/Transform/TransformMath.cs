using UnityEngine;

namespace ParticleLiveToolkit.Modules.TransformTools
{
    /// <summary>座標計算で使う軸。ミラーでは「その軸に垂直な面」で反転する。</summary>
    public enum TransformAxis
    {
        X = 0,
        Y = 1,
        Z = 2,
    }

    /// <summary>
    /// Transform Editor の座標計算(UI・シーンに依存しない純粋関数)。
    /// </summary>
    public static class TransformMath
    {
        private const float MinDirectionSqr = 1e-12f;

        public static Vector3 AxisVector(TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X: return Vector3.right;
                case TransformAxis.Y: return Vector3.up;
                default: return Vector3.forward;
            }
        }

        /// <summary>
        /// start から end まで count 個を等間隔に並べた位置。count が 1 なら start だけ、0 以下なら空。
        /// </summary>
        public static Vector3[] EvenSpacing(Vector3 start, Vector3 end, int count)
        {
            if (count <= 0) return new Vector3[0];
            var result = new Vector3[count];
            if (count == 1)
            {
                result[0] = start;
                return result;
            }
            Vector3 step = (end - start) / (count - 1);
            for (int i = 0; i < count; i++)
            {
                result[i] = start + step * i;
            }
            result[count - 1] = end;
            return result;
        }

        /// <summary>
        /// 角度 0 のときの向き(軸に垂直)。X 軸: +Y、Y 軸: +Z、Z 軸: +X。
        /// 角度は軸まわりの右手系回転(Quaternion.AngleAxis と同じ向き)で増える。
        /// </summary>
        private static Vector3 ZeroAngleDirection(TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X: return Vector3.up;
                case TransformAxis.Y: return Vector3.forward;
                default: return Vector3.right;
            }
        }

        /// <summary>円周上の 1 点。</summary>
        public static Vector3 CirclePosition(Vector3 center, float radius, TransformAxis axis, float angleDegrees)
        {
            Vector3 direction = Quaternion.AngleAxis(angleDegrees, AxisVector(axis)) * ZeroAngleDirection(axis);
            return center + direction * radius;
        }

        /// <summary>円周上に count 個を等角度(360 / count)で並べた位置。1 個目が startAngleDegrees。</summary>
        public static Vector3[] CirclePositions(Vector3 center, float radius, TransformAxis axis, float startAngleDegrees, int count)
        {
            if (count <= 0) return new Vector3[0];
            var result = new Vector3[count];
            float step = 360f / count;
            for (int i = 0; i < count; i++)
            {
                result[i] = CirclePosition(center, radius, axis, startAngleDegrees + step * i);
            }
            return result;
        }

        /// <summary>
        /// from から target を向く回転(forward が target 向き、up が軸方向)。
        /// 2 点が同じ位置(半径 0)なら false を返し、rotation は identity。
        /// </summary>
        public static bool TryFacing(Vector3 from, Vector3 target, TransformAxis axis, out Quaternion rotation)
        {
            Vector3 direction = target - from;
            if (direction.sqrMagnitude < MinDirectionSqr)
            {
                rotation = Quaternion.identity;
                return false;
            }
            rotation = Quaternion.LookRotation(direction, AxisVector(axis));
            return true;
        }

        /// <summary>pivot を通り axis に垂直な面での点の反転。</summary>
        public static Vector3 MirrorPoint(Vector3 point, Vector3 pivot, TransformAxis axis)
        {
            Vector3 offset = point - pivot;
            return pivot + MirrorDirection(offset, axis);
        }

        /// <summary>方向ベクトルの反転(axis 成分の符号だけ変える)。</summary>
        public static Vector3 MirrorDirection(Vector3 direction, TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X: return new Vector3(-direction.x, direction.y, direction.z);
                case TransformAxis.Y: return new Vector3(direction.x, -direction.y, direction.z);
                default: return new Vector3(direction.x, direction.y, -direction.z);
            }
        }

        /// <summary>
        /// 回転の鏡像。鏡像後の forward と up が、元の forward と up を反転したものと一致する回転を返す
        /// (回転で表せる範囲なので right は反転の鏡像の逆向きになる)。
        /// </summary>
        public static Quaternion MirrorRotation(Quaternion rotation, TransformAxis axis)
        {
            Vector3 forward = MirrorDirection(rotation * Vector3.forward, axis);
            Vector3 up = MirrorDirection(rotation * Vector3.up, axis);
            return Quaternion.LookRotation(forward, up);
        }

        /// <summary>pivot まわりに点を回す。</summary>
        public static Vector3 RotateAround(Vector3 point, Vector3 pivot, Quaternion rotation)
        {
            return pivot + rotation * (point - pivot);
        }

        /// <summary>pivot を基準にワールド軸ごとに点を拡縮する。</summary>
        public static Vector3 ScaleAround(Vector3 point, Vector3 pivot, Vector3 factor)
        {
            return pivot + Vector3.Scale(point - pivot, factor);
        }

        public static bool IsFinite(Vector3 v)
        {
            return IsFinite(v.x) && IsFinite(v.y) && IsFinite(v.z);
        }

        public static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
