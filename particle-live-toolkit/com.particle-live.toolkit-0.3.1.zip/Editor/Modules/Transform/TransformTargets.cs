using System;
using System.Collections.Generic;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.TransformTools
{
    /// <summary>並べる順序。</summary>
    public enum TargetOrder
    {
        /// <summary>Hierarchy の上からの順。</summary>
        Hierarchy = 0,

        /// <summary>名前順(大文字小文字を区別しない。同名は Hierarchy 順)。</summary>
        Name = 1,
    }

    /// <summary>操作対象の絞り込みと並べ替え(Selection には依存しない)。</summary>
    public static class TransformTargets
    {
        /// <summary>
        /// null・破棄済み・重複を除き、選択に含まれる別の Transform の子孫になっているものも除く(親だけを対象にする)。
        /// 入力の順序は保つ。
        /// </summary>
        public static List<Transform> TopLevel(IEnumerable<Transform> source)
        {
            var result = new List<Transform>();
            if (source == null) return result;

            var all = new List<Transform>();
            var set = new HashSet<Transform>();
            foreach (Transform t in source)
            {
                if (t == null) continue;
                if (set.Add(t)) all.Add(t);
            }

            foreach (Transform t in all)
            {
                bool hasSelectedAncestor = false;
                for (Transform p = t.parent; p != null; p = p.parent)
                {
                    if (set.Contains(p))
                    {
                        hasSelectedAncestor = true;
                        break;
                    }
                }
                if (!hasSelectedAncestor) result.Add(t);
            }
            return result;
        }

        /// <summary>TopLevel の後、指定の順序に並べ替える(安定)。</summary>
        public static List<Transform> Resolve(IEnumerable<Transform> source, TargetOrder order)
        {
            List<Transform> list = TopLevel(source);
            SortStable(list, order == TargetOrder.Name ? (Comparison<Transform>)CompareName : CompareHierarchy);
            return list;
        }

        /// <summary>位置の平均(選択の中心)。空なら原点。</summary>
        public static Vector3 Center(IList<Transform> targets)
        {
            if (targets == null) return Vector3.zero;
            Vector3 sum = Vector3.zero;
            int count = 0;
            for (int i = 0; i < targets.Count; i++)
            {
                if (targets[i] == null) continue;
                sum += targets[i].position;
                count++;
            }
            return count == 0 ? Vector3.zero : sum / count;
        }

        /// <summary>Hierarchy 上の前後関係(親は子より前。シーンが違えばシーン順)。</summary>
        public static int CompareHierarchy(Transform a, Transform b)
        {
            if (ReferenceEquals(a, b)) return 0;
            int sceneCompare = a.gameObject.scene.handle.CompareTo(b.gameObject.scene.handle);
            if (sceneCompare != 0) return sceneCompare;

            List<int> pathA = SiblingPath(a);
            List<int> pathB = SiblingPath(b);
            int length = Math.Min(pathA.Count, pathB.Count);
            for (int i = 0; i < length; i++)
            {
                int c = pathA[i].CompareTo(pathB[i]);
                if (c != 0) return c;
            }
            return pathA.Count.CompareTo(pathB.Count);
        }

        private static int CompareName(Transform a, Transform b)
        {
            int c = string.Compare(a.name, b.name, StringComparison.OrdinalIgnoreCase);
            return c != 0 ? c : CompareHierarchy(a, b);
        }

        private static List<int> SiblingPath(Transform t)
        {
            var path = new List<int>();
            for (Transform p = t; p != null; p = p.parent)
            {
                path.Add(p.GetSiblingIndex());
            }
            path.Reverse();
            return path;
        }

        // List.Sort は不安定なので、挿入ソートで安定にする(対象は数十個程度)。
        private static void SortStable(List<Transform> list, Comparison<Transform> comparison)
        {
            for (int i = 1; i < list.Count; i++)
            {
                Transform item = list[i];
                int j = i - 1;
                while (j >= 0 && comparison(list[j], item) > 0)
                {
                    list[j + 1] = list[j];
                    j--;
                }
                list[j + 1] = item;
            }
        }
    }
}
