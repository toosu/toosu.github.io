using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.TransformTools
{
    /// <summary>回転・スケール・円形・ミラーの基準点の決め方。</summary>
    public enum PivotSource
    {
        SelectionCenter = 0,
        ActiveObject = 1,
        Custom = 2,
    }

    /// <summary>Transform Editor の画面(入力と描画だけ。計算は TransformMath / TransformOps)。</summary>
    public sealed class TransformModule : IToolkitModule
    {
        private const string NoSelectionReason = "シーンでオブジェクトを選んでください";
        private const string NeedTwoReason = "2 つ以上選んでください(親子を同時に選んだ場合は親だけが数えられます)";

        private static readonly string[] TabLabels = { "移動", "回転", "スケール", "等間隔", "円形", "ミラー" };
        private static readonly string[] PivotLabels = { "選択の中心", "アクティブオブジェクト", "任意座標" };
        private static readonly string[] OrderLabels = { "Hierarchy の上から", "名前順" };
        private static readonly string[] AxisLabels = { "X", "Y", "Z" };

        public string Id { get { return ToolkitModuleIds.Transform; } }

        public string DisplayName { get { return "Transform"; } }

        public int Order { get { return ToolkitModuleIds.TransformOrder; } }

        public void OnEnable(ToolkitContext ctx)
        {
        }

        public void OnDisable()
        {
        }

        public void OnGUI(ToolkitContext ctx)
        {
            ModuleState s = ctx.State(Id);

            Transform[] selected = Selection.GetTransforms(SelectionMode.Editable | SelectionMode.ExcludePrefab);
            TargetOrder order = (TargetOrder)Mathf.Clamp(s.GetInt("order", 0), 0, 1);

            ToolkitGUI.Section("対象");
            int newOrder = EditorGUILayout.Popup("並べる順序", (int)order, OrderLabels);
            if (newOrder != (int)order)
            {
                s.SetInt("order", newOrder);
                order = (TargetOrder)newOrder;
            }
            List<Transform> targets = TransformTargets.Resolve(selected, order);
            EditorGUILayout.LabelField(targets.Count == 0 ? "選択中: 0 個" : "対象: " + targets.Count + " 個");

            int tab = Mathf.Clamp(s.GetInt("tab", 0), 0, TabLabels.Length - 1);
            int newTab = GUILayout.Toolbar(tab, TabLabels);
            if (newTab != tab)
            {
                s.SetInt("tab", newTab);
                tab = newTab;
            }
            GUILayout.Space(4f);

            string noTarget = targets.Count == 0 ? NoSelectionReason : null;
            string needTwo = targets.Count == 0 ? NoSelectionReason : (targets.Count < 2 ? NeedTwoReason : null);

            if (tab != 0)
            {
                bool local = EditorGUILayout.Toggle("アクティブのローカル座標", s.GetBool("layout.local"));
                s.SetBool("layout.local", local);
            }
            switch (tab)
            {
                case 0: DrawMove(ctx, s, targets, noTarget); break;
                case 1: DrawRotate(ctx, s, targets, noTarget); break;
                case 2: DrawScale(ctx, s, targets, noTarget); break;
                case 3: DrawDistribute(ctx, s, targets, needTwo); break;
                case 4: DrawCircle(ctx, s, targets, needTwo); break;
                default: DrawMirror(ctx, s, targets, noTarget); break;
            }
        }

        private static Transform CoordinateFrame(ModuleState state) =>
            state.GetBool("layout.local") ? Selection.activeTransform : null;
        private static Quaternion Axes(ModuleState state) =>
            CoordinateFrame(state) ? CoordinateFrame(state).rotation : Quaternion.identity;
        private static Vector3 WorldPoint(ModuleState state, Vector3 point) =>
            CoordinateFrame(state) ? CoordinateFrame(state).TransformPoint(point) : point;

        private static void DrawMove(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("相対移動");
            bool local = EditorGUILayout.Toggle("ローカル軸で動かす", s.GetBool("move.local", false));
            s.SetBool("move.local", local);
            Vector3 delta = EditorGUILayout.Vector3Field("移動量(m)", GetVector(s, "move.delta", Vector3.zero));
            SetVector(s, "move.delta", delta);

            if (ToolkitGUI.PrimaryButton("移動する", disabledReason))
            {
                Notify(ctx, TransformOps.Move(targets, delta, local), "移動しました");
            }
        }

        private static void DrawRotate(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("回転");
            Vector3 euler = EditorGUILayout.Vector3Field("回転量(度)", GetVector(s, "rotate.euler", Vector3.zero));
            SetVector(s, "rotate.euler", euler);
            Vector3 pivot = DrawPivot(s, "rotate.pivot", "基準点", targets);

            if (ToolkitGUI.PrimaryButton("回転する", disabledReason))
            {
                Notify(ctx, TransformOps.Rotate(targets, euler, pivot, Axes(s)), "回転しました");
            }
        }

        private static void DrawScale(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("スケール");
            bool uniform = EditorGUILayout.Toggle("全軸まとめて", s.GetBool("scale.uniform", true));
            s.SetBool("scale.uniform", uniform);

            Vector3 factor;
            if (uniform)
            {
                float f = EditorGUILayout.FloatField("倍率", s.GetFloat("scale.factor", 1f));
                s.SetFloat("scale.factor", f);
                factor = new Vector3(f, f, f);
            }
            else
            {
                factor = EditorGUILayout.Vector3Field("倍率", GetVector(s, "scale.vector", Vector3.one));
                SetVector(s, "scale.vector", factor);
            }
            Vector3 pivot = DrawPivot(s, "scale.pivot", "基準点", targets);
            ToolkitGUI.Hint("位置は基準点からの距離が倍率で変わり、各オブジェクトのスケールにも同じ倍率を掛けます。");

            if (ToolkitGUI.PrimaryButton("スケールする", disabledReason))
            {
                Notify(ctx, TransformOps.Scale(targets, factor, pivot, Axes(s)), "スケールしました");
            }
        }

        private static void DrawDistribute(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("等間隔配置");
            bool custom = EditorGUILayout.Toggle("始点・終点を指定する", s.GetBool("dist.custom", false));
            s.SetBool("dist.custom", custom);

            Vector3? start = null;
            Vector3? end = null;
            if (custom)
            {
                Vector3 a = EditorGUILayout.Vector3Field("始点", GetVector(s, "dist.start", Vector3.zero));
                Vector3 b = EditorGUILayout.Vector3Field("終点", GetVector(s, "dist.end", new Vector3(10f, 0f, 0f)));
                SetVector(s, "dist.start", a);
                SetVector(s, "dist.end", b);
                start = WorldPoint(s,a);
                end = WorldPoint(s,b);
            }
            else
            {
                ToolkitGUI.Hint("始点と終点は、並び順の先頭と末尾の現在位置です。間のオブジェクトが均等に並びます。");
            }

            if (ToolkitGUI.PrimaryButton("等間隔に並べる", disabledReason))
            {
                Notify(ctx, TransformOps.Distribute(targets, start, end), "等間隔に並べました");
            }
        }

        private static void DrawCircle(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("円形配置");
            Vector3 center = DrawPivot(s, "circle.center", "中心", targets);
            float radius = Mathf.Max(0f, EditorGUILayout.FloatField("半径(m)", s.GetFloat("circle.radius", 5f)));
            s.SetFloat("circle.radius", radius);
            int axisIndex = EditorGUILayout.Popup("軸(この軸まわりに並べる)", Mathf.Clamp(s.GetInt("circle.axis", 1), 0, 2), AxisLabels);
            s.SetInt("circle.axis", axisIndex);
            float startAngle = EditorGUILayout.FloatField("開始角度(度)", s.GetFloat("circle.angle", 0f));
            s.SetFloat("circle.angle", startAngle);
            bool face = EditorGUILayout.Toggle("中心を向く", s.GetBool("circle.face", false));
            s.SetBool("circle.face", face);

            if (ToolkitGUI.PrimaryButton("円形に並べる", disabledReason))
            {
                Notify(ctx, TransformOps.ArrangeCircle(targets, center, radius, (TransformAxis)axisIndex, startAngle, face, Axes(s)), "円形に並べました");
            }
        }

        private static void DrawMirror(ToolkitContext ctx, ModuleState s, List<Transform> targets, string disabledReason)
        {
            ToolkitGUI.Section("ミラー");
            // ミラーの基準は「任意座標(原点)」が既定。選択の中心だと全員が中心で重なってしまうため。
            Vector3 pivot = DrawPivot(s, "mirror.pivot", "基準点", targets, (int)PivotSource.Custom);
            int axisIndex = EditorGUILayout.Popup("反転する軸", Mathf.Clamp(s.GetInt("mirror.axis", 0), 0, 2), AxisLabels);
            s.SetInt("mirror.axis", axisIndex);
            bool duplicate = EditorGUILayout.Toggle("複製して反対側に置く", s.GetBool("mirror.duplicate", true));
            s.SetBool("mirror.duplicate", duplicate);
            ToolkitGUI.Hint(duplicate
                ? "元のオブジェクトはそのままで、反対側に複製を置きます。"
                : "選んだオブジェクト自体を反対側へ移動します。");

            if (ToolkitGUI.PrimaryButton(duplicate ? "ミラー複製する" : "ミラー移動する", disabledReason))
            {
                List<Transform> result = TransformOps.Mirror(targets, pivot, (TransformAxis)axisIndex, duplicate, Axes(s));
                Notify(ctx, result.Count, duplicate ? "ミラー複製しました" : "ミラー移動しました");
            }
        }

        private static Vector3 DrawPivot(ModuleState s, string key, string label, List<Transform> targets, int defaultMode = 0)
        {
            int mode = Mathf.Clamp(s.GetInt(key + ".mode", defaultMode), 0, 2);
            mode = EditorGUILayout.Popup(label, mode, PivotLabels);
            s.SetInt(key + ".mode", mode);

            if (mode == (int)PivotSource.Custom)
            {
                Vector3 custom = EditorGUILayout.Vector3Field("座標", GetVector(s, key + ".custom", Vector3.zero));
                SetVector(s, key + ".custom", custom);
                return WorldPoint(s, custom);
            }
            return ResolvePivot((PivotSource)mode, Vector3.zero, targets, Selection.activeTransform);
        }

        /// <summary>基準点の決定。アクティブオブジェクトが無いときは選択の中心。</summary>
        public static Vector3 ResolvePivot(PivotSource mode, Vector3 custom, IList<Transform> targets, Transform active)
        {
            switch (mode)
            {
                case PivotSource.Custom:
                    return custom;
                case PivotSource.ActiveObject:
                    if (active != null) return active.position;
                    return TransformTargets.Center(targets);
                default:
                    return TransformTargets.Center(targets);
            }
        }

        private static void Notify(ToolkitContext ctx, int count, string message)
        {
            if (count > 0)
            {
                ctx.ShowNotification(count + " 個を" + message);
            }
            else
            {
                ctx.ShowNotification("何も変更しませんでした(入力値を確認してください)");
            }
        }

        private static Vector3 GetVector(ModuleState s, string key, Vector3 defaultValue)
        {
            return new Vector3(
                s.GetFloat(key + ".x", defaultValue.x),
                s.GetFloat(key + ".y", defaultValue.y),
                s.GetFloat(key + ".z", defaultValue.z));
        }

        private static void SetVector(ModuleState s, string key, Vector3 value)
        {
            s.SetFloat(key + ".x", value.x);
            s.SetFloat(key + ".y", value.y);
            s.SetFloat(key + ".z", value.z);
        }
    }
}
