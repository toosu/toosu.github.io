using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.BeatCalculator
{
    /// <summary>
    /// 曲の BPM から「N 分」音符の秒数を一覧表示し、行ごとにクリップボードへコピーする。描画だけを担当する
    /// (計算は BeatCalculatorModel)。
    /// </summary>
    public sealed class BeatCalculatorModule : IToolkitModule
    {
        internal const string MultiplierKey = "multiplier";
        internal const string FrameRateKey = "frameRate";

        private const float DivisionWidth = 56f;
        private const float SecondsWidth = 90f;
        private const float FramesWidth = 90f;

        public string Id { get { return ToolkitModuleIds.Beat; } }

        public string DisplayName { get { return "Beat"; } }

        public int Order { get { return ToolkitModuleIds.BeatOrder; } }

        public void OnEnable(ToolkitContext ctx)
        {
        }

        public void OnDisable()
        {
        }

        public void OnGUI(ToolkitContext ctx)
        {
            if (ctx == null) return;
            ModuleState state = ctx.State(Id);

            ToolkitGUI.Section("BPM と倍率");

            EditorGUI.BeginChangeCheck();
            double bpm = EditorGUILayout.DelayedDoubleField("BPM", ctx.Bpm);
            if (EditorGUI.EndChangeCheck()) ctx.SetBpm(bpm);

            double multiplier = state.GetDouble(MultiplierKey, BeatCalculatorModel.DefaultMultiplier);
            EditorGUI.BeginChangeCheck();
            multiplier = EditorGUILayout.DoubleField("倍率 ×N", multiplier);
            if (EditorGUI.EndChangeCheck()) state.SetDouble(MultiplierKey, multiplier);

            double frameRate = state.GetDouble(FrameRateKey, BeatCalculatorModel.DefaultFrameRate);
            EditorGUI.BeginChangeCheck();
            frameRate = EditorGUILayout.DoubleField("フレームレート", frameRate);
            if (EditorGUI.EndChangeCheck()) state.SetDouble(FrameRateKey, frameRate);

            if (!BeatCalculatorModel.IsValidMultiplier(multiplier))
            {
                ToolkitGUI.Warning("倍率は 0 より大きい値にしてください。今は 1 として計算しています。");
            }
            if (!BeatCalculatorModel.IsValidFrameRate(frameRate))
            {
                ToolkitGUI.Warning("フレームレートは 0 より大きい値にしてください。今は 60 として計算しています。");
            }

            ToolkitGUI.Section("N 分の秒数");

            List<BeatRow> rows = BeatCalculatorModel.BuildRows(ctx.Bpm, multiplier, frameRate, ctx.NoteDivisions);
            if (rows.Count == 0)
            {
                ToolkitGUI.Hint("表示できる行がありません。BPM を 0 より大きい値にしてください。");
            }
            else
            {
                DrawHeader();
                foreach (BeatRow row in rows)
                {
                    DrawRow(row, ctx);
                }
            }

            ToolkitGUI.Section("秒数から換算");
            double duration = EditorGUILayout.DoubleField("秒数", state.GetDouble("convert.seconds", 1));
            if (duration >= 0 && !double.IsInfinity(duration))
            {
                state.SetDouble("convert.seconds", duration);
                double beats = duration / BeatMath.BeatSeconds(ctx.Bpm);
                EditorGUILayout.LabelField($"{beats:0.######} 拍   {beats / ctx.BeatsPerBar:0.######} 小節   {duration * BeatCalculatorModel.SanitizeFrameRate(frameRate):0.###} フレーム");
            }
            ToolkitGUI.Section("1 小節");
            string barText = BeatCalculatorModel.BarSecondsText(ctx.Bpm, ctx.BeatsPerBar);
            if (barText != null)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label(ctx.BeatsPerBar + "拍", GUILayout.Width(DivisionWidth));
                    GUILayout.Label(barText, GUILayout.Width(SecondsWidth));
                    GUILayout.Space(FramesWidth + 4f);
                    ToolkitGUI.CopyButton(barText, ctx);
                }
            }
        }

        private static void DrawHeader()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label("音符", EditorStyles.miniLabel, GUILayout.Width(DivisionWidth));
                GUILayout.Label("秒数", EditorStyles.miniLabel, GUILayout.Width(SecondsWidth));
                GUILayout.Label("フレーム数", EditorStyles.miniLabel, GUILayout.Width(FramesWidth));
            }
        }

        private static void DrawRow(BeatRow row, ToolkitContext ctx)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label(row.Division + "分", GUILayout.Width(DivisionWidth));
                GUILayout.Label(row.SecondsText, GUILayout.Width(SecondsWidth));
                GUILayout.Label(row.FramesText, GUILayout.Width(FramesWidth));
                ToolkitGUI.CopyButton(row.SecondsText, ctx);
            }
        }
    }
}
