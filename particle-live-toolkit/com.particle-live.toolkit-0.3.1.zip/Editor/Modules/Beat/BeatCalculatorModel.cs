using System.Collections.Generic;
using System.Globalization;
using ParticleLiveToolkit.Core;

namespace ParticleLiveToolkit.Modules.BeatCalculator
{
    /// <summary>「N 分」1 行ぶんの表示データ。</summary>
    public readonly struct BeatRow
    {
        public BeatRow(int division, string secondsText, double frames, string framesText)
        {
            Division = division;
            SecondsText = secondsText;
            Frames = frames;
            FramesText = framesText;
        }

        /// <summary>N 分の N。</summary>
        public int Division { get; }

        /// <summary>表示・コピーする秒数(小数 6 桁)。</summary>
        public string SecondsText { get; }

        /// <summary>フレーム数(丸めない値)。</summary>
        public double Frames { get; }

        /// <summary>表示用のフレーム数(小数 3 桁まで、末尾の 0 は省く)。</summary>
        public string FramesText { get; }
    }

    /// <summary>Beat Calculator の計算と行データの組み立て(UI なし)。</summary>
    public static class BeatCalculatorModel
    {
        public const double DefaultMultiplier = 1.0;
        public const double DefaultFrameRate = 60.0;

        /// <summary>倍率として使える値か(0 より大きい有限値)。</summary>
        public static bool IsValidMultiplier(double value)
        {
            return value > 0.0 && !double.IsInfinity(value);
        }

        /// <summary>フレームレートとして使える値か(0 より大きい有限値)。</summary>
        public static bool IsValidFrameRate(double value)
        {
            return value > 0.0 && !double.IsInfinity(value);
        }

        /// <summary>不正な倍率は既定(1)に戻す。</summary>
        public static double SanitizeMultiplier(double value)
        {
            return IsValidMultiplier(value) ? value : DefaultMultiplier;
        }

        /// <summary>不正なフレームレートは既定(60)に戻す。</summary>
        public static double SanitizeFrameRate(double value)
        {
            return IsValidFrameRate(value) ? value : DefaultFrameRate;
        }

        /// <summary>
        /// divisions の順に 1 行ずつ作る。0 以下の分母は飛ばす。bpm が不正なら行なし。
        /// 倍率・フレームレートが不正なときは既定値に戻して計算する。
        /// </summary>
        public static List<BeatRow> BuildRows(double bpm, double multiplier, double frameRate, IReadOnlyList<int> divisions)
        {
            var rows = new List<BeatRow>();
            if (!(bpm > 0.0) || double.IsInfinity(bpm) || divisions == null) return rows;

            double m = SanitizeMultiplier(multiplier);
            double fps = SanitizeFrameRate(frameRate);
            for (int i = 0; i < divisions.Count; i++)
            {
                int division = divisions[i];
                if (division <= 0) continue;
                double seconds = BeatMath.NoteSeconds(bpm, division, m);
                double frames = BeatMath.SecondsToFrames(seconds, fps);
                rows.Add(new BeatRow(division, BeatMath.FormatSeconds(seconds), frames, FormatFrames(frames)));
            }
            return rows;
        }

        /// <summary>1 小節の秒数の文字列(小数 6 桁)。bpm / 拍数が不正なら null。</summary>
        public static string BarSecondsText(double bpm, int beatsPerBar)
        {
            if (!(bpm > 0.0) || double.IsInfinity(bpm) || beatsPerBar <= 0) return null;
            return BeatMath.FormatSeconds(BeatMath.BarSeconds(bpm, beatsPerBar));
        }

        /// <summary>フレーム数を小数 3 桁まで・末尾の 0 を省いて表示する。例: 28.125 → "28.125"、30 → "30"。</summary>
        public static string FormatFrames(double frames)
        {
            if (double.IsNaN(frames) || double.IsInfinity(frames)) return "-";
            return frames.ToString("0.###", CultureInfo.InvariantCulture);
        }
    }
}
