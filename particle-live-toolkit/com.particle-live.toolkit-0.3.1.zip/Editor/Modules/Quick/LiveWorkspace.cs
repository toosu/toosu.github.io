using System;
using System.Linq;
using System.Collections.Generic;
using ParticleLiveToolkit.Modules.LivePreview;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Timeline;
using UnityEditor.Timeline.Actions;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.SceneManagement;
using UnityEngine.Timeline;

namespace ParticleLiveToolkit.Modules.Quick
{
    public sealed class LiveWorkspace : IToolkitModule
    {
        public string Id => "workspace";
        public string DisplayName => "ライブの編集";
        public int Order => 1;
        ParticleLiveProject choice;
        public void OnEnable(ToolkitContext ctx) { choice = ctx.ActiveProject; }
        public void OnDisable() { }

        public void OnGUI(ToolkitContext ctx)
        {
            var p = ctx.ActiveProject;
            using (new EditorGUI.DisabledScope(!p))
            {
                if (GUILayout.Button("このライブの編集に戻る"))
                {
                    string result = Resume(p);
                    if (result != null) ctx.ShowNotification(result);
                }
                if (p) EditorGUILayout.LabelField("再開フレーム", Math.Round(Time(p) * Fps(p)).ToString("0"));
            }
            ToolkitGUI.Section("ライブ別の設定");
            choice = (ParticleLiveProject)EditorGUILayout.ObjectField("読み込むライブ", choice, typeof(ParticleLiveProject), false);
            using (new EditorGUI.DisabledScope(!choice))
                if (GUILayout.Button("ライブ設定を読み込む"))
                {
                    ctx.SetActiveProject(choice);
                    ctx.ShowNotification(choice.name + " の設定を読み込みました");
                }
            using (new EditorGUI.DisabledScope(!p))
                if (GUILayout.Button("現在のライブ設定を保存"))
                {
                    SaveSettings(p);
                    ctx.ShowNotification(p.name + " に保存しました");
                }
            using (new EditorGUI.DisabledScope(!p || string.IsNullOrEmpty(p.savedToolkitSettings)))
                if (GUILayout.Button("保存時のツール設定を復元"))
                {
                    RestoreSettings(ctx);
                    ctx.ShowNotification("保存した設定を復元しました");
                }
        }

        [Serializable]
        sealed class Snapshot
        {
            public double bpm, offset;
            public int meter;
            public int[] divisions;
            public List<ParticleLiveProject.EditorSetting> values;
        }
        internal static void SaveSettings(ParticleLiveProject p)
        {
            Undo.RecordObject(p, "ライブのツール設定を保存");
            p.savedToolkitSettings = JsonUtility.ToJson(new Snapshot {
                bpm = p.bpm, offset = p.offsetSeconds, meter = p.beatsPerBar,
                divisions = p.noteDivisions, values = p.editorSettings });
            LiveSettings.Dirty(p);
            LiveSettings.Flush();
        }
        internal static void RestoreSettings(ToolkitContext ctx)
        {
            var p = ctx.ActiveProject;
            if (!p || string.IsNullOrEmpty(p.savedToolkitSettings)) return;
            var snapshot = JsonUtility.FromJson<Snapshot>(p.savedToolkitSettings);
            if (snapshot == null || !(snapshot.bpm > 0)) return;
            ctx.RecordProjectEdit("保存時のツール設定を復元");
            p.bpm = snapshot.bpm;
            p.offsetSeconds = snapshot.offset;
            p.beatsPerBar = snapshot.meter;
            p.noteDivisions = snapshot.divisions;
            p.editorSettings = snapshot.values ?? new List<ParticleLiveProject.EditorSetting>();
            var player = LivePreviewService.CurrentPlayerOrNull;
            if (player != null && player.Project == p)
            {
                player.Shutdown();
                player.Settings.CopyFrom(PreviewSettings.Load(ctx.State("preview")));
            }
            ctx.NotifyProjectEdited();
            LiveSettings.Flush();
        }

        internal static double Fps(ParticleLiveProject p) => p && p.mainClip && p.mainClip.frameRate > 0 ? p.mainClip.frameRate : 60;
        internal static double Time(ParticleLiveProject p) => new ModuleState("workspace", () => p).GetDouble("time");
        internal static void Remember(ParticleLiveProject p, double time)
        {
            if (p && time >= 0 && !double.IsInfinity(time)) new ModuleState("workspace", () => p).SetDouble("time", time);
        }

        internal static string Resume(ParticleLiveProject p)
        {
            if (!p || !p.mainClip) return "ライブ設定の Main Clip を確認してください";
            if (GlobalObjectId.TryParse(p.rootGlobalId, out var id))
            {
                string path = AssetDatabase.GUIDToAssetPath(id.assetGUID.ToString());
                if (string.IsNullOrEmpty(path)) return "ライブのシーンが見つかりません";
                var scene = SceneManager.GetSceneByPath(path);
                if (!scene.isLoaded) EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
            }
            var root = ProjectSceneUtility.FindRoot(p);
            if (!root) return "ライブのルートが見つかりません";
            SceneManager.SetActiveScene(root.scene);
            double seconds = Time(p);
            foreach (var director in root.GetComponentsInChildren<PlayableDirector>(true))
            {
                if (!(director.playableAsset is TimelineAsset timeline)) continue;
                foreach (var track in timeline.GetOutputTracks().OfType<AnimationTrack>())
                {
                    var clip = track.GetClips().FirstOrDefault(c => c.animationClip == p.mainClip);
                    if (clip == null || !director.GetGenericBinding(track)) continue;
                    Selection.activeGameObject = director.gameObject;
                    var window = TimelineEditor.GetOrCreateWindow();
                    window.SetTimeline(director);
                    window.playbackControls.Pause();
                    window.playbackControls.SetCurrentTime(seconds);
                    // Use the same action as Timeline's “Edit in Animation Window” so sound,
                    // recording and the animation binding use Timeline's time controller.
                    var type = typeof(TimelineEditor).Assembly.GetType("UnityEditor.Timeline.EditClipInAnimationWindow");
                    if (type != null && Activator.CreateInstance(type, true) is ClipAction action &&
                        action.Execute(new[] { clip })) return null;
                    return "Timeline を開きました。演出クリップをダブルクリックしてください";
                }
            }
            var animator = root.GetComponentsInChildren<Animator>(true).FirstOrDefault(a =>
                a.runtimeAnimatorController && a.runtimeAnimatorController.animationClips.Contains(p.mainClip));
            if (!animator) return "Main Clip の Animator または Timeline バインドが見つかりません";
            Selection.activeGameObject = animator.gameObject;
            var animation = EditorWindow.GetWindow<AnimationWindow>();
            animation.animationClip = p.mainClip;
            animation.time = (float)seconds;
            return null;
        }
    }
}
