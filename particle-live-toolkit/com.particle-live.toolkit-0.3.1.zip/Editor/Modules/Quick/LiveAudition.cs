using System;
using System.Reflection;
using System.Runtime.InteropServices;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.AnimationRepeat;
using ParticleLiveToolkit.Modules.LivePreview;
using UnityEditor;
using UnityEditor.Timeline;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UIElements;

namespace ParticleLiveToolkit.Modules.Quick
{
    [InitializeOnLoad]
    internal static class LiveAudition
    {
        const double HoldSeconds = 0.30;
        static ParticleLiveProject project;
        static GameObject root;
        static bool loaded, down, held, sawKeyDown;
        static EditorWindow window;
        static double pressedAt, origin, nextSample, lastPosition;
        static bool lastValid, physicalDown;
        static readonly EditorPreviewAudio audio = new EditorPreviewAudio();
        const BindingFlags Instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static readonly PropertyInfo animState = typeof(AnimationWindow).GetProperty("state", Instance);
        static readonly PropertyInfo linked = animState?.PropertyType.GetProperty("linkedWithSequencer", Instance);
        static readonly PropertyInfo timelineState = typeof(TimelineEditor).GetProperty("state", BindingFlags.NonPublic | BindingFlags.Static);
        static readonly PropertyInfo timelinePlaying = timelineState?.PropertyType.GetProperty("playing", Instance);

        static LiveAudition()
        {
            EditorApplication.update += Tick;
            AssemblyReloadEvents.beforeAssemblyReload += SaveAndStop;
            EditorApplication.quitting += SaveAndStop;
        }

        internal static void Select(ParticleLiveProject p)
        {
            if (!loaded || p != project) { Cancel(); root = null; project = p; loaded = true; }
        }

        internal static bool Owns(ParticleLiveProject p, PlayableDirector director)
        {
            if (!p || !director) return false;
            var owner = p == project && root ? root : ProjectSceneUtility.FindRoot(p);
            if (p == project) root = owner;
            return owner && director.transform.IsChildOf(owner.transform);
        }

        static bool Matches()
        {
            if (!project || !window || EditorApplication.isPlayingOrWillChangePlaymode) return false;
            if (window is TimelineEditorWindow) return Owns(project, TimelineEditor.inspectedDirector);
            if (!(window is AnimationWindow a) || !project.mainClip || a.animationClip != project.mainClip) return false;
            if (Linked(a)) return Owns(project, TimelineEditor.inspectedDirector);
            var go = AnimationWindowBridge.GetEditedRoot(a);
            if (!root) root = ProjectSceneUtility.FindRoot(project);
            return go && root && go.transform.IsChildOf(root.transform);
        }

        static readonly PropertyInfo control = animState?.PropertyType.GetProperty("controlInterface", Instance);
        static bool Linked(AnimationWindow a)
        {
            var state = animState?.GetValue(a);
            return state != null && (linked?.GetValue(state) as bool? == true ||
                control?.GetValue(state)?.GetType().Assembly == typeof(TimelineEditor).Assembly);
        }
        static double Position => window is AnimationWindow a ? a.time : ((TimelineEditorWindow)window).playbackControls.GetCurrentTime();
        static bool Playing => window is AnimationWindow a ? a.playing :
            timelinePlaying?.GetValue(timelineState.GetValue(null)) as bool? == true;

        static void Tick()
        {
            if (!loaded) Select(ActiveProjectMemory.Load());
            var focus = EditorWindow.focusedWindow;
            if (focus != window)
            {
                Cancel();
                if (window) { window.rootVisualElement.UnregisterCallback<KeyDownEvent>(KeyDown, TrickleDown.TrickleDown); window.rootVisualElement.UnregisterCallback<KeyUpEvent>(KeyUp, TrickleDown.TrickleDown); }
                physicalDown = lastValid = false;
                window = focus is AnimationWindow || focus is TimelineEditorWindow ? focus : null;
                if (window) { window.rootVisualElement.RegisterCallback<KeyDownEvent>(KeyDown, TrickleDown.TrickleDown); window.rootVisualElement.RegisterCallback<KeyUpEvent>(KeyUp, TrickleDown.TrickleDown); }
            }
            if (!window || !UnityEditorInternal.InternalEditorUtility.isApplicationActive) { Cancel(); lastValid = false; return; }
#if UNITY_EDITOR_WIN
            bool physical = PhysicalSpace();
            // Unity's native shortcut handler can consume KeyDown before UI Toolkit.
            if (!down && physical && !physicalDown && lastValid && !EditorGUIUtility.editingTextField &&
                !OtherModifier() && Matches()) Begin(lastPosition);
            physicalDown = physical;
#endif
            if (down)
            {
                if (!Matches()) { Reset(); return; }
#if UNITY_EDITOR_WIN
                if (!PhysicalSpace()) { Finish(); return; }
#endif
                if (!held && EditorApplication.timeSinceStartup - pressedAt >= HoldSeconds) StartHold();
            }
            else
            {
                lastValid = Matches();
                if (!lastValid) return;
                lastPosition = Position;
                if (!Playing && EditorApplication.timeSinceStartup >= nextSample)
                {
                    nextSample = EditorApplication.timeSinceStartup + 0.08;
                    Remember();
                }
            }
        }

#if UNITY_EDITOR_WIN
        [DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
        static bool OtherModifier() => ((GetAsyncKeyState(0x10) | GetAsyncKeyState(0x11) | GetAsyncKeyState(0x12) | GetAsyncKeyState(0x5b) | GetAsyncKeyState(0x5c)) & 0x8000) != 0;
        static bool PhysicalSpace() => (GetAsyncKeyState(0x20) & 0x8000) != 0;
#endif

        static void KeyDown(KeyDownEvent e)
        {
            if (e.keyCode != KeyCode.Space || e.modifiers != EventModifiers.None || EditorGUIUtility.editingTextField ||
                e.target is TextElement || !Matches()) return;
            if (down && sawKeyDown) { e.StopImmediatePropagation(); e.PreventDefault(); return; }
            if (!down) Begin(Position);
            sawKeyDown = true;
        }
        static void Begin(double at)
        {
            pressedAt = EditorApplication.timeSinceStartup;
            origin = at;
            down = true;
            // Leave the initial event to Unity's normal play/pause shortcut.
        }
        static void KeyUp(KeyUpEvent e) { if (down && e.keyCode == KeyCode.Space) Finish(); }

        static void StartHold()
        {
            held = true;
            if (window is AnimationWindow a)
            {
                if (!a.playing) { a.time = (float)origin; if (a.canPreview) a.previewing = true; a.playing = true; }
                if (!Linked(a) && project.song && a.time < project.song.length) audio.Play(project.song, a.time);
            }
            else if (!Playing) ((TimelineEditorWindow)window).playbackControls.Play();
        }

        static void Finish()
        {
            if (!down) return;
            if ((held || EditorApplication.timeSinceStartup - pressedAt >= HoldSeconds) && Matches())
            {
                if (window is AnimationWindow a) { a.playing = false; a.time = (float)origin; }
                else { var controls = ((TimelineEditorWindow)window).playbackControls; controls.Pause(); controls.SetCurrentTime(origin); }
                Remember();
                window.Repaint();
            }
            Reset();
        }

        static void Remember()
        {
            var a = window as AnimationWindow;
            double time = a && Linked(a) && TimelineEditor.GetWindow() ? TimelineEditor.GetWindow().playbackControls.GetCurrentTime() : Position;
            LiveWorkspace.Remember(project, time);
        }

        static void SaveAndStop()
        {
            if (down) Cancel();
            else if (Matches() && !Playing) Remember();
            LiveSettings.Flush();
        }

        static void Cancel() { if (down) Finish(); }
        static void Reset() { audio.Stop(); sawKeyDown = held = down = false; }
    }
}
