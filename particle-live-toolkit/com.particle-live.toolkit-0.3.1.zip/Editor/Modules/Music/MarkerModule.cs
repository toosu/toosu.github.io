using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Modules.Quick;
using UnityEditor.Timeline;
using System.Linq;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.AnimationRepeat;
using ParticleLiveToolkit.Modules.LivePreview;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.Music
{
    public sealed class MarkerModule : IToolkitModule
    {
        public string Id => "markers";
        public string DisplayName => "Marker System";
        public int Order => 33;
        private GUIStyle nameStyle;
        public void OnEnable(ToolkitContext ctx) { }
        public void OnDisable() { }
        public void OnGUI(ToolkitContext ctx)
        {
            if (!ToolkitGUI.RequireProject(ctx)) return;
            var project = ctx.ActiveProject;
            var list = project.markers;
            double fps = LiveWorkspace.Fps(project);
            EditorGUILayout.LabelField($"フレーム  ({fps:0.###} fps)", EditorStyles.boldLabel);
            if (GUILayout.Button("現在位置にマーカーを追加"))
            {
                var bridge = new AnimationWindowBridge();
                double time = LiveWorkspace.Time(project);
                if (TimelineEditor.inspectedDirector && LiveAudition.Owns(project, TimelineEditor.inspectedDirector))
                    time = TimelineEditor.GetWindow().playbackControls.GetCurrentTime();
                else if (bridge.TryGetClip(out var current, out _) && current == project.mainClip && bridge.TryGetTime(out double at, out _)) time = at;
                else if (LivePreviewService.Player.Project == project && LivePreviewService.Player.IsPlaying) time = LivePreviewService.Player.CurrentTime;
                ctx.RecordProjectEdit("マーカー追加");
                if (list == null) list = project.markers = new List<LiveMarker>();
                list.Add(new LiveMarker { name = "Marker " + (list.Count + 1), time = time });
                ctx.NotifyProjectEdited();
            }
            if (list == null) return;
            for (int i = 0; i < list.Count; i++)
            {
                var m = list[i];
                if (m == null) continue;
                {
                    float height = EditorGUIUtility.singleLineHeight;
                    float rowHeight = height * 2 + EditorGUIUtility.standardVerticalSpacing;
                    var bounds = EditorGUILayout.GetControlRect(false, rowHeight);
                    var row = new MarkerRow(bounds, height);
                    if (nameStyle == null) nameStyle = new GUIStyle(EditorStyles.textField) { fontSize = 11 };
                    EditorGUI.BeginChangeCheck();
                    var color = EditorGUI.ColorField(row.Color, GUIContent.none, m.color, false, true, false);
                    string name = EditorGUI.DelayedTextField(row.Name, m.name, nameStyle);
                    int oldFrame = (int)Math.Min(int.MaxValue, Math.Round(m.time * fps, MidpointRounding.AwayFromZero));
                    int frame = Math.Max(0, EditorGUI.DelayedIntField(row.Time, GUIContent.none, oldFrame));
                    GUI.Label(row.Unit, "f", EditorStyles.miniLabel);
                    if (EditorGUI.EndChangeCheck())
                    {
                        ctx.RecordProjectEdit("マーカー編集");
                        m.color = color; m.name = name; if (frame != oldFrame) m.time = frame / fps;
                        ctx.NotifyProjectEdited();
                    }
                    if (GUI.Button(row.Jump, "移動"))
                    {
                        LiveWorkspace.Remember(project, m.time);
                        if (LiveAudition.Owns(project, TimelineEditor.inspectedDirector)) TimelineEditor.GetWindow().playbackControls.SetCurrentTime(m.time);
                        var window = AnimationWindowBridge.FindWindow(out _);
                        if (window && window.animationClip == project.mainClip) window.time = (float)m.time;
                        var player = LivePreviewService.Player;
                        player.Project = project;
                        player.SetStartPosition(m.time);
                        if (player.IsPlaying) player.Seek(m.time);
                        player.Settings.Save(LivePreviewService.State);
                    }
                    if (GUI.Button(row.Delete, "削除"))
                    {
                        ctx.RecordProjectEdit("マーカー削除"); list.RemoveAt(i); ctx.NotifyProjectEdited(); GUIUtility.ExitGUI();
                    }
                }
            }
        }

        internal readonly struct MarkerRow
        {
            internal readonly Rect Color, Name, Time, Unit, Jump, Delete;
            internal MarkerRow(Rect bounds, float height)
            {
                const float gap = 4, swatch = 24, seconds = 92, unit = 18, button = 44;
                float fieldsRight = Mathf.Min(bounds.xMax, bounds.x + 330);
                Color = new Rect(bounds.x, bounds.y, swatch, height);
                Unit = new Rect(fieldsRight - unit, bounds.y, unit, height);
                float timeWidth = Mathf.Clamp((fieldsRight - bounds.x - unit - swatch - 3 * gap) * 0.50f, 0, seconds);
                Time = new Rect(Unit.x - timeWidth - gap, bounds.y, timeWidth, height);
                float nameX = Color.xMax + gap;
                Name = new Rect(nameX, bounds.y, Mathf.Max(0, Time.x - gap - nameX), height);
                float buttonY = bounds.yMax - height;
                Delete = new Rect(fieldsRight - button, buttonY, button, height);
                Jump = new Rect(Delete.x - gap - button, buttonY, button, height);
            }
        }

        internal static void Pick(string label, ParticleLiveProject project, Action<double> apply)
        {
            if (!project || project.markers == null || project.markers.Count == 0) return;
            var markers = project.markers.Where(m => m != null).OrderBy(m => m.time).ToArray();
            string[] labels = new[] { label }.Concat(markers.Select(m => Math.Round(m.time * LiveWorkspace.Fps(project), MidpointRounding.AwayFromZero).ToString("0") + " f   " + m.name)).ToArray();
            int selection = EditorGUILayout.Popup(0, labels);
            if (selection > 0) apply(markers[selection - 1].time);
        }
    }
}
