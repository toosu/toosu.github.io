using System;
using System.Collections.Generic;
using System.Linq;
using ParticleLiveToolkit.Core;
using ParticleLiveToolkit.Modules.AnimationRepeat;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.Music
{
    public sealed class BeatSnapModule : IToolkitModule
    {
        public string Id => "snap";
        public string DisplayName => "Beat Snap";
        public int Order => 32;
        public void OnEnable(ToolkitContext ctx) { }
        public void OnDisable() { }

        public void OnGUI(ToolkitContext ctx)
        {
            var state = ctx.State(Id);
            int division = EditorGUILayout.IntPopup("音符", state.GetInt("division", 4),
                new[] {"2分","3分","4分","6分","8分","12分","16分","24分","32分","48分","64分"},
                new[] {2,3,4,6,8,12,16,24,32,48,64});
            state.SetInt("division", division);
            double offset = ctx.HasProject ? ctx.ActiveProject.offsetSeconds : state.GetDouble("offset");
            double next = EditorGUILayout.DelayedDoubleField("曲頭オフセット（秒）", offset);
            if (next != offset && !double.IsNaN(next) && !double.IsInfinity(next))
            {
                if (ctx.HasProject) { ctx.RecordProjectEdit("曲頭オフセット"); ctx.ActiveProject.offsetSeconds = next; ctx.NotifyProjectEdited(); }
                else state.SetDouble("offset", next);
                offset = next;
            }
            if (GUILayout.Button("選択キーを拍に合わせる"))
                MoveSelection(ctx, t => BeatMath.SnapToGrid(t, ctx.Bpm, division, offset), "Beat Snap");
        }

        internal static void DrawMove(ToolkitContext ctx)
        {
            var state = ctx.State("snap");
            var shift = EditorGUILayout.DoubleField("選択キーの移動量（秒）", state.GetDouble("shift", .1));
            state.SetDouble("shift", shift);
            if (GUILayout.Button("選択キーを時間移動")) MoveSelection(ctx, t => t + shift, "キーの時間移動");
        }

        internal static void MoveSelection(ToolkitContext ctx, Func<double,double> map, string label)
        {
            var keys = new List<SelectedKeyInfo>();
            if (!new AnimationWindowBridge().TryGetSelectedKeys(keys, out string reason) || keys.Count == 0)
            { ctx.ShowNotification(reason ?? "Animation でキーを選択してください"); return; }
            var clip = keys[0].Clip;
            if (!clip || keys.Any(k => k.Clip != clip) || !ClipEditUtility.IsEditable(clip, out reason))
            { ctx.ShowNotification(reason ?? "編集可能なクリップを1つ選んでください"); return; }
            var session = new ClipEditSession(clip);
            int count = 0;
            foreach (var group in keys.GroupBy(k => CurveRefKey.Of(k.Curve)))
            {
                var curve = session.Curves.FirstOrDefault(c => CurveRefKey.Of(c) == group.Key);
                if (curve.Binding.type == null) { ctx.ShowNotification("対象の実カーブを特定できません"); return; }
                var binding = curve.Binding;
                var numbers = curve.IsObjectReference ? null : session.GetFloatCurve(binding);
                var refs = curve.IsObjectReference ? session.GetObjectCurve(binding) : null;
                var values = numbers?.keys;
                var times = refs != null ? refs.Select(k => k.time).ToArray() : values.Select(k => k.time).ToArray();
                var changed = (float[])times.Clone();
                foreach (var key in group)
                {
                    int i = Array.FindIndex(times, t => Math.Abs(t - key.Time) <= CurveKeyUtility.TimeEpsilon);
                    if (i < 0) { ctx.ShowNotification("選択キーが変わりました。選び直してください"); return; }
                    var target = (float)map(times[i]);
                    if (!(target >= 0) || float.IsInfinity(target)) { ctx.ShowNotification("時刻が範囲外です"); return; }
                    changed[i] = target;
                }
                var order = Enumerable.Range(0, times.Length).OrderBy(i => changed[i]).ToArray();
                for (int j = 1; j < order.Length; j++)
                    if (changed[order[j]] - changed[order[j-1]] <= CurveKeyUtility.TimeEpsilon)
                    { ctx.ShowNotification("同時刻にキーが重なるため中止しました"); return; }
                count += changed.Where((v,i) => v != times[i]).Count();
                if (refs != null)
                {
                    for (int i = 0; i < refs.Length; i++) refs[i].time = changed[i];
                    session.SetObjectCurve(binding, order.Select(i => refs[i]).ToArray());
                }
                else
                {
                    for (int i = 0; i < values.Length; i++) values[i].time = changed[i];
                    numbers.keys = order.Select(i => values[i]).ToArray();
                    session.SetFloatCurve(binding, numbers);
                }
            }
            if (count > 0 && EditorUtility.DisplayDialog(label, $"{clip.name} の {count} キーを移動します。", "適用", "キャンセル")) session.Commit(label);
            else if (count == 0) ctx.ShowNotification("変更はありません");
        }
    }
}
