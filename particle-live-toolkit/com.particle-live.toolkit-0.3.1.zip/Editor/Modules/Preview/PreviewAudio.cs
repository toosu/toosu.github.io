using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// プレビューの音声再生。実装は例外を投げてもよい(呼び出し側の LivePreviewPlayer が捕まえて「音なし」に切り替える)。
    /// </summary>
    public interface IPreviewAudio
    {
        /// <summary>clip を startSeconds から再生する。再生を始められたら true。</summary>
        bool Play(AudioClip clip, double startSeconds);

        /// <summary>自分が始めた再生を止める。</summary>
        void Stop();

        /// <summary>再生中なら現在の再生位置(秒)を返す。再生していない・取れないときは false。</summary>
        bool TryGetTime(out double seconds);
    }

    /// <summary>
    /// Unity 内部 API UnityEditor.AudioUtil のプレビュー再生(Inspector の試聴と同じ仕組み)を使う実装。
    /// 内部 API が無い・呼び出しに失敗した場合は false を返す(例外は外に出さない)。
    /// StopAllPreviewClips は Inspector の試聴も止めてしまうので、自分が再生を始めたときだけ呼ぶ。
    /// </summary>
    public sealed class EditorPreviewAudio : IPreviewAudio
    {
        private AudioClip _playing;

        /// <summary>内部 API が見つかったか。</summary>
        public static bool IsSupported
        {
            get { return AudioUtilReflection.IsAvailable; }
        }

        public bool Play(AudioClip clip, double startSeconds)
        {
            Stop();
            if (clip == null || !AudioUtilReflection.IsAvailable) return false;
            int startSample = ToStartSample(startSeconds, clip.frequency, clip.samples);
            if (!AudioUtilReflection.TryPlay(clip, startSample)) return false;
            _playing = clip;
            return true;
        }

        public void Stop()
        {
            if (_playing == null) return;
            _playing = null;
            AudioUtilReflection.TryStopAll();
        }

        public bool TryGetTime(out double seconds)
        {
            seconds = 0.0;
            if (_playing == null) return false;
            if (!AudioUtilReflection.TryIsPlaying(out bool playing) || !playing) return false;
            if (!AudioUtilReflection.TryGetPosition(out float position)) return false;
            if (float.IsNaN(position) || position < 0f) return false;
            seconds = position;
            return true;
        }

        /// <summary>秒 → 開始サンプル。[0, samples - 1] に収める(NaN・負は 0、サンプル数 0 以下なら 0)。</summary>
        public static int ToStartSample(double seconds, int frequency, int samples)
        {
            if (samples <= 0 || frequency <= 0 || double.IsNaN(seconds) || seconds <= 0.0) return 0;
            double sample = Math.Round(seconds * frequency);
            if (sample >= samples) return samples - 1;
            return (int)sample;
        }
    }

    /// <summary>
    /// UnityEditor.AudioUtil(internal)へのリフレクションをここだけに閉じ込める。
    /// 2022.3 で確認したシグネチャ: PlayPreviewClip(AudioClip, int startSample, bool loop) / StopAllPreviewClips() /
    /// IsPreviewClipPlaying() / GetPreviewClipPosition()(秒)。どれかが見つからなければ「使えない」。
    /// </summary>
    internal static class AudioUtilReflection
    {
        private static bool s_resolved;
        private static MethodInfo s_play;
        private static MethodInfo s_stopAll;
        private static MethodInfo s_isPlaying;
        private static MethodInfo s_position;

        public static bool IsAvailable
        {
            get
            {
                Resolve();
                return s_play != null && s_stopAll != null;
            }
        }

        public static bool TryPlay(AudioClip clip, int startSample)
        {
            if (!IsAvailable) return false;
            try
            {
                ParameterInfo[] ps = s_play.GetParameters();
                object[] args;
                if (ps.Length == 3) args = new object[] { clip, startSample, false };
                else if (ps.Length == 2) args = new object[] { clip, startSample };
                else args = new object[] { clip };
                s_play.Invoke(null, args);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool TryStopAll()
        {
            if (!IsAvailable) return false;
            try
            {
                s_stopAll.Invoke(null, null);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool TryIsPlaying(out bool playing)
        {
            playing = false;
            Resolve();
            if (s_isPlaying == null) return false;
            try
            {
                playing = (bool)s_isPlaying.Invoke(null, null);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool TryGetPosition(out float seconds)
        {
            seconds = 0f;
            Resolve();
            if (s_position == null) return false;
            try
            {
                seconds = (float)s_position.Invoke(null, null);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static void Resolve()
        {
            if (s_resolved) return;
            s_resolved = true;
            try
            {
                Type type = typeof(EditorWindow).Assembly.GetType("UnityEditor.AudioUtil");
                if (type == null) return;
                const BindingFlags flags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
                s_play = FindPlay(type, flags);
                s_stopAll = Find(type, "StopAllPreviewClips", flags, typeof(void));
                s_isPlaying = Find(type, "IsPreviewClipPlaying", flags, typeof(bool));
                s_position = Find(type, "GetPreviewClipPosition", flags, typeof(float));
            }
            catch (Exception)
            {
                s_play = null;
                s_stopAll = null;
                s_isPlaying = null;
                s_position = null;
            }
        }

        private static MethodInfo FindPlay(Type type, BindingFlags flags)
        {
            MethodInfo best = null;
            foreach (MethodInfo m in type.GetMethods(flags))
            {
                if (m.Name != "PlayPreviewClip") continue;
                ParameterInfo[] ps = m.GetParameters();
                if (ps.Length == 0 || ps[0].ParameterType != typeof(AudioClip)) continue;
                if (ps.Length >= 2 && ps[1].ParameterType != typeof(int)) continue;
                if (ps.Length == 3 && ps[2].ParameterType != typeof(bool)) continue;
                if (ps.Length > 3) continue;
                if (best == null || ps.Length > best.GetParameters().Length) best = m;
            }
            return best;
        }

        private static MethodInfo Find(Type type, string name, BindingFlags flags, Type returnType)
        {
            MethodInfo m = type.GetMethod(name, flags, null, Type.EmptyTypes, null);
            return m != null && m.ReturnType == returnType ? m : null;
        }
    }
}
