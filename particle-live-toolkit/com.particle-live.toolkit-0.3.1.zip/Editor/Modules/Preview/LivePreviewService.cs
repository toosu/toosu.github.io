using ParticleLiveToolkit.Core;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// モジュール画面と「別ウィンドウ」で 1 つのプレビューを共有する。
    /// 別ウィンドウが開いている間はモジュールのタブを切り替えても再生を続け、別ウィンドウを閉じたら止める。
    /// どちらも開いていない状態でモジュールが無効になったら止める。
    /// </summary>
    public static class LivePreviewService
    {
        private static LivePreviewPlayer s_player;

        /// <summary>共有プレイヤー(初回アクセスで作る。設定は ModuleState から読み込む)。</summary>
        public static LivePreviewPlayer Player
        {
            get
            {
                if (s_player == null)
                {
                    s_player = new LivePreviewPlayer(new EditorPreviewAudio());
                    s_player.Settings.CopyFrom(PreviewSettings.Load(State));
                }
                return s_player;
            }
        }

        /// <summary>まだ作っていなければ null(副作用なしで確認する用)。</summary>
        public static LivePreviewPlayer CurrentPlayerOrNull
        {
            get { return s_player; }
        }

        /// <summary>プレビューの UI 状態の保存先(モジュールの ctx.State(Id) と同じキー空間)。</summary>
        public static ModuleState State
        {
            get { return new ModuleState(ToolkitModuleIds.Preview, () => s_player?.Project); }
        }

        /// <summary>開いている別ウィンドウの数。</summary>
        public static int DetachedWindowCount { get; internal set; }

        public static bool IsDetachedWindowOpen
        {
            get { return DetachedWindowCount > 0; }
        }

        internal static void NotifyDetachedWindowOpened()
        {
            DetachedWindowCount++;
        }

        /// <summary>別ウィンドウが閉じた(OnDisable)。最後の 1 枚なら止める。</summary>
        public static void NotifyDetachedWindowClosed()
        {
            if (DetachedWindowCount > 0) DetachedWindowCount--;
            if (DetachedWindowCount == 0) s_player?.Shutdown();
        }

        /// <summary>モジュールのタブが無効になった。別ウィンドウが無ければ止める。</summary>
        public static void NotifyModuleDisabled()
        {
            if (!IsDetachedWindowOpen) s_player?.Shutdown();
        }

        /// <summary>テスト用: 共有プレイヤーを差し替え、前のものを返す。</summary>
        internal static LivePreviewPlayer SwapPlayer(LivePreviewPlayer player)
        {
            LivePreviewPlayer previous = s_player;
            s_player = player;
            return previous;
        }
    }
}
