using System;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// ⑥ Live Preview。観客視点の登録・編集と、2 段構えのプレビュー:
    ///  1. Scene ビューを視点に合わせる(常に動く)
    ///  2. 視点からの映像を Play Mode なしで楽曲と mainClip に同期して再生(任意秒から、区間ループ、別ウィンドウ)
    /// 生成(コンストラクタ)では何もしない。プレビューはタブの切り替え・ウィンドウを閉じる・再コンパイル・
    /// Play Mode の切り替えで止まり、シーンは元に戻る(別ウィンドウ表示中はタブを切り替えても続ける)。
    /// </summary>
    public sealed class LivePreviewModule : IToolkitModule
    {
        private ToolkitContext _ctx;
        private Action _repaint;
        private readonly PreviewGuiSnapshot _shown = new PreviewGuiSnapshot();

        public string Id
        {
            get { return ToolkitModuleIds.Preview; }
        }

        public string DisplayName
        {
            get { return "Preview"; }
        }

        public int Order
        {
            get { return ToolkitModuleIds.PreviewOrder; }
        }

        public void OnEnable(ToolkitContext ctx)
        {
            Detach();
            _ctx = ctx;
            if (ctx == null) return;
            _repaint = ctx.Repaint;
            ctx.ProjectChanged += OnProjectChanged;
            LivePreviewPlayer player = LivePreviewService.Player;
            player.Changed += _repaint;
            player.Project = ctx.ActiveProject;
        }

        public void OnDisable()
        {
            Detach();
            LivePreviewService.NotifyModuleDisabled();
        }

        public void OnGUI(ToolkitContext ctx)
        {
            if (!ToolkitGUI.RequireProject(ctx)) return;
            ParticleLiveProject project = ctx.ActiveProject;
            LivePreviewPlayer player = LivePreviewService.Player;
            _shown.CaptureIfLayout(player);

            ToolkitGUI.Section("観客視点");
            DrawViewpointList(ctx, project, player);
            DrawAddButtons(ctx, project, player);

            ToolkitGUI.Section("Scene ビューで確認");
            DrawAlignButton(ctx, project, player);

            ToolkitGUI.Section("プレビュー(Play Mode に入らずに再生)");
            if (GUILayout.Button("別ウィンドウで開く"))
            {
                LivePreviewWindow.Open();
            }
            if (_shown.DetachedWindowOpen)
            {
                ToolkitGUI.Hint("別ウィンドウで表示中です。タブを切り替えても再生は続きます(別ウィンドウを閉じると止まります)");
            }
            LivePreviewGUI.DrawPreview(player, ctx.ShowNotification, _shown);
        }

        private void OnProjectChanged()
        {
            if (_ctx == null) return;
            // 同じライブの値の変更(視点の編集など)では止めない。別のライブに替わったときだけ止まる。
            LivePreviewService.Player.Project = _ctx.ActiveProject;
        }

        private void Detach()
        {
            if (_ctx != null) _ctx.ProjectChanged -= OnProjectChanged;
            LivePreviewPlayer player = LivePreviewService.CurrentPlayerOrNull;
            if (player != null && _repaint != null) player.Changed -= _repaint;
            _ctx = null;
            _repaint = null;
        }

        private static void DrawViewpointList(ToolkitContext ctx, ParticleLiveProject project, LivePreviewPlayer player)
        {
            if (project.viewpoints == null || project.viewpoints.Count == 0)
            {
                ToolkitGUI.Hint("観客視点がまだありません。Scene ビューを観客の位置に合わせて「Scene ビューから追加」を押すか、目印のオブジェクトを選んで「選択中のオブジェクトから追加」を押してください");
                return;
            }

            int selected = Mathf.Clamp(player.Settings.ViewpointIndex, 0, project.viewpoints.Count - 1);
            for (int i = 0; i < project.viewpoints.Count; i++)
            {
                Viewpoint vp = project.viewpoints[i];
                if (vp == null) continue;
                using (new EditorGUILayout.HorizontalScope())
                {
                    bool isSelected = i == selected;
                    if (GUILayout.Toggle(isSelected, GUIContent.none, EditorStyles.radioButton, GUILayout.Width(18f)) && !isSelected)
                    {
                        player.Settings.ViewpointIndex = i;
                        player.Settings.Save(LivePreviewService.State);
                    }

                    string name = EditorGUILayout.DelayedTextField(vp.name ?? "");
                    if (name != vp.name) ViewpointEditing.SetName(ctx, i, name);

                    GUILayout.Label(new GUIContent("高さ", "目の高さ(m)"), GUILayout.Width(28f));
                    float height = EditorGUILayout.DelayedFloatField(vp.eyeHeight, GUILayout.Width(44f));
                    if (!height.Equals(vp.eyeHeight)) ViewpointEditing.SetEyeHeight(ctx, i, height);

                    GUILayout.Label(new GUIContent("FOV", "垂直の視野角(度)"), GUILayout.Width(30f));
                    float fov = EditorGUILayout.DelayedFloatField(vp.fieldOfView, GUILayout.Width(44f));
                    if (!fov.Equals(vp.fieldOfView)) ViewpointEditing.SetFieldOfView(ctx, i, fov);

                    if (GUILayout.Button("削除", GUILayout.Width(44f)))
                    {
                        string removed = vp.name;
                        if (ViewpointEditing.Remove(ctx, i))
                        {
                            if (player.Settings.ViewpointIndex >= project.viewpoints.Count)
                            {
                                player.Settings.ViewpointIndex = Math.Max(0, project.viewpoints.Count - 1);
                                player.Settings.Save(LivePreviewService.State);
                            }
                            ctx.ShowNotification("視点「" + removed + "」を削除しました(Undo で戻せます)");
                        }
                        GUIUtility.ExitGUI();
                    }
                }
                if (!string.IsNullOrEmpty(vp.anchorPath))
                {
                    EditorGUILayout.LabelField("    目印: " + vp.anchorPath + "(このオブジェクトに追従)", EditorStyles.miniLabel);
                }
            }
        }

        private static void DrawAddButtons(ToolkitContext ctx, ParticleLiveProject project, LivePreviewPlayer player)
        {
            SceneView view = SceneView.lastActiveSceneView;
            string noSceneView = view == null || view.camera == null ? "Scene ビューが開かれていません" : null;
            if (ToolkitGUI.PrimaryButton("Scene ビューから追加", noSceneView))
            {
                Transform cam = view.camera.transform;
                Viewpoint vp = ViewpointEditing.FromCamera(cam.position, cam.rotation, view.camera.fieldOfView, ViewpointEditing.NextName(project.viewpoints));
                AddAndSelect(ctx, player, vp);
            }

            Transform target = Selection.activeTransform;
            string noSelection = target == null ? "ヒエラルキーで目印にするオブジェクトを選択してください"
                : EditorUtility.IsPersistent(target) ? "シーン内のオブジェクトを選択してください(プレハブアセットは使えません)" : null;
            if (ToolkitGUI.PrimaryButton("選択中のオブジェクトから追加", noSelection))
            {
                Viewpoint vp = ViewpointEditing.FromObject(project, target, target.name);
                AddAndSelect(ctx, player, vp);
            }
        }

        private static void AddAndSelect(ToolkitContext ctx, LivePreviewPlayer player, Viewpoint vp)
        {
            int index = ViewpointEditing.Add(ctx, vp);
            if (index < 0) return;
            player.Settings.ViewpointIndex = index;
            player.Settings.Save(LivePreviewService.State);
            ctx.ShowNotification("視点「" + vp.name + "」を追加しました");
        }

        private static void DrawAlignButton(ToolkitContext ctx, ParticleLiveProject project, LivePreviewPlayer player)
        {
            Viewpoint vp = player.SelectedViewpoint;
            SceneView view = SceneView.lastActiveSceneView;
            string reason = vp == null ? "先に観客視点を登録してください"
                : view == null ? "Scene ビューが開かれていません" : null;
            string label = vp != null ? "Scene ビューを「" + vp.name + "」に合わせる" : "Scene ビューを視点に合わせる";
            if (!ToolkitGUI.PrimaryButton(label, reason)) return;

            if (SceneViewAlignment.TryCompute(project, vp, out SceneViewPose pose) && SceneViewAlignment.Apply(view, pose))
            {
                ctx.ShowNotification("Scene ビューを「" + vp.name + "」に合わせました");
            }
            else
            {
                ctx.ShowNotification("Scene ビューを合わせられませんでした");
            }
        }
    }
}
