using System;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// 視点からの映像を RenderTexture に描く一時カメラ。カメラと RenderTexture は HideAndDontSave で作るので
    /// シーンには保存されず、シーンも dirty にしない。Dispose で破棄(何度呼んでも安全)。
    /// シーンに MainCamera があればその設定(背景・カリングマスク・クリップ面など)を写して使う。
    /// </summary>
    internal sealed class PreviewRenderer : IDisposable
    {
        private const int MinSize = 16;
        private const int MaxSize = 4096;

        private Camera _camera;
        private RenderTexture _texture;

        public bool HasResources
        {
            get { return _camera != null || _texture != null; }
        }

        public Texture Render(Vector3 eyePosition, Quaternion rotation, float fieldOfView, int width, int height)
        {
            width = Mathf.Clamp(width, MinSize, MaxSize);
            height = Mathf.Clamp(height, MinSize, MaxSize);
            EnsureCamera();
            EnsureTexture(width, height);

            Camera main = Camera.main;
            if (main != null && main != _camera)
            {
                _camera.CopyFrom(main);
            }
            else
            {
                _camera.clearFlags = CameraClearFlags.Skybox;
                _camera.nearClipPlane = 0.05f;
                _camera.farClipPlane = 2000f;
            }
            _camera.enabled = false;
            _camera.orthographic = false;
            _camera.targetTexture = _texture;
            _camera.transform.SetPositionAndRotation(eyePosition, rotation);
            _camera.fieldOfView = fieldOfView;
            _camera.aspect = width / (float)height;
            _camera.Render();
            return _texture;
        }

        public void Dispose()
        {
            if (_camera != null)
            {
                try
                {
                    _camera.targetTexture = null;
                    Object.DestroyImmediate(_camera.gameObject);
                }
                catch (Exception)
                {
                    // 続ける
                }
            }
            _camera = null;

            if (_texture != null)
            {
                try
                {
                    _texture.Release();
                    Object.DestroyImmediate(_texture);
                }
                catch (Exception)
                {
                    // 続ける
                }
            }
            _texture = null;
        }

        private void EnsureCamera()
        {
            if (_camera != null) return;
            GameObject go = EditorUtility.CreateGameObjectWithHideFlags("Particle Live Toolkit Preview Camera", HideFlags.HideAndDontSave, typeof(Camera));
            _camera = go.GetComponent<Camera>();
            _camera.enabled = false;
        }

        private void EnsureTexture(int width, int height)
        {
            if (_texture != null && _texture.width == width && _texture.height == height) return;
            if (_texture != null)
            {
                if (_camera != null) _camera.targetTexture = null;
                _texture.Release();
                Object.DestroyImmediate(_texture);
            }
            _texture = new RenderTexture(width, height, 24)
            {
                name = "Particle Live Toolkit Preview",
                hideFlags = HideFlags.HideAndDontSave,
                antiAliasing = 1,
            };
            _texture.Create();
        }
    }
}
