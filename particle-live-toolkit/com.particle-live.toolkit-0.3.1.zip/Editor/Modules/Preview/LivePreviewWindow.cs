using System;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// プレビューを独立したウィンドウに切り離して表示する。モジュール画面と同じ LivePreviewService.Player を使う。
    /// 開いている間はメインウィンドウのタブを切り替えても再生が続き、閉じると止まる(シーンも元に戻る)。
    ///
    /// 対象のライブは選べない(読み取り専用の表示)。常にメインウィンドウの「編集中のライブ」に従う。
    /// メインウィンドウが閉じているときは、最後に「編集中のライブ」だった設定(Core が Unity プロジェクト単位で記憶しているもの)に従う。
    /// メインウィンドウと違いモジュールの例外隔離が無いので、描画中の例外はここで捕まえ、プレビューを後始末してから理由を表示する。
    /// 再コンパイル後は自動で再生を再開しない。
    /// </summary>
    public sealed class LivePreviewWindow : EditorWindow
    {
        private const string Title = "Live Preview";

        [SerializeField] private Vector2 _scroll;

        private readonly PreviewGuiSnapshot _shown = new PreviewGuiSnapshot();
        private string _error;
        private string _shownError;

        public static LivePreviewWindow Open()
        {
            var window = GetWindow<LivePreviewWindow>(false, Title, true);
            SyncProject(LivePreviewService.Player);
            window.Show();
            window.Focus();
            return window;
        }

        /// <summary>プレイヤーの対象をメインウィンドウの「編集中のライブ」に合わせる(違えばプレビューは止まる)。</summary>
        internal static void SyncProject(LivePreviewPlayer player)
        {
            if (player == null) return;
            ParticleLiveProject active = ActiveProjectMemory.Load();
            if (!ReferenceEquals(player.Project, active)) player.Project = active;
        }

        /// <summary>描画中の例外: プレビューを後始末して、表示する理由を返す。</summary>
        internal static string HandleGuiException(LivePreviewPlayer player, Exception error)
        {
            player?.Shutdown();
            string message = error != null ? error.GetType().Name + ": " + error.Message : "不明なエラー";
            return "プレビューの表示中にエラーが発生したため、プレビューを止めてシーンを元に戻しました(" + message.Replace("\n", " ") + ")";
        }

        private void OnEnable()
        {
            titleContent = new GUIContent(Title);
            minSize = new Vector2(320f, 300f);
            LivePreviewService.NotifyDetachedWindowOpened();
            LivePreviewService.Player.Changed += Repaint;
        }

        private void OnDisable()
        {
            LivePreviewPlayer player = LivePreviewService.CurrentPlayerOrNull;
            if (player != null) player.Changed -= Repaint;
            LivePreviewService.NotifyDetachedWindowClosed();
        }

        private void OnGUI()
        {
            LivePreviewPlayer player = LivePreviewService.Player;
            if (Event.current.type == EventType.Layout)
            {
                SyncProject(player);
                _shownError = _error;
            }

            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.ObjectField(new GUIContent("ライブ", "メインウィンドウの「編集中のライブ」に従います"), player.Project, typeof(ParticleLiveProject), false);
            }

            if (_shownError != null)
            {
                ToolkitGUI.Error(_shownError);
                if (GUILayout.Button("表示し直す")) _error = null;
                return;
            }

            if (player.Project == null)
            {
                ToolkitGUI.Hint(PreviewRequirements.NoProjectMessage);
                return;
            }

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            bool ok = ModuleRunner.TryInvoke(() => LivePreviewGUI.DrawPreview(player, message => ShowNotification(new GUIContent(message)), _shown), out Exception error);
            if (!ok)
            {
                _error = HandleGuiException(player, error);
                // レイアウトの途中で抜けたので、このイベントは打ち切って次のフレームで理由を描く
                GUIUtility.ExitGUI();
            }
            EditorGUILayout.EndScrollView();
        }
    }
}
