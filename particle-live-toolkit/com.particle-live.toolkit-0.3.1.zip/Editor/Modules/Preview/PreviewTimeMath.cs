using System;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>再生位置を進めた結果の種類。</summary>
    public enum PreviewAdvanceKind
    {
        /// <summary>そのまま進んだ。</summary>
        Continue,
        /// <summary>区間ループの終端に達して開始側へ折り返した(シークし直しが必要)。</summary>
        Wrapped,
        /// <summary>クリップの終端に達した(再生を止める)。</summary>
        Ended,
    }

    /// <summary>再生位置を進めた結果。</summary>
    public struct PreviewAdvance
    {
        public double Time;
        public PreviewAdvanceKind Kind;

        public PreviewAdvance(double time, PreviewAdvanceKind kind)
        {
            Time = time;
            Kind = kind;
        }
    }

    /// <summary>
    /// プレビューの時刻計算(UI なしの純粋関数)。時刻はすべて秒。
    /// 区間ループは半開区間 [開始, 終了)。終了ちょうどに達したら開始へ戻る。
    /// </summary>
    public static class PreviewTimeMath
    {
        /// <summary>シーク時に手前から再シミュレートする秒数の既定値。</summary>
        public const double DefaultPreRollSeconds = 10.0;

        /// <summary>シミュレーションの固定刻み(1/30 秒)。</summary>
        public const double DefaultStepSeconds = 1.0 / 30.0;

        /// <summary>再生中に 1 回の更新で逐次進める刻み数の上限。超える飛びはシークで処理する。</summary>
        public const int MaxIncrementalSteps = 30;

        private const double StepEpsilon = 1e-6;

        /// <summary>時刻を [0, length] に収める。NaN は 0、長さ 0 以下なら 0。</summary>
        public static double ClampTime(double time, double length)
        {
            if (double.IsNaN(time) || time < 0.0) return 0.0;
            if (double.IsNaN(length) || length <= 0.0) return 0.0;
            return time > length ? length : time;
        }

        /// <summary>
        /// 入力されたループ区間を正規化する。負の値・NaN は 0、クリップ長を超える値はクリップ長に丸める。
        /// 丸めた後に終了 ≤ 開始ならループとして無効(false)。
        /// </summary>
        public static bool TryGetLoop(double start, double end, double length, out double loopStart, out double loopEnd)
        {
            loopStart = ClampTime(start, length);
            loopEnd = ClampTime(end, length);
            return loopEnd - loopStart > StepEpsilon;
        }

        /// <summary>t を区間 [loopStart, loopEnd) に折り返す(終端ちょうどは開始、何周超えても剰余で戻す)。</summary>
        public static double WrapIntoLoop(double time, double loopStart, double loopEnd)
        {
            double span = loopEnd - loopStart;
            if (!(span > 0.0)) return loopStart;
            if (time < loopEnd) return time < loopStart ? loopStart : time;
            double offset = (time - loopStart) % span;
            if (offset < 0.0 || offset >= span) offset = 0.0;
            return loopStart + offset;
        }

        /// <summary>
        /// 時計から求めた生の再生位置 raw を、ループ・終端を考慮した再生位置にする。
        /// ループが有効(TryGetLoop が true)なら終了以上で折り返し、無効ならクリップ長で終わる。
        /// </summary>
        public static PreviewAdvance Advance(double raw, bool loopEnabled, double loopStartInput, double loopEndInput, double length)
        {
            double time = double.IsNaN(raw) || raw < 0.0 ? 0.0 : raw;
            if (loopEnabled && TryGetLoop(loopStartInput, loopEndInput, length, out double loopStart, out double loopEnd))
            {
                if (time >= loopEnd) return new PreviewAdvance(WrapIntoLoop(time, loopStart, loopEnd), PreviewAdvanceKind.Wrapped);
                return new PreviewAdvance(time, PreviewAdvanceKind.Continue);
            }

            double clipLength = double.IsNaN(length) || length < 0.0 ? 0.0 : length;
            if (time >= clipLength) return new PreviewAdvance(clipLength, PreviewAdvanceKind.Ended);
            return new PreviewAdvance(time, PreviewAdvanceKind.Continue);
        }

        /// <summary>
        /// 再生ボタンを押したときの開始位置。ループ有効なら区間の外からはループ開始へ。
        /// ループ無効で終端にいるなら頭から。
        /// </summary>
        public static double StartTimeForPlay(double current, bool loopEnabled, double loopStartInput, double loopEndInput, double length)
        {
            double time = ClampTime(current, length);
            if (loopEnabled && TryGetLoop(loopStartInput, loopEndInput, length, out double loopStart, out double loopEnd))
            {
                return time < loopStart || time >= loopEnd ? loopStart : time;
            }
            return time >= length ? 0.0 : time;
        }

        /// <summary>シーク先 target の手前 preRoll 秒(0 未満にはしない。負・NaN の preRoll は 0 扱い)。</summary>
        public static double PreRollStart(double target, double preRoll)
        {
            if (double.IsNaN(target) || target <= 0.0) return 0.0;
            double roll = double.IsNaN(preRoll) || preRoll < 0.0 ? 0.0 : preRoll;
            return Math.Max(0.0, target - roll);
        }

        /// <summary>from から to までを刻み step で進めるときの刻み数(端数は 1 刻み。step が 0 以下なら既定値)。</summary>
        public static int StepCount(double from, double to, double step)
        {
            if (double.IsNaN(from) || double.IsNaN(to) || to <= from) return 0;
            double dt = NormalizeStep(step);
            double count = Math.Ceiling((to - from) / dt - StepEpsilon);
            if (count < 1.0) return 1;
            return count > int.MaxValue ? int.MaxValue : (int)count;
        }

        /// <summary>index 番目(0 始まり)の刻みを終えた時刻。最後の刻みは必ず to ちょうど。</summary>
        public static double StepTime(double from, double to, double step, int index)
        {
            double t = from + (index + 1) * NormalizeStep(step);
            return t >= to - StepEpsilon ? to : t;
        }

        /// <summary>0 以下・NaN の刻みを既定値に置き換える。</summary>
        public static double NormalizeStep(double step)
        {
            return double.IsNaN(step) || step <= 0.0 ? DefaultStepSeconds : step;
        }
    }
}
