using System;
using System.Collections.Generic;
using System.Globalization;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>プレビューに必要なもの(プロジェクト・ルート・クリップ・視点)がそろっているかの判定。</summary>
    public static class PreviewRequirements
    {
        public const string NoProjectMessage = "ライブ(プロジェクト設定)が選ばれていません。上部バーで選ぶか、Project タブで新規作成してください";
        public const string NoRootMessage = "シーン内にライブルートが見つかりません。ライブのシーンを開き、Project タブでライブルートを設定してください";
        public const string NoClipMessage = "メインクリップ(mainClip)が設定されていません。プロジェクト設定で指定してください";
        public const string NoViewpointMessage = "観客視点が登録されていません。「Scene ビューから追加」などで登録してください";

        /// <summary>そろっていれば true(reason は null)。足りなければ最初に足りないものの案内を reason に入れて false。</summary>
        public static bool Check(ParticleLiveProject project, out string reason)
        {
            reason = null;
            if (project == null)
            {
                reason = NoProjectMessage;
            }
            else if (ProjectSceneUtility.FindRoot(project) == null)
            {
                reason = NoRootMessage;
            }
            else if (project.mainClip == null)
            {
                reason = NoClipMessage;
            }
            else if (project.viewpoints == null || project.viewpoints.Count == 0)
            {
                reason = NoViewpointMessage;
            }
            return reason == null;
        }
    }

    /// <summary>プレビューの設定(UI 状態)。ModuleState に保存して再コンパイル後も残す。</summary>
    public sealed class PreviewSettings
    {
        private const string ViewpointKey = "viewpoint";
        private const string StartKey = "start";
        private const string LoopKey = "loop";
        private const string LoopStartKey = "loopStart";
        private const string LoopEndKey = "loopEnd";
        private const string PreRollKey = "preRoll";

        public int ViewpointIndex;
        public double StartSeconds;
        public bool LoopEnabled;
        public double LoopStart;
        public double LoopEnd;
        public double PreRollSeconds = PreviewTimeMath.DefaultPreRollSeconds;

        public static PreviewSettings Load(ModuleState state)
        {
            var s = new PreviewSettings();
            if (state == null) return s;
            s.ViewpointIndex = int.TryParse(state.GetString(ViewpointKey, "0"), NumberStyles.Integer, CultureInfo.InvariantCulture, out int vp) ? vp : 0;
            s.StartSeconds = state.GetDouble(StartKey, 0.0);
            s.LoopEnabled = state.GetString(LoopKey, "0") == "1";
            s.LoopStart = state.GetDouble(LoopStartKey, 0.0);
            s.LoopEnd = state.GetDouble(LoopEndKey, 0.0);
            s.PreRollSeconds = state.GetDouble(PreRollKey, PreviewTimeMath.DefaultPreRollSeconds);
            return s;
        }

        public void Save(ModuleState state)
        {
            if (state == null) return;
            state.SetString(ViewpointKey, ViewpointIndex.ToString(CultureInfo.InvariantCulture));
            state.SetDouble(StartKey, StartSeconds);
            state.SetString(LoopKey, LoopEnabled ? "1" : "0");
            state.SetDouble(LoopStartKey, LoopStart);
            state.SetDouble(LoopEndKey, LoopEnd);
            state.SetDouble(PreRollKey, PreRollSeconds);
        }

        /// <summary>保存した値を消す(テストの後片付け用)。</summary>
        public void Erase(ModuleState state)
        {
            if (state == null) return;
            foreach (string key in new[] { ViewpointKey, StartKey, LoopKey, LoopStartKey, LoopEndKey, PreRollKey })
            {
                state.SetString(key, null);
            }
        }

        public void CopyFrom(PreviewSettings other)
        {
            if (other == null) return;
            ViewpointIndex = other.ViewpointIndex;
            StartSeconds = other.StartSeconds;
            LoopEnabled = other.LoopEnabled;
            LoopStart = other.LoopStart;
            LoopEnd = other.LoopEnd;
            PreRollSeconds = other.PreRollSeconds;
        }
    }

    /// <summary>
    /// Edit Mode のプレビュー再生(UI なし)。楽曲と mainClip を同期再生し、選んだ視点からの映像を描く。
    ///
    /// 時計: 音が鳴っている間は音の再生位置、取れないときは壁時計(既定 EditorApplication.timeSinceStartup)。
    /// 後始末(Shutdown): サンプリング停止・AnimationMode 終了・粒子の消去・乱数シードの復元・音の停止・
    /// 一時カメラと RenderTexture の破棄。次のどれでも走る: Shutdown / Stop / プロジェクトの切り替え /
    /// アセンブリのリロード前 / Play Mode の切り替え / シーンを閉じる・保存する・アクティブシーンの切り替え /
    /// 利用者によるシーンの編集(ObjectChangeEvents.changesPublished のシーン系イベント)/ Undo・Redo。
    /// 何度呼んでも安全。プレビューのためにシーンを dirty にしたり Undo を記録したりしない。
    ///
    /// 編集の検知(実測): changesPublished はシーク・再生・描画・一時停止では発火せず、複製・RecordObject 付きの編集・
    /// SerializedObject の編集・Undo で発火する。ただし後始末自身(AnimationMode の復元)でも 1 フレーム遅れて発火するので、
    /// プレビュー開始から EditorApplication.update 2 回分は無視する。編集は Undo への記録(フラッシュ)の後に通知されるため、
    /// 編集の Undo 記録に固定シードは入らない。加えて:
    ///  - Undo.postprocessModifications(記録の確定時)でも編集を検知し、AnimationMode が動かしているプロパティは記録から外す
    ///    (停止後の Undo でサンプリング中の値が書き戻されないように。外した記録は changesPublished も出ないことがある)。
    ///  - 後始末は値を戻す前に Undo.FlushUndoRecordObjects() で確定前の記録を確定させる(戻した差分が記録に入るのを防ぐ)。</summary>
    public sealed class LivePreviewPlayer : IDisposable
    {
        public const string NoAudioMessage = "この環境ではエディタ音声を再生できないため音なしでプレビューします";
        public const string NoSongMessage = "楽曲(song)が設定されていないため音なしで再生します";
        public const string SceneEditedMessage = "プレビュー中にシーンが編集されたため、プレビューを終了してシーンを元に戻しました";
        public const string RenderFailedPrefix = "映像を描画できませんでした: ";

        /// <summary>プレビュー開始直後に無視する update 回数(直前の後始末が遅れて出す変更通知を誤検知しないため)。</summary>
        internal const int IgnoreChangesForUpdates = 2;

        private const double TimeEpsilon = 1e-9;

        private readonly IPreviewAudio _audio;
        private readonly Func<double> _clock;
        private readonly PreviewRenderer _renderer = new PreviewRenderer();
        private ParticleLiveProject _project;
        private PreviewSimulator _sim;
        private bool _audioStarted;
        private bool _audioBroken;
        private double _anchorMedia;
        private double _anchorWall;
        private bool _hooked;
        private bool _seekedOnce;
        private bool _ended;
        private int _updatesSinceBegin;
        private int _sessionId;
        private bool _shuttingDown;
        private bool _editShutdownScheduled;
        private int _editShutdownSession;

        /// <summary>テスト用: 設定すると Render がこの例外を投げたものとして扱う。</summary>
        internal Func<Exception> RenderFaultForTests;

        public LivePreviewPlayer(IPreviewAudio audio, Func<double> clock = null)
        {
            _audio = audio;
            _clock = clock ?? (() => EditorApplication.timeSinceStartup);
        }

        /// <summary>再生中の更新や状態の変化で発火する(ホストの再描画用)。</summary>
        public event Action Changed;

        public PreviewSettings Settings { get; } = new PreviewSettings();

        /// <summary>対象のライブ。別のものに替えるとプレビューを止める。</summary>
        public ParticleLiveProject Project
        {
            get { return _project != null ? _project : null; }
            set
            {
                ParticleLiveProject next = value != null ? value : null;
                if (ReferenceEquals(Project, next))
                {
                    _project = next;
                    return;
                }
                Shutdown();
                _project = next;
                Settings.CopyFrom(PreviewSettings.Load(new ModuleState(ToolkitModuleIds.Preview, () => Project)));
                LastMessage = null;
            }
        }

        /// <summary>現在の再生位置(秒)。</summary>
        public double CurrentTime { get; private set; }

        /// <summary>AnimationMode に入ってシーンにプレビューを適用している間 true。</summary>
        public bool IsActive
        {
            get { return _sim != null && _sim.IsActive; }
        }

        public bool IsPlaying { get; private set; }

        /// <summary>音声 API が使えない(例外・失敗)ため音なしで動いているとき true。</summary>
        public bool AudioUnavailable
        {
            get { return _audioBroken; }
        }

        /// <summary>音について利用者に見せる案内(音なしの理由)。問題なければ null。</summary>
        public string AudioMessage { get; private set; }

        /// <summary>直近の操作が失敗した理由(足りないもの・AnimationMode 使用中など)。成功したら null。</summary>
        public string LastMessage { get; private set; }

        /// <summary>一時カメラか RenderTexture が残っているか。</summary>
        public bool HasRenderResources
        {
            get { return _renderer.HasResources; }
        }

        /// <summary>クリップの長さ(秒)。クリップが無ければ 0。</summary>
        public double Length
        {
            get
            {
                ParticleLiveProject project = Project;
                return project != null && project.mainClip != null ? project.mainClip.length : 0.0;
            }
        }

        /// <summary>選択中の視点(範囲外のインデックスは丸める)。無ければ null。</summary>
        public Viewpoint SelectedViewpoint
        {
            get
            {
                ParticleLiveProject project = Project;
                if (project == null || project.viewpoints == null || project.viewpoints.Count == 0) return null;
                int index = Mathf.Clamp(Settings.ViewpointIndex, 0, project.viewpoints.Count - 1);
                return project.viewpoints[index];
            }
        }

        /// <summary>プレビューに足りないもの。そろっていれば null。</summary>
        public string GetMissingReason()
        {
            return PreviewRequirements.Check(Project, out string reason) ? null : reason;
        }

        /// <summary>time の状態をシーンに適用する(必要ならプレビューを開始する)。失敗したら LastMessage に理由。</summary>
        public bool Seek(double time)
        {
            if (!EnsureSession()) return false;
            double t = PreviewTimeMath.ClampTime(time, _sim.Clip.length);
            if (!TrySimulate(() => _sim.Seek(t, Settings.PreRollSeconds))) return false;
            CurrentTime = t;
            _ended = false;
            if (IsPlaying)
            {
                RestartAudio(t);
                Reanchor(t);
            }
            RaiseChanged();
            return true;
        }

        /// <summary>
        /// 再生する。一時停止中(プレビュー中)なら現在位置から再開し、プレビューしていない・最後まで再生し終えた後は開始位置から。
        /// ループ有効で区間の外ならループ開始から。
        /// </summary>
        public bool Play()
        {
            if (IsPlaying) return true;
            bool resume = IsActive && !_ended;
            if (!EnsureSession()) return false;
            double from = resume ? CurrentTime : Settings.StartSeconds;
            double start = PreviewTimeMath.StartTimeForPlay(from, Settings.LoopEnabled, Settings.LoopStart, Settings.LoopEnd, _sim.Clip.length);
            if (Math.Abs(_sim.SimulatedTime - start) > TimeEpsilon || Math.Abs(CurrentTime - start) > TimeEpsilon || !_seekedOnce)
            {
                if (!Seek(start)) return false;
            }
            IsPlaying = true;
            _ended = false;
            StartAudio(start);
            Reanchor(start);
            RaiseChanged();
            return true;
        }

        /// <summary>一時停止(シーンはプレビューの姿のまま)。</summary>
        public void Pause()
        {
            if (!IsPlaying) return;
            IsPlaying = false;
            StopAudio();
            RaiseChanged();
        }

        /// <summary>
        /// 開始位置を変える。再生中でなければ現在位置もそこへ移す(プレビュー中ならその時刻をシーンに適用する)。
        /// </summary>
        public void SetStartPosition(double seconds)
        {
            double value = double.IsNaN(seconds) || seconds < 0.0 ? 0.0 : seconds;
            double length = Length;
            if (length > 0.0 && value > length) value = length;
            Settings.StartSeconds = value;
            if (IsPlaying) return;
            _ended = false;
            if (IsActive)
            {
                Seek(value);
            }
            else
            {
                CurrentTime = value;
                RaiseChanged();
            }
        }

        /// <summary>停止: 後始末してシーンを元に戻し、再生位置を開始位置に戻す。</summary>
        public void Stop()
        {
            Shutdown();
            CurrentTime = double.IsNaN(Settings.StartSeconds) || Settings.StartSeconds < 0.0 ? 0.0 : Settings.StartSeconds;
            RaiseChanged();
        }

        /// <summary>再生中なら時計を読んで再生位置を進め、シーンに適用する(EditorApplication.update から呼ばれる)。</summary>
        public void Tick()
        {
            if (!IsPlaying) return;
            if (!IsActive)
            {
                IsPlaying = false;
                StopAudio();
                return;
            }

            double now = _clock();
            double raw;
            if (TryGetAudioTime(out double audioTime))
            {
                raw = audioTime;
                _anchorMedia = audioTime;
                _anchorWall = now;
            }
            else
            {
                raw = _anchorMedia + (now - _anchorWall);
            }

            double length = _sim.Clip.length;
            PreviewAdvance advance = PreviewTimeMath.Advance(raw, Settings.LoopEnabled, Settings.LoopStart, Settings.LoopEnd, length);
            switch (advance.Kind)
            {
                case PreviewAdvanceKind.Wrapped:
                    if (!TrySimulate(() => _sim.Seek(advance.Time, Settings.PreRollSeconds))) return;
                    CurrentTime = advance.Time;
                    RestartAudio(advance.Time);
                    Reanchor(advance.Time);
                    break;

                case PreviewAdvanceKind.Ended:
                    if (!MoveForward(advance.Time)) return;
                    CurrentTime = advance.Time;
                    Pause();
                    _ended = true;
                    break;

                default:
                    // 時計が止まった・少し戻った場合は何もしない
                    if (advance.Time <= _sim.SimulatedTime + TimeEpsilon) return;
                    if (!MoveForward(advance.Time)) return;
                    CurrentTime = advance.Time;
                    break;
            }
            RaiseChanged();
        }

        /// <summary>選択中の視点からの映像を描く。描けなければ null(理由は LastMessage)。</summary>
        public Texture Render(int width, int height)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return null;
            if (!PreviewRequirements.Check(Project, out string reason))
            {
                LastMessage = reason;
                return null;
            }
            Viewpoint viewpoint = SelectedViewpoint;
            if (!ProjectSceneUtility.TryGetViewpointPose(Project, viewpoint, out Vector3 eye, out Quaternion rotation)) return null;
            try
            {
                float fov = Mathf.Clamp(viewpoint.fieldOfView, ViewpointEditing.MinFieldOfView, ViewpointEditing.MaxFieldOfView);
                // 一時カメラだけを作った状態でもリロード・Play Mode などで確実に破棄されるように購読する。
                Hook();
                Func<Exception> fault = RenderFaultForTests;
                if (fault != null) throw fault();
                return _renderer.Render(eye, rotation, fov, width, height);
            }
            catch (Exception e)
            {
                // GUI は LastMessage を Layout の時点で取り込むので、Repaint 中に変えても次のフレームから表示される
                LastMessage = RenderFailedPrefix + e.Message;
                _renderer.Dispose();
                return null;
            }
        }

        /// <summary>後始末(何度呼んでも安全)。</summary>
        public void Shutdown()
        {
            if (_shuttingDown) return;
            _shuttingDown = true;
            try
            {
                IsPlaying = false;
                _seekedOnce = false;
                _ended = false;
                StopAudio();
                if (_sim != null)
                {
                    if (_sim.IsActive)
                    {
                        // 利用者の編集の記録(RecordObject)が確定前なら、プレビューの値を戻す「前」に確定させる。
                        // 戻した後に確定すると、戻した差分(固定シード・サンプリング中の値)が編集の Undo に入ってしまう(実測)。
                        try
                        {
                            Undo.FlushUndoRecordObjects();
                        }
                        catch (Exception)
                        {
                            // 続ける
                        }
                    }
                    PreviewSimulator sim = _sim;
                    _sim = null;
                    try
                    {
                        sim.Dispose();
                    }
                    catch (Exception)
                    {
                        // 残りの後始末を続ける
                    }
                }
                _renderer.Dispose();
                Unhook();
            }
            finally
            {
                _shuttingDown = false;
            }
        }

        public void Dispose()
        {
            Shutdown();
            Changed = null;
        }

        internal void HandleBeforeAssemblyReload()
        {
            Shutdown();
        }

        internal void HandlePlayModeStateChanged(PlayModeStateChange change)
        {
            Shutdown();
            RaiseChanged();
        }

        internal void HandleSceneClosing(Scene scene, bool removingScene)
        {
            Shutdown();
            RaiseChanged();
        }

        internal void HandleSceneSaving(Scene scene, string path)
        {
            // 保存前に戻す(固定した乱数シードやプレビュー中の値を保存させない)
            Shutdown();
            RaiseChanged();
        }

        internal void HandleChangesPublished(ref ObjectChangeEventStream stream)
        {
            if (!IsActive || _updatesSinceBegin < IgnoreChangesForUpdates) return;
            for (int i = 0; i < stream.length; i++)
            {
                if (IsSceneEdit(stream.GetEventType(i)))
                {
                    ShutdownBecauseEdited();
                    return;
                }
            }
        }

        /// <summary>
        /// プレビュー中の編集の Undo 記録から、AnimationMode が動かしている(サンプリング中の値が入っている)プロパティを外す。
        /// 外さないと、停止後の Undo で「プレビュー中の値」が実データに書き戻される。外した編集はプレビュー終了で元の値に戻る。
        /// </summary>
        internal UndoPropertyModification[] HandlePostprocessModifications(UndoPropertyModification[] modifications)
        {
            if (!IsActive || modifications == null || modifications.Length == 0) return modifications;
            var kept = new List<UndoPropertyModification>(modifications.Length);
            bool sceneEdit = false;
            foreach (UndoPropertyModification modification in modifications)
            {
                PropertyModification current = modification.currentValue ?? modification.previousValue;
                bool animated = false;
                try
                {
                    UnityEngine.Object target = current != null ? current.target : null;
                    if (target != null && !EditorUtility.IsPersistent(target)) sceneEdit = true;
                    animated = target != null && AnimationMode.IsPropertyAnimated(target, current.propertyPath);
                }
                catch (Exception)
                {
                    animated = false;
                }
                if (!animated) kept.Add(modification);
            }

            // 記録から外した編集は changesPublished が来ないことがある(実測)ので、ここでも編集として扱う。
            // 記録(フラッシュ)の途中なので、終わってから後始末する。
            if (sceneEdit && !_shuttingDown && _updatesSinceBegin >= IgnoreChangesForUpdates) ScheduleEditShutdown();
            return kept.Count == modifications.Length ? modifications : kept.ToArray();
        }

        /// <summary>次の EditorApplication.update で後始末する(記録の確定処理の途中では値を戻さない)。</summary>
        private void ScheduleEditShutdown()
        {
            _editShutdownSession = _sessionId;
            _editShutdownScheduled = true;
        }

        internal void HandleUndoRedo()
        {
            if (!IsActive) return;
            ShutdownBecauseEdited();
        }

        /// <summary>シーン(GameObject・コンポーネント・階層)の変更か。アセットの変更(視点の編集・BPM など)では止めない。</summary>
        internal static bool IsSceneEdit(ObjectChangeKind kind)
        {
            switch (kind)
            {
                case ObjectChangeKind.None:
                case ObjectChangeKind.CreateAssetObject:
                case ObjectChangeKind.DestroyAssetObject:
                case ObjectChangeKind.ChangeAssetObjectProperties:
                    return false;
                default:
                    return true;
            }
        }

        private void ShutdownBecauseEdited()
        {
            Shutdown();
            LastMessage = SceneEditedMessage;
            RaiseChanged();
        }

        private void HandleActiveSceneChanged(Scene previous, Scene next)
        {
            Shutdown();
            RaiseChanged();
        }

        private void HandleUpdate()
        {
            if (_updatesSinceBegin < int.MaxValue) _updatesSinceBegin++;
            if (_editShutdownScheduled)
            {
                _editShutdownScheduled = false;
                if (IsActive && _editShutdownSession == _sessionId)
                {
                    ShutdownBecauseEdited();
                    return;
                }
            }
            if (!IsPlaying) return;
            try
            {
                Tick();
            }
            catch (Exception e)
            {
                LastMessage = "プレビューを続けられませんでした: " + e.Message;
                Shutdown();
            }
            RaiseChanged();
        }

        private bool EnsureSession()
        {
            ParticleLiveProject project = Project;
            if (!PreviewRequirements.Check(project, out string reason))
            {
                Shutdown();
                LastMessage = reason;
                return false;
            }

            GameObject root = ProjectSceneUtility.FindRoot(project);
            AnimationClip clip = project.mainClip;
            if (IsActive)
            {
                if (_sim.Root == root && _sim.Clip == clip) return true;
                Shutdown(); // ルートやクリップが変わった
            }

            var sim = new PreviewSimulator(root, clip);
            if (!sim.TryBegin(out string error))
            {
                sim.Dispose();
                LastMessage = error;
                return false;
            }
            _sim = sim;
            _seekedOnce = false;
            _ended = false;
            _updatesSinceBegin = 0;
            _sessionId++;
            Hook();
            LastMessage = null;
            return true;
        }

        private bool MoveForward(double target)
        {
            if (target <= _sim.SimulatedTime + TimeEpsilon) return true;
            int steps = PreviewTimeMath.StepCount(_sim.SimulatedTime, target, PreviewTimeMath.DefaultStepSeconds);
            if (steps > PreviewTimeMath.MaxIncrementalSteps)
            {
                return TrySimulate(() => _sim.Seek(target, Settings.PreRollSeconds));
            }
            return TrySimulate(() => _sim.StepTo(target));
        }

        private bool TrySimulate(Action action)
        {
            try
            {
                action();
                _seekedOnce = true;
                return true;
            }
            catch (Exception e)
            {
                Shutdown();
                LastMessage = "プレビューを続けられませんでした: " + e.Message;
                return false;
            }
        }

        private void StartAudio(double seconds)
        {
            ParticleLiveProject project = Project;
            AudioClip song = project != null ? project.song : null;
            if (song == null)
            {
                AudioMessage = NoSongMessage;
                return;
            }
            if (_audioBroken || _audio == null)
            {
                _audioBroken = true;
                AudioMessage = NoAudioMessage;
                return;
            }

            bool started;
            try
            {
                started = _audio.Play(song, seconds);
            }
            catch (Exception)
            {
                started = false;
            }
            if (!started)
            {
                _audioBroken = true;
                AudioMessage = NoAudioMessage;
                return;
            }
            _audioStarted = true;
            AudioMessage = null;
        }

        private void StopAudio()
        {
            if (!_audioStarted) return;
            _audioStarted = false;
            try
            {
                _audio.Stop();
            }
            catch (Exception)
            {
                _audioBroken = true;
                AudioMessage = NoAudioMessage;
            }
        }

        private void RestartAudio(double seconds)
        {
            StopAudio();
            StartAudio(seconds);
        }

        private bool TryGetAudioTime(out double seconds)
        {
            seconds = 0.0;
            if (!_audioStarted) return false;
            try
            {
                return _audio.TryGetTime(out seconds) && !double.IsNaN(seconds) && seconds >= 0.0;
            }
            catch (Exception)
            {
                _audioBroken = true;
                AudioMessage = NoAudioMessage;
                StopAudio();
                return false;
            }
        }

        private void Reanchor(double mediaTime)
        {
            _anchorMedia = mediaTime;
            _anchorWall = _clock();
        }

        private void Hook()
        {
            if (_hooked) return;
            _hooked = true;
            EditorApplication.update += HandleUpdate;
            AssemblyReloadEvents.beforeAssemblyReload += HandleBeforeAssemblyReload;
            EditorApplication.playModeStateChanged += HandlePlayModeStateChanged;
            EditorSceneManager.sceneClosing += HandleSceneClosing;
            EditorSceneManager.sceneSaving += HandleSceneSaving;
            EditorSceneManager.activeSceneChangedInEditMode += HandleActiveSceneChanged;
            ObjectChangeEvents.changesPublished += HandleChangesPublished;
            Undo.undoRedoPerformed += HandleUndoRedo;
            Undo.postprocessModifications += HandlePostprocessModifications;
        }

        private void Unhook()
        {
            if (!_hooked) return;
            _hooked = false;
            EditorApplication.update -= HandleUpdate;
            AssemblyReloadEvents.beforeAssemblyReload -= HandleBeforeAssemblyReload;
            EditorApplication.playModeStateChanged -= HandlePlayModeStateChanged;
            EditorSceneManager.sceneClosing -= HandleSceneClosing;
            EditorSceneManager.sceneSaving -= HandleSceneSaving;
            EditorSceneManager.activeSceneChangedInEditMode -= HandleActiveSceneChanged;
            ObjectChangeEvents.changesPublished -= HandleChangesPublished;
            Undo.undoRedoPerformed -= HandleUndoRedo;
            Undo.postprocessModifications -= HandlePostprocessModifications;
        }

        private void RaiseChanged()
        {
            Action handler = Changed;
            if (handler == null) return;
            try
            {
                handler();
            }
            catch (Exception)
            {
                // 再描画の失敗でプレビューを止めない
            }
        }
    }
}
