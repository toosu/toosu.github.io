using System;
using System.Collections.Generic;
using System.Globalization;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// 観客視点(ParticleLiveProject.viewpoints)の追加・削除・編集。
    /// プロジェクトの変更は ctx.RecordProjectEdit → 変更 → ctx.NotifyProjectEdited(1 操作 = Undo 1 回)。
    /// プロジェクトが無い・インデックスが範囲外のときは何もせず false / -1。
    /// </summary>
    public static class ViewpointEditing
    {
        public const float DefaultEyeHeight = 1.5f;
        public const float MinFieldOfView = 1f;
        public const float MaxFieldOfView = 179f;
        public const string NamePrefix = "視点 ";

        /// <summary>末尾に追加して、そのインデックスを返す。失敗は -1。</summary>
        public static int Add(ToolkitContext ctx, Viewpoint viewpoint)
        {
            ParticleLiveProject project = ctx != null ? ctx.ActiveProject : null;
            if (project == null || viewpoint == null) return -1;
            ctx.RecordProjectEdit("観客視点の追加");
            if (project.viewpoints == null) project.viewpoints = new List<Viewpoint>();
            project.viewpoints.Add(viewpoint);
            ctx.NotifyProjectEdited();
            return project.viewpoints.Count - 1;
        }

        public static bool Remove(ToolkitContext ctx, int index)
        {
            if (!TryGet(ctx, index, out ParticleLiveProject project, out _)) return false;
            ctx.RecordProjectEdit("観客視点の削除");
            project.viewpoints.RemoveAt(index);
            ctx.NotifyProjectEdited();
            return true;
        }

        public static bool SetName(ToolkitContext ctx, int index, string name)
        {
            if (!TryGet(ctx, index, out _, out Viewpoint viewpoint)) return false;
            string value = name ?? "";
            if (viewpoint.name == value) return true;
            ctx.RecordProjectEdit("観客視点の名前の変更");
            viewpoint.name = value;
            ctx.NotifyProjectEdited();
            return true;
        }

        /// <summary>目の高さ(m)。負の値は 0。</summary>
        public static bool SetEyeHeight(ToolkitContext ctx, int index, float eyeHeight)
        {
            if (!TryGet(ctx, index, out _, out Viewpoint viewpoint)) return false;
            float value = float.IsNaN(eyeHeight) || eyeHeight < 0f ? 0f : eyeHeight;
            if (viewpoint.eyeHeight.Equals(value)) return true;
            ctx.RecordProjectEdit("観客視点の高さの変更");
            viewpoint.eyeHeight = value;
            ctx.NotifyProjectEdited();
            return true;
        }

        /// <summary>FOV(垂直、度)。[MinFieldOfView, MaxFieldOfView] に収める。</summary>
        public static bool SetFieldOfView(ToolkitContext ctx, int index, float fieldOfView)
        {
            if (!TryGet(ctx, index, out _, out Viewpoint viewpoint)) return false;
            float value = ClampFieldOfView(fieldOfView);
            if (viewpoint.fieldOfView.Equals(value)) return true;
            ctx.RecordProjectEdit("観客視点の FOV の変更");
            viewpoint.fieldOfView = value;
            ctx.NotifyProjectEdited();
            return true;
        }

        public static float ClampFieldOfView(float fieldOfView)
        {
            if (float.IsNaN(fieldOfView)) return 60f;
            return Mathf.Clamp(fieldOfView, MinFieldOfView, MaxFieldOfView);
        }

        /// <summary>
        /// カメラ(Scene ビューなど)の位置・向き・FOV から視点を作る。position は足元
        /// (カメラ位置 − 上 × 既定の目の高さ)なので、TryGetViewpointPose の目の位置はカメラ位置と一致する。
        /// </summary>
        public static Viewpoint FromCamera(Vector3 cameraPosition, Quaternion cameraRotation, float fieldOfView, string name)
        {
            return new Viewpoint
            {
                name = name ?? "",
                anchorPath = "",
                position = cameraPosition - Vector3.up * DefaultEyeHeight,
                eulerAngles = cameraRotation.eulerAngles,
                eyeHeight = DefaultEyeHeight,
                fieldOfView = ClampFieldOfView(fieldOfView),
            };
        }

        /// <summary>
        /// 選択中のオブジェクトから視点を作る。ライブルートの配下(ルート自身は除く)なら anchorPath に相対パスを入れて追従させる
        /// (予備として現在の位置・回転も入れる)。それ以外はオブジェクトの位置(足元)・回転をそのまま使う。target が null なら null。
        /// </summary>
        public static Viewpoint FromObject(ParticleLiveProject project, Transform target, string name)
        {
            if (target == null) return null;
            string anchor = "";
            GameObject root = ProjectSceneUtility.FindRoot(project);
            if (root != null)
            {
                string relative = HierarchyPathUtility.GetRelativePath(root.transform, target);
                if (!string.IsNullOrEmpty(relative)) anchor = relative;
            }
            return new Viewpoint
            {
                name = name ?? "",
                anchorPath = anchor,
                position = target.position,
                eulerAngles = target.rotation.eulerAngles,
                eyeHeight = DefaultEyeHeight,
                fieldOfView = 60f,
            };
        }

        /// <summary>「視点 N」の空いている最小の N。</summary>
        public static string NextName(IList<Viewpoint> viewpoints)
        {
            var used = new HashSet<string>(StringComparer.Ordinal);
            if (viewpoints != null)
            {
                foreach (Viewpoint vp in viewpoints)
                {
                    if (vp != null && vp.name != null) used.Add(vp.name);
                }
            }
            for (int n = 1; ; n++)
            {
                string candidate = NamePrefix + n.ToString(CultureInfo.InvariantCulture);
                if (!used.Contains(candidate)) return candidate;
            }
        }

        private static bool TryGet(ToolkitContext ctx, int index, out ParticleLiveProject project, out Viewpoint viewpoint)
        {
            project = ctx != null ? ctx.ActiveProject : null;
            viewpoint = null;
            if (project == null || project.viewpoints == null) return false;
            if (index < 0 || index >= project.viewpoints.Count) return false;
            viewpoint = project.viewpoints[index];
            return viewpoint != null;
        }
    }

    /// <summary>Scene ビューを合わせる先(目の位置・向き・垂直 FOV)。</summary>
    public struct SceneViewPose
    {
        public Vector3 EyePosition;
        public Quaternion Rotation;
        public float FieldOfView;

        /// <summary>Scene ビューのピボット(カメラは pivot − 前方 × distance に置かれるので、前方に distance 進めた点)。</summary>
        public Vector3 PivotFor(float distance)
        {
            return EyePosition + Rotation * Vector3.forward * distance;
        }
    }

    /// <summary>「Scene ビューをこの視点に合わせる」(第 1 段。プロジェクトと視点さえあれば常に動く)。</summary>
    public static class SceneViewAlignment
    {
        private const float AlignSize = 1f;

        /// <summary>視点の目の位置・向き・FOV(範囲に丸めた値)を求める。viewpoint が null なら false。</summary>
        public static bool TryCompute(ParticleLiveProject project, Viewpoint viewpoint, out SceneViewPose pose)
        {
            pose = default;
            if (!ProjectSceneUtility.TryGetViewpointPose(project, viewpoint, out Vector3 eye, out Quaternion rotation)) return false;
            pose = new SceneViewPose
            {
                EyePosition = eye,
                Rotation = rotation,
                FieldOfView = ViewpointEditing.ClampFieldOfView(viewpoint.fieldOfView),
            };
            return true;
        }

        /// <summary>
        /// Scene ビューのカメラを pose に合わせる(透視投影・2D モード解除・FOV 設定)。
        /// カメラ位置 = ピボット − 前方 × cameraDistance なので、先に向きとサイズを決めて距離を読み、ピボットを置き直す。
        /// </summary>
        public static bool Apply(SceneView view, SceneViewPose pose)
        {
            if (view == null) return false;
            try
            {
                view.in2DMode = false;
                view.orthographic = false;
                SceneView.CameraSettings settings = view.cameraSettings;
                settings.fieldOfView = pose.FieldOfView;
                view.cameraSettings = settings;
                view.LookAtDirect(pose.EyePosition, pose.Rotation, AlignSize);
                float distance = view.cameraDistance;
                view.LookAtDirect(pose.PivotFor(distance), pose.Rotation, AlignSize);
                view.Repaint();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
