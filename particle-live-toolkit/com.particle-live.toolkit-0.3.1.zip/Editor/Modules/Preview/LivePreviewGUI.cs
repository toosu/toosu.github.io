using System;
using System.Globalization;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// GUI に出す状態の写し。IMGUI は Layout と Repaint で同じ数のコントロールを描く必要があるので、
    /// 表示の有無が変わるもの(メッセージ・プレビュー中かどうか)は Layout の時点で取り込んだ値で描く。
    /// Repaint 中に変わった値(描画失敗の理由など)は次のフレームから表示される。
    /// </summary>
    internal sealed class PreviewGuiSnapshot
    {
        public bool Captured { get; private set; }
        public string Missing { get; private set; }
        public string LastMessage { get; private set; }
        public string AudioMessage { get; private set; }
        public bool IsActive { get; private set; }
        public bool DetachedWindowOpen { get; private set; }

        public void Capture(LivePreviewPlayer player)
        {
            Captured = true;
            Missing = player.GetMissingReason();
            LastMessage = player.LastMessage;
            AudioMessage = player.AudioMessage;
            IsActive = player.IsActive;
            DetachedWindowOpen = LivePreviewService.IsDetachedWindowOpen;
        }

        /// <summary>Layout イベント(またはまだ一度も取り込んでいないとき)だけ取り込む。</summary>
        public void CaptureIfLayout(LivePreviewPlayer player)
        {
            if (!Captured || Event.current == null || Event.current.type == EventType.Layout) Capture(player);
        }
    }

    /// <summary>プレビュー部分の描画(モジュール画面と別ウィンドウで共通)。ロジックは LivePreviewPlayer に置き、ここは入力と描画だけ。</summary>
    internal static class LivePreviewGUI
    {
        private const float VideoAspect = 16f / 9f;
        private const float MaxVideoHeight = 420f;
        private const double MaxPreRollSeconds = 120.0;

        public const string EditWarning =
            "プレビュー中はシーンの値を一時的に変えています(保存はされません。「停止」・タブの切り替え・保存・Play Mode で元に戻ります)。" +
            "プレビュー中にシーンを編集するとプレビューを終了します。アニメーションで動いている値をプレビュー中に変えた場合、その変更はプレビュー終了で元の値に戻ります。" +
            "プレビュー中に複製したオブジェクトには、そのときアニメーションで動いていた値(位置・有効 / 無効など)が残ります(乱数シードは元に戻ります)。";

        public static void DrawPreview(LivePreviewPlayer player, Action<string> notify, PreviewGuiSnapshot shown)
        {
            shown.CaptureIfLayout(player);
            if (shown.Missing != null)
            {
                ToolkitGUI.Hint(shown.Missing);
                return;
            }

            ParticleLiveProject project = player.Project;
            PreviewSettings settings = player.Settings;
            if (project == null || project.viewpoints == null || project.viewpoints.Count == 0) return; // Layout 後に消えた場合

            ParticleLiveToolkit.Modules.Music.MarkerModule.Pick("マーカーへ移動", project, t => { player.SetStartPosition(t); player.Seek(t); });
            DrawViewpointPopup(player, project, settings);
            DrawVideo(player);
            DrawTransport(player, notify);

            double length = player.Length;
            EditorGUI.BeginChangeCheck();
            float time = EditorGUILayout.Slider("現在時刻(秒)", (float)player.CurrentTime, 0f, (float)length);
            if (EditorGUI.EndChangeCheck()) player.Seek(time);

            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUI.BeginChangeCheck();
                double start = EditorGUILayout.DelayedDoubleField(new GUIContent("開始位置(秒)", "停止中・再生し終えた後に「再生」を押すとここから始まります"), settings.StartSeconds);
                if (EditorGUI.EndChangeCheck()) player.SetStartPosition(start);
                if (GUILayout.Button("現在時刻を入れる", GUILayout.Width(110f))) player.SetStartPosition(player.CurrentTime);
            }

            ParticleLiveToolkit.Modules.Music.MarkerModule.Pick("ループ開始マーカー", project, t => { settings.LoopStart = t; settings.LoopEnabled = true; });
            ParticleLiveToolkit.Modules.Music.MarkerModule.Pick("ループ終了マーカー", project, t => { settings.LoopEnd = t; settings.LoopEnabled = true; });
            if (GUILayout.Button("開始から1小節をループ"))
            {
                settings.LoopStart = player.CurrentTime;
                var bpm = project.bpm > 0 && !double.IsInfinity(project.bpm) ? project.bpm : ParticleLiveProject.DefaultBpm;
                settings.LoopEnd = Math.Min(length, settings.LoopStart + BeatMath.BarSeconds(bpm, Math.Max(1,project.beatsPerBar)));
                settings.LoopEnabled = settings.LoopEnd > settings.LoopStart;
            }
            settings.LoopEnabled = EditorGUILayout.ToggleLeft("区間ループ", settings.LoopEnabled);
            using (new EditorGUI.DisabledScope(!settings.LoopEnabled))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    settings.LoopStart = Math.Max(0.0, EditorGUILayout.DoubleField("ループ開始(秒)", settings.LoopStart));
                    if (GUILayout.Button("現在時刻", GUILayout.Width(70f))) settings.LoopStart = player.CurrentTime;
                }
                using (new EditorGUILayout.HorizontalScope())
                {
                    settings.LoopEnd = Math.Max(0.0, EditorGUILayout.DoubleField("ループ終了(秒)", settings.LoopEnd));
                    if (GUILayout.Button("現在時刻", GUILayout.Width(70f))) settings.LoopEnd = player.CurrentTime;
                }
                if (settings.LoopEnabled && !PreviewTimeMath.TryGetLoop(settings.LoopStart, settings.LoopEnd, length, out _, out _))
                {
                    ToolkitGUI.Warning("ループ終了をループ開始より後(クリップの長さ " + Format(length) + " 秒以内)にしてください。今はループしません");
                }
            }

            EditorGUI.BeginChangeCheck();
            double preRoll = EditorGUILayout.DoubleField(new GUIContent("pre-roll(秒)", "シークしたとき、何秒手前からパーティクルを計算し直すか"), settings.PreRollSeconds);
            if (EditorGUI.EndChangeCheck()) settings.PreRollSeconds = Math.Min(MaxPreRollSeconds, Math.Max(0.0, preRoll));

            if (GUI.changed) settings.Save(LivePreviewService.State);

            if (!string.IsNullOrEmpty(shown.LastMessage)) ToolkitGUI.Warning(shown.LastMessage);
            if (!string.IsNullOrEmpty(shown.AudioMessage))
            {
                ToolkitGUI.Hint(shown.AudioMessage);
            }
            else if (!EditorPreviewAudio.IsSupported)
            {
                ToolkitGUI.Hint(LivePreviewPlayer.NoAudioMessage);
            }
            if (shown.IsActive)
            {
                ToolkitGUI.Hint(EditWarning);
            }
            ToolkitGUI.Hint(
                "シーク直後は、pre-roll(" + Format(settings.PreRollSeconds) + " 秒)より前に出た粒子は表示されません。" +
                "プレビュー中は乱数シードを固定するため、粒子の細かい位置は Play Mode とは揃いません。" +
                "Play On Awake が OFF のパーティクルや、スクリプト(Udon)から再生するパーティクルは表示されません。");
        }

        private static void DrawViewpointPopup(LivePreviewPlayer player, ParticleLiveProject project, PreviewSettings settings)
        {
            int count = project.viewpoints.Count;
            var names = new string[count];
            for (int i = 0; i < count; i++)
            {
                Viewpoint vp = project.viewpoints[i];
                string name = vp != null && !string.IsNullOrEmpty(vp.name) ? vp.name : "(名前なし)";
                names[i] = (i + 1).ToString(CultureInfo.InvariantCulture) + ". " + name;
            }
            int current = Mathf.Clamp(settings.ViewpointIndex, 0, count - 1);
            int chosen = EditorGUILayout.Popup("視点", current, names);
            if (chosen != current || settings.ViewpointIndex != current)
            {
                // 映像は毎回 SelectedViewpoint から描くので、選び直すだけでよい
                settings.ViewpointIndex = chosen;
                settings.Save(LivePreviewService.State);
            }
        }

        private static void DrawVideo(LivePreviewPlayer player)
        {
            Rect rect = GUILayoutUtility.GetAspectRect(VideoAspect, GUILayout.MaxHeight(MaxVideoHeight));
            if (Event.current.type != EventType.Repaint) return;
            float scale = EditorGUIUtility.pixelsPerPoint;
            Texture texture = player.Render(Mathf.RoundToInt(rect.width * scale), Mathf.RoundToInt(rect.height * scale));
            if (texture != null)
            {
                GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false);
            }
            else
            {
                EditorGUI.DrawRect(rect, Color.black);
            }
        }

        private static void DrawTransport(LivePreviewPlayer player, Action<string> notify)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(player.IsPlaying ? "一時停止" : "再生", GUILayout.Height(28f)))
                {
                    if (player.IsPlaying)
                    {
                        player.Pause();
                    }
                    else if (!player.Play() && !string.IsNullOrEmpty(player.LastMessage))
                    {
                        notify?.Invoke(player.LastMessage);
                    }
                }
                using (new EditorGUI.DisabledScope(!player.IsActive && !player.HasRenderResources))
                {
                    if (GUILayout.Button("停止", GUILayout.Height(28f), GUILayout.Width(80f)))
                    {
                        player.Stop();
                        notify?.Invoke("プレビューを止めてシーンを元に戻しました");
                    }
                }
            }
        }

        public static string Format(double seconds)
        {
            return seconds.ToString("0.###", CultureInfo.InvariantCulture);
        }
    }
}
