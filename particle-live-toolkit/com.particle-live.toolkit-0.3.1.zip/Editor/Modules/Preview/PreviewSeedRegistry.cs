using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// プレビューが入れた固定シードの記録(Unity を閉じるまで SessionState に残す)。
    /// 「どのシステム(インスタンス ID)に・どの固定シードを入れ、元は何だったか」を覚えておき、プレビュー外にこぼれた固定シードを戻す:
    ///  - プレビュー中に複製された ParticleSystem(複製は固定シードを引き継ぐが、プレビュー開始時の一覧に無い)
    ///    → 同じ固定シードを最後に入れたシステムの元の値へ戻す。
    ///  - Undo / Redo で書き戻された固定シード(プレビュー中の編集の記録に入り込んだ場合の安全網)
    ///    → そのシステム自身の元の値へ戻す。
    /// 判定は「randomSeed が記録した固定シードと一致し、元の組(useAutoRandomSeed, randomSeed)と違う」。
    /// 実測で Undo は (false, 固定シード)、Redo は (true, 固定シード) を書き戻しうるので、randomSeed を目印にする。
    /// プレビュー中(PreviewSimulator が動いている間)は正当に固定しているので何もしない。
    /// 作者が偶然同じ値のシードを入れていた場合は区別できない(32bit ハッシュなので実用上起きない)。
    /// </summary>
    [InitializeOnLoad]
    internal static class PreviewSeedRegistry
    {
        private const string StateKey = "PLT.preview.fixedSeeds";
        private const int MaxEntries = 1024;

        private static List<Entry> s_entries;

        static PreviewSeedRegistry()
        {
            Undo.undoRedoPerformed += OnUndoRedo;
        }

        public static void Register(ParticleSystem system, uint fixedSeed, bool originalAuto, uint originalSeed)
        {
            if (system == null) return;
            List<Entry> entries = Entries;
            int id = system.GetInstanceID();
            entries.RemoveAll(e => e.InstanceId == id);
            if (entries.Count >= MaxEntries) entries.RemoveRange(0, entries.Count - MaxEntries + 1);
            entries.Add(new Entry(id, fixedSeed, originalAuto, originalSeed));
            Save();
        }

        /// <summary>
        /// 読み込み済みシーンの ParticleSystem のうち、記録した固定シードが残っているもの(exclude を除く)を元へ戻す。戻した数を返す。
        /// </summary>
        public static int RestoreStrays(ICollection<ParticleSystem> exclude)
        {
            List<Entry> entries = Entries;
            if (entries.Count == 0) return 0;

            var byInstance = new Dictionary<int, Entry>();
            var bySeed = new Dictionary<uint, Entry>();
            foreach (Entry e in entries)
            {
                byInstance[e.InstanceId] = e;
                bySeed[e.FixedSeed] = e; // 後から登録したものを優先
            }

            ParticleSystem[] all;
            try
            {
                all = Object.FindObjectsByType<ParticleSystem>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            }
            catch (Exception)
            {
                return 0;
            }

            int restored = 0;
            foreach (ParticleSystem ps in all)
            {
                if (ps == null || EditorUtility.IsPersistent(ps)) continue;
                if (exclude != null && exclude.Contains(ps)) continue;
                try
                {
                    uint seed = ps.randomSeed;
                    if (!byInstance.TryGetValue(ps.GetInstanceID(), out Entry entry) || entry.FixedSeed != seed)
                    {
                        if (!bySeed.TryGetValue(seed, out entry)) continue;
                    }
                    if (ps.useAutoRandomSeed == entry.OriginalAuto && seed == entry.OriginalSeed) continue;
                    ps.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
                    ps.randomSeed = entry.OriginalSeed;
                    ps.useAutoRandomSeed = entry.OriginalAuto;
                    restored++;
                }
                catch (Exception)
                {
                    // 次へ
                }
            }
            return restored;
        }

        private static void OnUndoRedo()
        {
            if (PreviewSimulator.ActiveCount > 0) return; // プレビュー中はプレイヤー側が後始末する(その中で RestoreStrays が走る)
            RestoreStrays(null);
        }

        private static List<Entry> Entries
        {
            get
            {
                if (s_entries == null) s_entries = Load();
                return s_entries;
            }
        }

        private static List<Entry> Load()
        {
            var result = new List<Entry>();
            string stored = SessionState.GetString(StateKey, "");
            if (string.IsNullOrEmpty(stored)) return result;
            foreach (string item in stored.Split(';'))
            {
                string[] parts = item.Split(':');
                if (parts.Length != 4) continue;
                if (!int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int id)) continue;
                if (!uint.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out uint fixedSeed)) continue;
                if (!uint.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out uint seed)) continue;
                result.Add(new Entry(id, fixedSeed, parts[2] == "1", seed));
            }
            return result;
        }

        private static void Save()
        {
            var sb = new StringBuilder();
            foreach (Entry e in s_entries)
            {
                if (sb.Length > 0) sb.Append(';');
                sb.Append(e.InstanceId.ToString(CultureInfo.InvariantCulture)).Append(':')
                  .Append(e.FixedSeed.ToString(CultureInfo.InvariantCulture)).Append(':')
                  .Append(e.OriginalAuto ? "1" : "0").Append(':')
                  .Append(e.OriginalSeed.ToString(CultureInfo.InvariantCulture));
            }
            SessionState.SetString(StateKey, sb.ToString());
        }

        private readonly struct Entry
        {
            public readonly int InstanceId;
            public readonly uint FixedSeed;
            public readonly bool OriginalAuto;
            public readonly uint OriginalSeed;

            public Entry(int instanceId, uint fixedSeed, bool originalAuto, uint originalSeed)
            {
                InstanceId = instanceId;
                FixedSeed = fixedSeed;
                OriginalAuto = originalAuto;
                OriginalSeed = originalSeed;
            }
        }
    }
}
