using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.LivePreview
{
    /// <summary>
    /// Edit Mode のまま、ライブルートにクリップの任意時刻を適用し、配下の ParticleSystem をその時刻の状態まで再シミュレートする(UI なし)。
    ///
    /// 方式(docs/spikes/3.2-edit-mode-preview.md):
    ///  - 専用の AnimationModeDriver で AnimationMode に入る(Animation ウィンドウのプレビューと区別するため)。
    ///    既に別のドライバが AnimationMode を使っているときは横取りせず開始しない。
    ///  - シーク: 全システムを停止・消去 → 手前(pre-roll)から固定刻みで「サンプリング → Simulate」を繰り返す。
    ///    各システムの最初の Simulate と、非アクティブ → アクティブに変わった最初の刻みは restart:true
    ///    (Play Mode の「有効化で Play On Awake から再生」に相当)。非アクティブの間は Simulate せず消去する。
    ///  - Play On Awake が OFF のシステムは単独では Simulate しない(サブエミッターとしては親経由で出る)。
    ///  - 乱数シード: 自動シードのシステムだけ、ルートからの相対パスのハッシュで固定する(同じ設定のシステムが同じ配置にならないように)。
    ///    作者が既に固定しているシステムは触らない。Dispose で元の値へ戻す。
    /// Dispose は何度呼んでも安全で、破棄済みのオブジェクトがあっても例外を出さない。
    /// </summary>
    public sealed class PreviewSimulator : IDisposable
    {
        public const string NoRootMessage = "ライブルートが見つかりません";
        public const string NoClipMessage = "メインクリップ(mainClip)が設定されていません";
        public const string PlayModeMessage = "Play Mode 中はプレビューできません。Play Mode を終了してください";
        public const string AnimationModeBusyMessage = "Animation ウィンドウなど別の機能がプレビュー(AnimationMode)を使用中です。Animation ウィンドウのプレビューを止めてから操作してください";

        private static readonly ParticleSystem[] NoSystems = new ParticleSystem[0];
        private static int s_activeCount;

        private readonly GameObject _root;
        private readonly AnimationClip _clip;
        private AnimationModeDriver _driver;
        private bool _counted;
        private GameObject _animationRoot;
        private ParticleSystem[] _systems = NoSystems;
        private bool[] _needsRestart = new bool[0];
        private readonly List<SeedBackup> _seeds = new List<SeedBackup>();

        public PreviewSimulator(GameObject root, AnimationClip clip)
        {
            _root = root;
            _clip = clip;
        }

        public GameObject Root
        {
            get { return _root; }
        }

        public AnimationClip Clip
        {
            get { return _clip; }
        }

        /// <summary>動いている(TryBegin 済みで Dispose していない)シミュレーターの数。</summary>
        internal static int ActiveCount
        {
            get { return s_activeCount; }
        }

        /// <summary>AnimationMode に入っていて、シークできる状態か。</summary>
        public bool IsActive
        {
            get { return _driver != null; }
        }

        /// <summary>アニメーションとパーティクルを合わせた時刻(秒)。</summary>
        public double SimulatedTime { get; private set; }

        /// <summary>対象の ParticleSystem(ルート配下、非アクティブ含む)。</summary>
        public IReadOnlyList<ParticleSystem> Systems
        {
            get { return _systems; }
        }

        /// <summary>AnimationMode に入り、乱数シードを固定する。失敗したら理由を error に入れて false(何も変えない)。</summary>
        public bool TryBegin(out string error)
        {
            error = null;
            if (IsActive) return true;
            if (_root == null)
            {
                error = NoRootMessage;
                return false;
            }
            if (_clip == null)
            {
                error = NoClipMessage;
                return false;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            {
                error = PlayModeMessage;
                return false;
            }
            if (AnimationMode.InAnimationMode())
            {
                error = AnimationModeBusyMessage;
                return false;
            }

            try
            {
                _driver = ScriptableObject.CreateInstance<AnimationModeDriver>();
                _driver.name = "Particle Live Toolkit Preview";
                _driver.hideFlags = HideFlags.HideAndDontSave;
                AnimationMode.StartAnimationMode(_driver);
                s_activeCount++;
                _counted = true;

                var binding = ParticleLiveToolkit.Modules.PathFixer.PathTrackingService.FindPathBase(_root.transform, out string problem);
                if (!binding) throw new InvalidOperationException(problem);
                _animationRoot = binding.gameObject;
                _systems = _root.GetComponentsInChildren<ParticleSystem>(true);
                _needsRestart = new bool[_systems.Length];
                FixSeeds();
                SimulatedTime = 0.0;
                return true;
            }
            catch (Exception e)
            {
                Dispose();
                error = "プレビューを開始できませんでした: " + e.Message;
                return false;
            }
        }

        /// <summary>time の状態を作る(pre-roll 秒手前から刻み stepSeconds で再シミュレート)。開始前なら何もしない。</summary>
        public void Seek(double time, double preRollSeconds, double stepSeconds = PreviewTimeMath.DefaultStepSeconds)
        {
            if (!IsActive) return;
            double target = double.IsNaN(time) || time < 0.0 ? 0.0 : time;
            double start = PreviewTimeMath.PreRollStart(target, preRollSeconds);

            for (int i = 0; i < _systems.Length; i++)
            {
                ParticleSystem ps = _systems[i];
                _needsRestart[i] = true;
                if (ps == null) continue;
                ps.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
            }

            Sample(start);
            SimulatedTime = start;
            AdvanceTo(target, stepSeconds);
        }

        /// <summary>現在の時刻から time まで逐次進める(戻る方向・開始前なら何もしない)。</summary>
        public void StepTo(double time, double stepSeconds = PreviewTimeMath.DefaultStepSeconds)
        {
            if (!IsActive || double.IsNaN(time) || time <= SimulatedTime) return;
            AdvanceTo(time, stepSeconds);
        }

        /// <summary>
        /// 後始末: 粒子を消去 → 乱数シード設定を戻す → 自分のドライバで AnimationMode を抜ける(値が元に戻る)→ ドライバを破棄。
        /// 何度呼んでも安全。
        /// </summary>
        public void Dispose()
        {
            ClearAll();

            foreach (SeedBackup backup in _seeds)
            {
                if (backup.System == null) continue;
                try
                {
                    // シードは停止中にしか変えられない(ClearAll で停止済み)。randomSeed → useAutoRandomSeed の順で戻す。
                    backup.System.randomSeed = backup.RandomSeed;
                    backup.System.useAutoRandomSeed = backup.UseAutoRandomSeed;
                }
                catch (Exception)
                {
                    // 破棄途中のオブジェクトなど。残りの後始末を続ける。
                }
            }
            _seeds.Clear();

            if (_driver != null)
            {
                // プレビュー中に複製されたシステムなど、一覧に無いところへこぼれた固定シードも戻す
                try
                {
                    PreviewSeedRegistry.RestoreStrays(new HashSet<ParticleSystem>(_systems));
                }
                catch (Exception)
                {
                    // 続ける
                }

                AnimationModeDriver driver = _driver;
                _driver = null;
                if (_counted)
                {
                    _counted = false;
                    s_activeCount = Math.Max(0, s_activeCount - 1);
                }
                try
                {
                    if (AnimationMode.InAnimationMode(driver)) AnimationMode.StopAnimationMode(driver);
                }
                catch (Exception)
                {
                    // 続ける
                }
                try
                {
                    Object.DestroyImmediate(driver);
                }
                catch (Exception)
                {
                    // 続ける
                }
            }

            // AnimationMode を抜けて有効 / 無効が戻った後にも念のため消去する。
            ClearAll();
            _systems = NoSystems;
            _needsRestart = new bool[0];
        }

        /// <summary>相対パスから決まる固定シード(0 以外)。FNV-1a 32bit。</summary>
        public static uint SeedFor(string relativePath)
        {
            unchecked
            {
                uint hash = 2166136261u;
                string s = relativePath ?? "";
                for (int i = 0; i < s.Length; i++)
                {
                    hash ^= s[i];
                    hash *= 16777619u;
                }
                return hash == 0u ? 1u : hash;
            }
        }

        private void AdvanceTo(double target, double stepSeconds)
        {
            double from = SimulatedTime;
            int steps = PreviewTimeMath.StepCount(from, target, stepSeconds);
            double t = from;
            for (int s = 0; s < steps; s++)
            {
                double next = PreviewTimeMath.StepTime(from, target, stepSeconds, s);
                SimulateAll((float)(next - t));
                t = next;
                Sample(t);
            }
            if (steps == 0) Sample(target);
            SimulatedTime = target;
        }

        private void SimulateAll(float dt)
        {
            if (dt <= 0f) return;
            for (int i = 0; i < _systems.Length; i++)
            {
                ParticleSystem ps = _systems[i];
                if (ps == null) continue;
                if (!ps.gameObject.activeInHierarchy)
                {
                    if (ps.particleCount > 0) ps.Clear(false);
                    _needsRestart[i] = true;
                    continue;
                }
                if (!ps.main.playOnAwake) continue;
                ps.Simulate(dt, false, _needsRestart[i], false);
                _needsRestart[i] = false;
            }
        }

        private void Sample(double time)
        {
            if (_root == null || _clip == null || _driver == null) return;
            AnimationMode.BeginSampling();
            try
            {
                AnimationMode.SampleAnimationClip(_animationRoot, _clip, (float)time);
            }
            finally
            {
                AnimationMode.EndSampling();
            }
        }

        private void FixSeeds()
        {
            _seeds.Clear();
            var used = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (ParticleSystem ps in _systems)
            {
                if (ps == null) continue;
                string path = HierarchyPathUtility.GetRelativePath(_root.transform, ps.transform) ?? ps.name;
                used.TryGetValue(path, out int n);
                used[path] = n + 1;
                if (!ps.useAutoRandomSeed) continue; // 作者が固定したシードはそのまま使う

                _seeds.Add(new SeedBackup(ps, ps.useAutoRandomSeed, ps.randomSeed));
                uint fixedSeed = SeedFor(n == 0 ? path : path + "#" + n);
                PreviewSeedRegistry.Register(ps, fixedSeed, ps.useAutoRandomSeed, ps.randomSeed);
                ps.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
                ps.useAutoRandomSeed = false;
                ps.randomSeed = fixedSeed;
            }
        }

        private void ClearAll()
        {
            foreach (ParticleSystem ps in _systems)
            {
                if (ps == null) continue;
                try
                {
                    ps.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
                    ps.Clear(false);
                }
                catch (Exception)
                {
                    // 続ける
                }
            }
        }

        private readonly struct SeedBackup
        {
            public readonly ParticleSystem System;
            public readonly bool UseAutoRandomSeed;
            public readonly uint RandomSeed;

            public SeedBackup(ParticleSystem system, bool useAutoRandomSeed, uint randomSeed)
            {
                System = system;
                UseAutoRandomSeed = useAutoRandomSeed;
                RandomSeed = randomSeed;
            }
        }
    }
}
