using System;
using System.IO;
using System.Linq;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ParticleLiveToolkit.Modules.Presets
{
    public sealed class EffectPresetModule : IToolkitModule
    {
        const string Root = "Assets/ParticleLivePresets";
        public string Id => "presets";
        public string DisplayName => "Effect Preset";
        public int Order => 11;
        string[] paths = Array.Empty<string>();
        bool refresh;
        public void OnEnable(ToolkitContext ctx) { refresh = true; EditorApplication.projectChanged += Invalidate; }
        public void OnDisable() { EditorApplication.projectChanged -= Invalidate; }
        void Invalidate() => refresh = true;

        public void OnGUI(ToolkitContext ctx)
        {
            var state = ctx.State(Id);
            string category = EditorGUILayout.TextField("保存カテゴリ",state.GetString("category", "Effects")).Trim();
            state.SetString("category",category);
            var selected = Selection.activeGameObject;
            bool valid = !string.IsNullOrEmpty(category) && category != "." && category != ".." &&
                category.IndexOfAny(Path.GetInvalidFileNameChars()) < 0 && !category.EndsWith(".");
            using (new EditorGUI.DisabledScope(!valid || !selected || !selected.scene.IsValid()))
            if (GUILayout.Button("選択した演出を保存"))
            {
                if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets","ParticleLivePresets");
                string folder = Root + "/" + category;
                if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder(Root,category);
                var filename = string.Concat(selected.name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + filename + ".prefab");
                PrefabUtility.SaveAsPrefabAsset(selected,path,out bool saved);
                refresh = true;
                ctx.ShowNotification(saved ? "演出を保存しました" : "Prefab を保存できませんでした");
            }
            string filter = EditorGUILayout.TextField("カテゴリで絞り込み",state.GetString("filter"));
            state.SetString("filter",filter);
            if (refresh)
            {
                paths = AssetDatabase.IsValidFolder(Root) ? AssetDatabase.FindAssets("t:Prefab",new[] {Root}).Select(AssetDatabase.GUIDToAssetPath).OrderBy(p => p).ToArray() : Array.Empty<string>();
                refresh = false;
            }
            foreach (string path in paths)
            {
                string folder = Path.GetFileName(Path.GetDirectoryName(path));
                if (folder.IndexOf(filter,StringComparison.OrdinalIgnoreCase)<0) continue;
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (!prefab) continue;
                using (new EditorGUILayout.HorizontalScope())
                {
                    var preview = AssetPreview.GetAssetPreview(prefab);
                    GUILayout.Label(preview ? preview : AssetPreview.GetMiniThumbnail(prefab),GUILayout.Width(48),GUILayout.Height(48));
                    if (!preview && AssetPreview.IsLoadingAssetPreview(prefab.GetInstanceID())) ctx.Repaint();
                    EditorGUILayout.LabelField(folder + " / " + prefab.name);
                    if (GUILayout.Button("配置",GUILayout.Width(45)))
                    {
                        var parent = Selection.activeTransform;
                        if (parent && !parent.gameObject.scene.IsValid()) parent = null;
                        var copy = (GameObject)PrefabUtility.InstantiatePrefab(prefab,parent ? parent.gameObject.scene : SceneManager.GetActiveScene());
                        if (parent) copy.transform.SetParent(parent,false);
                        Undo.RegisterCreatedObjectUndo(copy,"演出を配置");
                        Selection.activeGameObject=copy;
                    }
                    if (GUILayout.Button("書き出し",GUILayout.Width(70)))
                    {
                        string output = EditorUtility.SaveFilePanel("依存アセットを含むパッケージ","",prefab.name,"unitypackage");
                        if (output.Length > 0) AssetDatabase.ExportPackage(path,output,ExportPackageOptions.IncludeDependencies);
                    }
                }
            }
        }
    }
}
