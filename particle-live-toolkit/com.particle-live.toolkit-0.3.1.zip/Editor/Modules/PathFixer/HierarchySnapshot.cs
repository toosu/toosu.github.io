using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>
    /// ある時点の「オブジェクト(GameObject のインスタンス ID)→ ルートからの相対パス」の記録。
    /// ルート自身は含めない(ルートのパス "" はクリップの書き換え対象外のため)。
    /// インスタンス ID は同じ Unity 起動中・同じシーン読み込み中だけ有効。
    /// </summary>
    public sealed class HierarchySnapshot
    {
        readonly Dictionary<int, string> _paths;

        HierarchySnapshot(int rootId, Dictionary<int, string> paths, DateTime capturedAtUtc)
        {
            RootId = rootId;
            _paths = paths;
            CapturedAtUtc = capturedAtUtc;
        }

        /// <summary>ルート(パスの基準)の GameObject のインスタンス ID。ルートが無いときは 0。</summary>
        public int RootId { get; }

        /// <summary>記録した時刻(UTC)。</summary>
        public DateTime CapturedAtUtc { get; }

        /// <summary>記録したオブジェクト数(ルート自身を除く)。</summary>
        public int Count
        {
            get { return _paths.Count; }
        }

        public IEnumerable<KeyValuePair<int, string>> Entries
        {
            get { return _paths; }
        }

        public bool TryGetPath(int instanceId, out string path)
        {
            return _paths.TryGetValue(instanceId, out path);
        }

        /// <summary>root 配下(非アクティブ・非表示を含む)を記録する。root が null なら空。</summary>
        public static HierarchySnapshot Capture(Transform root)
        {
            var paths = new Dictionary<int, string>();
            if (root == null) return new HierarchySnapshot(0, paths, DateTime.UtcNow);

            var stack = new Stack<(Transform t, string path)>();
            stack.Push((root, ""));
            while (stack.Count > 0)
            {
                var (t, path) = stack.Pop();
                for (int i = t.childCount - 1; i >= 0; i--)
                {
                    Transform child = t.GetChild(i);
                    string childPath = HierarchyPathUtility.Combine(path, child.name);
                    paths[child.gameObject.GetInstanceID()] = childPath;
                    stack.Push((child, childPath));
                }
            }
            return new HierarchySnapshot(root.gameObject.GetInstanceID(), paths, DateTime.UtcNow);
        }

        /// <summary>(インスタンス ID, 相対パス) の組から作る(テスト・復元用)。同じ ID は後のものが勝つ。</summary>
        public static HierarchySnapshot FromEntries(int rootId, IEnumerable<KeyValuePair<int, string>> entries, DateTime? capturedAtUtc = null)
        {
            var paths = new Dictionary<int, string>();
            if (entries != null)
            {
                foreach (var e in entries)
                {
                    if (e.Value != null) paths[e.Key] = e.Value;
                }
            }
            return new HierarchySnapshot(rootId, paths, capturedAtUtc ?? DateTime.UtcNow);
        }

        [Serializable]
        sealed class Data
        {
            public int version = 1;
            public int rootId;
            public long capturedTicks;
            public int[] ids;
            public string[] paths;
        }

        /// <summary>SessionState に保存するための文字列(JSON)。</summary>
        public string Serialize()
        {
            var data = new Data
            {
                rootId = RootId,
                capturedTicks = CapturedAtUtc.Ticks,
                ids = new int[_paths.Count],
                paths = new string[_paths.Count],
            };
            int i = 0;
            foreach (var e in _paths)
            {
                data.ids[i] = e.Key;
                data.paths[i] = e.Value;
                i++;
            }
            return JsonUtility.ToJson(data);
        }

        /// <summary>Serialize の結果から復元する。壊れている・空なら null(例外は投げない)。</summary>
        public static HierarchySnapshot Deserialize(string text)
        {
            if (string.IsNullOrEmpty(text)) return null;
            try
            {
                var data = JsonUtility.FromJson<Data>(text);
                if (data == null || data.version != 1 || data.ids == null || data.paths == null || data.ids.Length != data.paths.Length) return null;
                if (data.capturedTicks < DateTime.MinValue.Ticks || data.capturedTicks > DateTime.MaxValue.Ticks) return null;
                var paths = new Dictionary<int, string>(data.ids.Length);
                for (int i = 0; i < data.ids.Length; i++)
                {
                    if (data.paths[i] != null) paths[data.ids[i]] = data.paths[i];
                }
                return new HierarchySnapshot(data.rootId, paths, new DateTime(data.capturedTicks, DateTimeKind.Utc));
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
