using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>
    /// 階層変更の追跡。ルート(パスの基準)を決め、基準スナップショットを保持し、現在の階層との差分を計算する。
    ///
    ///  - 基準・手動ルート・ライブ設定は ModuleState(SessionState)に置くので、再コンパイルやタブ切り替えをまたいで残る。
    ///    タブを開いていない間の変更も、次の Refresh で基準との差分として出る。
    ///  - 差分はイベントを溜めず、Refresh のたびに「基準 vs 今の階層」で計算し直す(MarkDirty は再計算の合図だけ)。
    ///  - 今のルートが基準を取ったときのルートと違う(ルートを変えた / シーンを開き直してインスタンス ID が変わった)
    ///    場合は、追跡開始として基準を取り直す。
    /// </summary>
    public sealed class PathTrackingService
    {
        internal const string BaselineKey = "baseline";
        internal const string BaselineRevisionKey = "baselineRevision";
        internal const string ManualRootIdKey = "manualRootId";
        internal const string ManualRootGlobalIdKey = "manualRootGlobalId";
        internal const string ManualRootScenePathKey = "manualRootScenePath";
        internal const string ProjectGuidKey = "projectGuid";
        internal const string BaselineEpochKey = "baselineEpoch";
        internal const string ApplyRecordKey = "applyRecord";

        /// <summary>このサービスが ModuleState に書くキー(テストの後片付け用)。</summary>
        internal static readonly string[] StateKeys =
        {
            BaselineKey, BaselineRevisionKey, ManualRootIdKey, ManualRootGlobalIdKey, ManualRootScenePathKey, ProjectGuidKey,
            BaselineEpochKey, ApplyRecordKey,
        };

        /// <summary>CheckApplyUndo の判定結果。</summary>
        public enum ApplyUndoState
        {
            /// <summary>記録が無い、または状態が変わっていない。</summary>
            None,

            /// <summary>直前の適用が Undo された(適用前の基準に戻した)。</summary>
            Undone,

            /// <summary>Undo した適用が Redo された(適用後の基準に戻した)。</summary>
            Redone,

            /// <summary>適用したクリップの中身が適用前とも適用後とも一致しない(判定できないので以後は追わない)。</summary>
            Unknown,
        }

        [Serializable]
        sealed class ApplyRecord
        {
            public string preBaseline;
            public string postBaseline;
            public int[] clipIds;
            public string[] preKeys;
            public string[] postKeys;

            // 入れ替えなどでバインディングの集合が適用前後で同じクリップだけ、中身の指紋で判定する
            public string[] preContent;
            public string[] postContent;
            public string ui;
            public bool undone;
        }

        readonly ModuleState _state;

        HierarchySnapshot _baseline;
        int _baselineRevision = int.MinValue;

        bool _projectKnown;
        ParticleLiveProject _project;

        GameObject _manualRoot;
        GameObject _specifiedRoot;
        Transform _pathRoot;
        Animator _pathRootAnimator;
        string _rootProblem;
        string _rootNote;

        HierarchyDiff _diff = HierarchyDiff.Empty;
        bool _dirty = true;

        public PathTrackingService(ModuleState state)
        {
            _state = state ?? throw new ArgumentNullException(nameof(state));
        }

        /// <summary>モジュール本体と同じ保存領域を使うサービス(シーンを開いたときなどのイベント用)。</summary>
        public static PathTrackingService CreateDefault()
        {
            return new PathTrackingService(new ModuleState(ToolkitModuleIds.PathFixer, ActiveProjectMemory.Load));
        }

        // ---- 状態 ----

        /// <summary>現在の差分(null にならない)。Refresh で更新される。</summary>
        public HierarchyDiff Diff
        {
            get { return _diff; }
        }

        /// <summary>Diff を計算し直すたびに増える(表示側のキャッシュ判定用)。</summary>
        public int DiffRevision { get; private set; }

        /// <summary>指定されたルート(手動指定、またはライブ設定のルート)。見つからなければ null。</summary>
        public GameObject SpecifiedRoot
        {
            get { return _specifiedRoot != null ? _specifiedRoot : null; }
        }

        /// <summary>パスの基準(クリップのパスはここからの相対)。SpecifiedRoot の Animator。決まらなければ null。</summary>
        public Transform PathRoot
        {
            get { return _pathRoot != null ? _pathRoot : null; }
        }

        /// <summary>PathRoot の Animator。無ければ null。</summary>
        public Animator PathRootAnimator
        {
            get { return _pathRootAnimator != null ? _pathRootAnimator : null; }
        }

        /// <summary>PathRoot が決まらない理由(日本語)。決まっていれば null。</summary>
        public string RootProblem
        {
            get { return _rootProblem; }
        }

        /// <summary>PathRoot は決まったが注意が必要なこと(Animator が無いなど)。無ければ null。</summary>
        public string RootNote
        {
            get { return _rootNote; }
        }

        /// <summary>手動で指定したルート(見つからなければ null)。</summary>
        public GameObject ManualRoot
        {
            get { return _manualRoot != null ? _manualRoot : null; }
        }

        /// <summary>手動ルートが設定されているか(見つかるかどうかに関係なく)。</summary>
        public bool UsesManualRoot
        {
            get
            {
                return _state.GetInt(ManualRootIdKey, 0) != 0
                    || _state.GetString(ManualRootGlobalIdKey, "").Length > 0
                    || _state.GetString(ManualRootScenePathKey, "").Length > 0;
            }
        }

        /// <summary>基準スナップショット。追跡していなければ null。</summary>
        public HierarchySnapshot Baseline
        {
            get
            {
                LoadBaselineIfChanged();
                return _baseline;
            }
        }

        public bool HasBaseline
        {
            get { return Baseline != null; }
        }

        /// <summary>
        /// 基準を「取り直した」回数(追跡開始・ボタン・シーンを開いた・Prefab 編集モードの出入り)。
        /// 適用による基準の部分更新と、適用の Undo / Redo による復元では増えない。チェック状態の破棄の判定に使う。
        /// </summary>
        public int BaselineEpoch
        {
            get { return _state.GetInt(BaselineEpochKey, 0); }
        }

        /// <summary>基準が今の PathRoot のものか(= 追跡中)。</summary>
        public bool IsTracking
        {
            get
            {
                var b = Baseline;
                var root = PathRoot;
                return b != null && root != null && b.RootId == root.gameObject.GetInstanceID();
            }
        }

        // ---- 操作 ----

        /// <summary>差分の再計算が必要(hierarchyChanged / Undo など)。次の Refresh で計算し直す。</summary>
        public void MarkDirty()
        {
            _dirty = true;
        }

        /// <summary>
        /// ルートを手動で指定する。null なら手動指定をやめてライブ設定のルートに戻す。
        /// シーン上のオブジェクト以外(プレハブアセットなど)は無視して false。
        /// </summary>
        public bool SetManualRoot(GameObject root)
        {
            if (root == null)
            {
                _state.SetInt(ManualRootIdKey, 0);
                _state.SetString(ManualRootGlobalIdKey, null);
                _state.SetString(ManualRootScenePathKey, null);
                _manualRoot = null;
                _dirty = true;
                return true;
            }
            if (!IsSceneObject(root)) return false;
            _state.SetInt(ManualRootIdKey, root.GetInstanceID());
            _state.SetString(ManualRootGlobalIdKey, StableGlobalId(root));
            _state.SetString(ManualRootScenePathKey, ProjectSceneUtility.GetScenePath(root.transform) ?? "");
            _manualRoot = root;
            _dirty = true;
            return true;
        }

        /// <summary>
        /// ルートを決め、必要なら追跡を始め(基準を取り)、差分を計算し直す。
        /// 再計算は MarkDirty 後・ライブ設定の変更後・基準が他から取り直された後・ルートが破棄された後だけ行う。
        /// project はライブ設定(null 可)。例外は投げない。
        /// </summary>
        public void Refresh(ParticleLiveProject project)
        {
            ParticleLiveProject p = project != null ? project : null;
            if (!_projectKnown || !ReferenceEquals(p, _project))
            {
                _projectKnown = true;
                _project = p;
                RememberProject(p);
                _dirty = true;
            }
            if (BaselineChangedElsewhere()) _dirty = true;
            if (!ReferenceEquals(_pathRoot, null) && _pathRoot == null) _dirty = true;           // ルートが破棄された
            if (!ReferenceEquals(_specifiedRoot, null) && _specifiedRoot == null) _dirty = true;
            if (!_dirty) return;
            _dirty = false;

            try
            {
                ResolveRoot(_project);
                LoadBaselineIfChanged();
                var root = PathRoot;
                if (root == null)
                {
                    SetDiff(HierarchyDiff.Empty);
                    return;
                }
                if (_baseline == null || _baseline.RootId != root.gameObject.GetInstanceID())
                {
                    // 追跡開始(初回 / ルートが変わった / シーンを開き直して ID が変わった)
                    RetakeBaseline(HierarchySnapshot.Capture(root));
                    SetDiff(HierarchyDiff.Empty);
                    return;
                }
                SetDiff(HierarchyDiffCalculator.Compute(_baseline, HierarchySnapshot.Capture(root), ExistsOutsideRoot));
            }
            catch (Exception e)
            {
                _rootProblem = "階層の確認中にエラーが発生しました: " + e.Message;
                SetDiff(HierarchyDiff.Empty);
            }
        }

        /// <summary>今の階層を基準にする(候補は 0 件になる)。ルートが決まらなければ基準を消す。</summary>
        public void Rebaseline()
        {
            try
            {
                if (!_projectKnown)
                {
                    _projectKnown = true;
                    _project = LoadRememberedProject();
                }
                ResolveRoot(_project);
                var root = PathRoot;
                RetakeBaseline(root != null ? HierarchySnapshot.Capture(root) : null);
            }
            catch (Exception e)
            {
                _rootProblem = "基準の取得中にエラーが発生しました: " + e.Message;
            }
            SetDiff(HierarchyDiff.Empty);
            _dirty = true;
        }

        /// <summary>
        /// 追跡中(基準がある)なら基準を取り直して true。追跡していなければ何もせず false。
        /// シーンを開いたとき・Prefab 編集モードの出入りで、モジュールのタブが閉じていても呼ばれる。
        /// </summary>
        public bool RebaselineIfTracking()
        {
            if (!HasBaseline) return false;
            Rebaseline();
            return true;
        }

        /// <summary>
        /// プレビューを適用し、1 クリップでも書き換えたら、基準のパスを適用したリマップで書き換える
        /// (= 適用した候補のオブジェクトと、その候補でまとめて直した子孫だけ基準が進む)。
        /// 適用しなかった候補(チェックを外したもの・要確認)は、次の Refresh でも候補として残る。
        /// 飛ばしたクリップがあっても基準は進める(同じリマップを書き換え済みのクリップへ 2 回適用しないため)。
        /// 飛ばしたクリップは結果(PathFixResult.Skipped と Remaps)に残る。
        /// uiSnapshot は適用の Undo 時に CheckApplyUndo が返す、呼び出し側の入力内容(任意の文字列)。
        /// </summary>
        public PathFixResult ApplyAndUpdateBaseline(PathFixPreview preview, string uiSnapshot = null)
        {
            var before = new Dictionary<AnimationClip, string>();
            var beforeContent = new Dictionary<AnimationClip, string>();
            if (preview != null)
            {
                foreach (var plan in preview.Plans)
                {
                    if (plan != null && plan.Clip != null && plan.Changes.Count > 0 && !before.ContainsKey(plan.Clip))
                    {
                        before.Add(plan.Clip, BindingFingerprint(plan.Clip));
                        beforeContent.Add(plan.Clip, ContentFingerprint(plan.Clip));
                    }
                }
            }
            string preBaseline = _state.GetString(BaselineKey, "");

            var result = PathFixPlanner.Apply(preview);
            if (result.Applied.Count == 0) return result;

            try
            {
                AdvanceBaseline(result.Remaps);
                var record = new ApplyRecord
                {
                    preBaseline = preBaseline,
                    postBaseline = _state.GetString(BaselineKey, ""),
                    clipIds = new int[result.Applied.Count],
                    preKeys = new string[result.Applied.Count],
                    postKeys = new string[result.Applied.Count],
                    preContent = new string[result.Applied.Count],
                    postContent = new string[result.Applied.Count],
                    ui = uiSnapshot,
                };
                for (int i = 0; i < result.Applied.Count; i++)
                {
                    var clip = result.Applied[i].Clip;
                    record.clipIds[i] = clip.GetInstanceID();
                    record.preKeys[i] = before.TryGetValue(clip, out string k) ? k : "";
                    record.postKeys[i] = BindingFingerprint(clip);
                    record.preContent[i] = "";
                    record.postContent[i] = "";
                    if (record.preKeys[i] == record.postKeys[i])
                    {
                        record.preContent[i] = beforeContent.TryGetValue(clip, out string pc) ? pc : "";
                        record.postContent[i] = ContentFingerprint(clip);
                    }
                }
                _state.SetString(ApplyRecordKey, JsonUtility.ToJson(record));
            }
            catch (Exception e)
            {
                _rootProblem = "基準の更新中にエラーが発生しました: " + e.Message;
            }
            return result;
        }

        /// <summary>
        /// 基準の各オブジェクトのパスを remaps で書き換え、基準に無い(後から追加された)オブジェクトを今のパスで足す。
        /// 基準が無い・今のルートのものでない場合は取り直す。ルートが決まらなければ何もしない。
        /// </summary>
        void AdvanceBaseline(IReadOnlyList<PathRemap> remaps)
        {
            if (!_projectKnown)
            {
                _projectKnown = true;
                _project = LoadRememberedProject();
            }
            ResolveRoot(_project);
            LoadBaselineIfChanged();
            var root = PathRoot;
            _dirty = true;
            if (root == null) return;
            int rootId = root.gameObject.GetInstanceID();
            var current = HierarchySnapshot.Capture(root);
            if (_baseline == null || _baseline.RootId != rootId)
            {
                RetakeBaseline(current);
                return;
            }
            var entries = new Dictionary<int, string>();
            var pending = new List<string>(); // まだ直していない(候補が残る)・消えたオブジェクトの基準パス
            foreach (var e in _baseline.Entries)
            {
                string path = ClipPathRemapper.RemapPath(e.Value, remaps);
                entries[e.Key] = path;
                if (!current.TryGetPath(e.Key, out string now) || !string.Equals(now, path, StringComparison.Ordinal)) pending.Add(path);
            }
            foreach (var e in current.Entries)
            {
                if (entries.ContainsKey(e.Key)) continue;
                // 後から追加されたオブジェクトは基準に足す。ただし、まだ直していない別のオブジェクトの基準パス(とその下)に
                // いるものは足さない(後でそのパスのリマップを適用したとき、一緒に書き換わって架空の候補になるため)。
                // 次の適用または取り直しで足される。
                bool blocked = false;
                foreach (string p in pending)
                {
                    if (HierarchyPathUtility.IsSameOrChildPath(e.Value, p))
                    {
                        blocked = true;
                        break;
                    }
                }
                if (!blocked) entries[e.Key] = e.Value;
            }
            SaveBaseline(HierarchySnapshot.FromEntries(rootId, entries));
        }

        /// <summary>
        /// 直前の適用が Undo / Redo されたかを、適用したクリップのバインディング構成(パス・型・プロパティの集合)で判定し、
        /// 基準を適用前 / 適用後に戻す。Undone のとき uiSnapshot に適用時の入力内容を返す。
        /// 判定できるのは最後の 1 回の適用だけ。適用後にそのクリップのカーブを足す・消すなどすると Unknown になり、以後は追わない。
        /// </summary>
        public ApplyUndoState CheckApplyUndo(out string uiSnapshot)
        {
            uiSnapshot = null;
            ApplyRecord record = LoadApplyRecord();
            if (record == null) return ApplyUndoState.None;

            bool allBefore = true;
            bool allAfter = true;
            for (int i = 0; i < record.clipIds.Length; i++)
            {
                var clip = EditorUtility.InstanceIDToObject(record.clipIds[i]) as AnimationClip;
                if (clip == null)
                {
                    allBefore = false;
                    allAfter = false;
                    break;
                }
                bool byContent = record.preContent != null && record.postContent != null && i < record.preContent.Length && i < record.postContent.Length
                    && !string.IsNullOrEmpty(record.preContent[i]);
                string now = byContent ? ContentFingerprint(clip) : BindingFingerprint(clip);
                if (now != (byContent ? record.preContent[i] : record.preKeys[i])) allBefore = false;
                if (now != (byContent ? record.postContent[i] : record.postKeys[i])) allAfter = false;
            }

            if (allAfter)
            {
                if (!record.undone) return ApplyUndoState.None;
                record.undone = false;
                _state.SetString(ApplyRecordKey, JsonUtility.ToJson(record));
                RestoreBaseline(record.postBaseline);
                return ApplyUndoState.Redone;
            }
            if (allBefore)
            {
                if (record.undone) return ApplyUndoState.None;
                record.undone = true;
                _state.SetString(ApplyRecordKey, JsonUtility.ToJson(record));
                RestoreBaseline(record.preBaseline);
                uiSnapshot = record.ui;
                return ApplyUndoState.Undone;
            }
            _state.SetString(ApplyRecordKey, null);
            return ApplyUndoState.Unknown;
        }

        ApplyRecord LoadApplyRecord()
        {
            string json = _state.GetString(ApplyRecordKey, "");
            if (json.Length == 0) return null;
            try
            {
                var record = JsonUtility.FromJson<ApplyRecord>(json);
                if (record == null || record.clipIds == null || record.preKeys == null || record.postKeys == null) return null;
                if (record.clipIds.Length != record.preKeys.Length || record.clipIds.Length != record.postKeys.Length) return null;
                return record;
            }
            catch (Exception)
            {
                return null;
            }
        }

        void RestoreBaseline(string serialized)
        {
            SaveBaseline(HierarchySnapshot.Deserialize(serialized));
            SetDiff(HierarchyDiff.Empty);
            _dirty = true;
        }

        /// <summary>クリップのバインディング構成(パス・型・プロパティ・種類)の指紋。キーの値は含めない。</summary>
        internal static string BindingFingerprint(AnimationClip clip)
        {
            return Fingerprint(clip, false);
        }

        /// <summary>
        /// バインディング構成に加えて、各カーブのキー(時刻・値、参照先)まで含めた指紋。
        /// 入れ替え(A↔B)のように適用前後でバインディングの集合が同じクリップの Undo 判定に使う。
        /// </summary>
        internal static string ContentFingerprint(AnimationClip clip)
        {
            return Fingerprint(clip, true);
        }

        static string Fingerprint(AnimationClip clip, bool content)
        {
            var items = new List<string>();
            foreach (var c in ClipEditUtility.GetAllCurves(clip))
            {
                var b = c.Binding;
                var sb = new System.Text.StringBuilder();
                sb.Append(b.path).Append('\u0001').Append(b.type != null ? b.type.FullName : "").Append('\u0001')
                  .Append(b.propertyName).Append('\u0001').Append(c.IsObjectReference ? 'P' : 'F');
                if (content)
                {
                    if (c.IsObjectReference)
                    {
                        var keys = AnimationUtility.GetObjectReferenceCurve(clip, b);
                        if (keys != null)
                        {
                            foreach (var k in keys)
                                sb.Append('|').Append(BitConverter.SingleToInt32Bits(k.time)).Append(':').Append(k.value != null ? k.value.GetInstanceID() : 0);
                        }
                    }
                    else
                    {
                        var curve = AnimationUtility.GetEditorCurve(clip, b);
                        if (curve != null)
                        {
                            foreach (var k in curve.keys)
                                sb.Append('|').Append(BitConverter.SingleToInt32Bits(k.time)).Append(':').Append(BitConverter.SingleToInt32Bits(k.value));
                        }
                    }
                }
                items.Add(sb.ToString());
            }
            items.Sort(StringComparer.Ordinal);
            // FNV-1a 64bit(SessionState に保存するので短くする)
            ulong hash = 14695981039346656037UL;
            foreach (string item in items)
            {
                foreach (char ch in item)
                {
                    hash ^= ch;
                    hash *= 1099511628211UL;
                }
                hash ^= 0xFFFF;
                hash *= 1099511628211UL;
            }
            return items.Count + ":" + hash.ToString("x16");
        }

        // ---- ルートの決定 ----

        /// <summary>
        /// 指定されたルートから「パスの基準」を決める(AnimationClip のパスは Animator からの相対のため)。
        ///  - root に Animator があれば root。
        ///  - 無ければ、子孫のうち最も浅い Animator(1 つだけのとき)。
        ///  - 最も浅い Animator が複数あれば推測せず null を返し、problem に理由を入れる。
        ///  - Animator が 1 つも無ければ root(problem は null)。
        /// </summary>
        public static Transform FindPathBase(Transform root, out string problem)
        {
            problem = null;
            if (root == null) return null;
            if (root.GetComponent<Animator>() != null) return root;

            int bestDepth = int.MaxValue;
            var best = new List<Transform>();
            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                if (animator == null) continue;
                Transform t = animator.transform;
                int depth = 0;
                for (Transform x = t; x != null && x != root; x = x.parent) depth++;
                if (depth < bestDepth)
                {
                    bestDepth = depth;
                    best.Clear();
                    best.Add(t);
                }
                else if (depth == bestDepth && !best.Contains(t))
                {
                    best.Add(t);
                }
            }
            if (best.Count == 0) return root;
            if (best.Count == 1) return best[0];

            var names = new List<string>();
            foreach (var t in best) names.Add(HierarchyPathUtility.GetRelativePath(root, t));
            problem = "「" + root.name + "」の下の同じ深さに Animator が " + best.Count + " 個あります(" + string.Join(", ", names)
                + ")。どの Animator のクリップを直すか決められないため、その Animator のオブジェクトをルートとして手動で指定してください。";
            return null;
        }

        void ResolveRoot(ParticleLiveProject project)
        {
            _rootProblem = null;
            _rootNote = null;
            _specifiedRoot = null;
            _pathRoot = null;
            _pathRootAnimator = null;

            GameObject specified;
            if (UsesManualRoot)
            {
                _manualRoot = ResolveManualRoot();
                specified = _manualRoot;
                if (specified == null)
                {
                    _rootProblem = "手動で指定したルートが見つかりません(削除されたか、別のシーンにあります)。ルートを指定し直してください。";
                    return;
                }
            }
            else
            {
                _manualRoot = null;
                if (project == null)
                {
                    _rootProblem = "ライブ(プロジェクト設定)が選ばれていません。上部バーでライブを選ぶか、ルートを手動で指定してください。";
                    return;
                }
                specified = ProjectSceneUtility.FindRoot(project);
                if (specified == null)
                {
                    _rootProblem = "ライブのルートがシーンに見つかりません。ライブのシーンを開くか、ルートを手動で指定してください。";
                    return;
                }
            }

            _specifiedRoot = specified;
            Transform pathRoot = FindPathBase(specified.transform, out string problem);
            if (pathRoot == null)
            {
                _rootProblem = problem ?? "パスの基準を決められません。";
                return;
            }
            _pathRoot = pathRoot;
            _pathRootAnimator = pathRoot.GetComponent<Animator>();
            if (_pathRootAnimator == null)
            {
                _rootNote = "ルートの下に Animator が無いため、「" + specified.name + "」からのパスで調べます。対象クリップは手動で追加してください。";
            }
        }

        GameObject ResolveManualRoot()
        {
            int id = _state.GetInt(ManualRootIdKey, 0);
            if (id != 0)
            {
                var byId = EditorUtility.InstanceIDToObject(id) as GameObject;
                if (IsSceneObject(byId)) return byId;
            }

            GameObject found = null;
            string globalId = _state.GetString(ManualRootGlobalIdKey, "");
            if (globalId.Length > 0)
            {
                try
                {
                    if (GlobalObjectId.TryParse(globalId, out GlobalObjectId gid))
                    {
                        Object obj = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(gid);
                        found = obj as GameObject;
                        if (found == null && obj is Component component && component != null) found = component.gameObject;
                    }
                }
                catch (Exception)
                {
                    found = null;
                }
                if (!IsSceneObject(found)) found = null;
            }
            if (found == null) found = FindByScenePath(_state.GetString(ManualRootScenePathKey, ""));
            if (found != null) _state.SetInt(ManualRootIdKey, found.GetInstanceID()); // シーンを開き直した後の新しい ID を覚える
            return found;
        }

        static GameObject FindByScenePath(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            int slash = path.IndexOf('/');
            string first = slash < 0 ? path : path.Substring(0, slash);
            string rest = slash < 0 ? null : path.Substring(slash + 1);
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded) continue;
                foreach (GameObject go in scene.GetRootGameObjects())
                {
                    if (go.name != first) continue;
                    if (string.IsNullOrEmpty(rest)) return go;
                    Transform t = go.transform.Find(rest);
                    if (t != null) return t.gameObject;
                }
            }
            return null;
        }

        static bool IsSceneObject(GameObject go)
        {
            return go != null && !EditorUtility.IsPersistent(go) && go.scene.IsValid();
        }

        static string StableGlobalId(GameObject go)
        {
            try
            {
                GlobalObjectId id = GlobalObjectId.GetGlobalObjectIdSlow(go);
                if (id.identifierType == 0 || id.assetGUID.Empty() || id.targetObjectId == 0) return null;
                return id.ToString();
            }
            catch (Exception)
            {
                return null;
            }
        }

        static bool ExistsOutsideRoot(int instanceId)
        {
            return EditorUtility.InstanceIDToObject(instanceId) is GameObject go && go != null;
        }

        // ---- 保存 ----

        void RememberProject(ParticleLiveProject project)
        {
            string guid = null;
            if (project != null && AssetDatabase.TryGetGUIDAndLocalFileIdentifier(project, out string found, out long _)) guid = found;
            if (_state.GetString(ProjectGuidKey, "") != (guid ?? "")) _state.SetString(ProjectGuidKey, guid);
        }

        ParticleLiveProject LoadRememberedProject()
        {
            string guid = _state.GetString(ProjectGuidKey, "");
            if (guid.Length == 0) return null;
            string path = AssetDatabase.GUIDToAssetPath(guid);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<ParticleLiveProject>(path);
        }

        bool BaselineChangedElsewhere()
        {
            return _state.GetInt(BaselineRevisionKey, 0) != _baselineRevision;
        }

        void LoadBaselineIfChanged()
        {
            int revision = _state.GetInt(BaselineRevisionKey, 0);
            if (revision == _baselineRevision) return;
            _baseline = HierarchySnapshot.Deserialize(_state.GetString(BaselineKey, ""));
            _baselineRevision = revision;
        }

        /// <summary>基準を取り直す(チェック状態の破棄の合図として BaselineEpoch を進め、適用の記録を捨てる)。</summary>
        void RetakeBaseline(HierarchySnapshot snapshot)
        {
            SaveBaseline(snapshot);
            _state.SetInt(BaselineEpochKey, _state.GetInt(BaselineEpochKey, 0) + 1);
            _state.SetString(ApplyRecordKey, null);
        }

        void SaveBaseline(HierarchySnapshot snapshot)
        {
            _state.SetString(BaselineKey, snapshot != null ? snapshot.Serialize() : null);
            int revision = _state.GetInt(BaselineRevisionKey, 0) + 1;
            _state.SetInt(BaselineRevisionKey, revision);
            _baseline = snapshot;
            _baselineRevision = revision;
        }

        void SetDiff(HierarchyDiff diff)
        {
            _diff = diff ?? HierarchyDiff.Empty;
            DiffRevision++;
        }
    }
}
