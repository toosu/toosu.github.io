using System;
using System.Collections.Generic;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>
    /// 候補のチェック状態(既定と違うものだけを「旧パス + 新パス」のキーで覚える)。
    /// 古いチェック状態が、後で同じ組み合わせの別の候補に残らないよう、
    ///  - 基準を取り直したら(BaselineEpoch が変わったら)すべて消す、
    ///  - 今の候補に無いキーは消す、
    /// を行う。
    /// </summary>
    internal sealed class CandidateSelection
    {
        readonly Dictionary<string, bool> _overrides = new Dictionary<string, bool>(StringComparer.Ordinal);

        /// <summary>このチェック状態が対応する基準の世代(PathTrackingService.BaselineEpoch)。</summary>
        public int Epoch { get; private set; }

        public int Count
        {
            get { return _overrides.Count; }
        }

        public bool IsSelected(PathCandidate candidate)
        {
            if (candidate == null) return false;
            return _overrides.TryGetValue(candidate.Key, out bool v) ? v : PathFixPlanner.IsSelectedByDefault(candidate);
        }

        public void Set(PathCandidate candidate, bool selected)
        {
            if (candidate == null) return;
            if (selected == PathFixPlanner.IsSelectedByDefault(candidate)) _overrides.Remove(candidate.Key);
            else _overrides[candidate.Key] = selected;
        }

        public void Clear()
        {
            _overrides.Clear();
        }

        /// <summary>基準の世代が変わっていればチェック状態を消して true。</summary>
        public bool SyncEpoch(int epoch)
        {
            if (epoch == Epoch) return false;
            Epoch = epoch;
            if (_overrides.Count == 0) return true;
            _overrides.Clear();
            return true;
        }

        /// <summary>今の候補に無いキーを消す。消したものがあれば true。</summary>
        public bool Prune(IEnumerable<PathCandidate> candidates)
        {
            if (_overrides.Count == 0) return false;
            var alive = new HashSet<string>(StringComparer.Ordinal);
            if (candidates != null)
            {
                foreach (var c in candidates)
                {
                    if (c != null) alive.Add(c.Key);
                }
            }
            var dead = new List<string>();
            foreach (var key in _overrides.Keys)
            {
                if (!alive.Contains(key)) dead.Add(key);
            }
            foreach (var key in dead) _overrides.Remove(key);
            return dead.Count > 0;
        }

        /// <summary>保存用に書き出す。</summary>
        public void Write(List<string> checkedKeys, List<string> uncheckedKeys, out int epoch)
        {
            checkedKeys.Clear();
            uncheckedKeys.Clear();
            foreach (var kv in _overrides)
            {
                if (kv.Value) checkedKeys.Add(kv.Key);
                else uncheckedKeys.Add(kv.Key);
            }
            epoch = Epoch;
        }

        /// <summary>保存した内容から読み込む。</summary>
        public void Read(IEnumerable<string> checkedKeys, IEnumerable<string> uncheckedKeys, int epoch)
        {
            _overrides.Clear();
            if (checkedKeys != null)
            {
                foreach (string k in checkedKeys)
                {
                    if (k != null) _overrides[k] = true;
                }
            }
            if (uncheckedKeys != null)
            {
                foreach (string k in uncheckedKeys)
                {
                    if (k != null) _overrides[k] = false;
                }
            }
            Epoch = epoch;
        }
    }
}
