using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>
    /// 基準を取り直すエディタイベント(シーンを開いたとき、Prefab 編集モードの出入り)。
    /// モジュールのタブを開いていなくても動くよう、エディタ起動時に登録する。
    /// 追跡していない(基準が無い)ときは何もしない。
    /// </summary>
    [InitializeOnLoad]
    internal static class PathFixerEditorEvents
    {
        /// <summary>イベントで基準を取り直したとき(開いているモジュールの再描画用)。</summary>
        internal static event Action BaselineRetaken;

        static PathFixerEditorEvents()
        {
            EditorSceneManager.sceneOpened += OnSceneOpened;
            EditorSceneManager.newSceneCreated += OnNewSceneCreated;
            PrefabStage.prefabStageOpened += OnPrefabStageOpened;
            PrefabStage.prefabStageClosing += OnPrefabStageClosing;
        }

        static void OnSceneOpened(Scene scene, OpenSceneMode mode)
        {
            // 追加で開いたシーン(Additive)では既存のオブジェクトの ID は変わらないので取り直さない。
            // ルートが変わった場合は PathTrackingService.Refresh が追跡開始として取り直す。
            if (mode == OpenSceneMode.Single) Retake();
        }

        static void OnNewSceneCreated(Scene scene, NewSceneSetup setup, NewSceneMode mode)
        {
            if (mode == NewSceneMode.Single) Retake();
        }

        static void OnPrefabStageOpened(PrefabStage stage)
        {
            Retake();
        }

        static void OnPrefabStageClosing(PrefabStage stage)
        {
            // 閉じた後(シーン側のインスタンスが更新された後)の階層を基準にする
            EditorApplication.delayCall += Retake;
        }

        static void Retake()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            try
            {
                if (PathTrackingService.CreateDefault().RebaselineIfTracking()) BaselineRetaken?.Invoke();
            }
            catch (Exception e)
            {
                Debug.LogWarning("[ParticleLiveToolkit] Path Fixer の基準の取り直しに失敗しました: " + e.Message);
            }
        }
    }
}
