using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>
    /// ② Animation Path Fixer。Hierarchy での改名・親の付け替えを基準との差分で検知し、
    /// AnimationClip 内のパスをユーザーの確認後に書き換える(自動適用はしない)。
    /// 計算はすべて HierarchyDiffCalculator / PathFixPlanner / PathTrackingService にあり、ここは入力と描画だけ。
    /// </summary>
    public sealed class PathFixerModule : IToolkitModule
    {
        const string UiStateKey = "ui";
        const int MaxDetailLines = 200;

        [Serializable]
        sealed class UiState
        {
            public List<ManualRemap> manual = new List<ManualRemap>();
            public List<string> clipRefs = new List<string>();
            public List<string> checkedKeys = new List<string>();
            public List<string> uncheckedKeys = new List<string>();
            public int selectionEpoch;

            // 前回の適用で飛ばしたクリップ(未修正のまま)と、そのとき使ったリマップ
            public List<ManualRemap> retryRemaps = new List<ManualRemap>();
            public List<string> retryClipRefs = new List<string>();
        }

        ParticleLiveProject owner;
        ToolkitContext _ctx;
        ModuleState _moduleState;
        PathTrackingService _service;
        UiState _ui = new UiState();
        readonly List<AnimationClip> _manualClips = new List<AnimationClip>();
        readonly CandidateSelection _selection = new CandidateSelection();
        readonly List<AnimationClip> _retryClips = new List<AnimationClip>();
        readonly HashSet<int> _expandedClips = new HashSet<int>();

        // Layout イベントでだけ更新する表示用の計算結果
        bool _previewDirty = true;
        int _seenDiffRevision = -1;
        bool _playMode;
        List<AnimationClip> _clips = new List<AnimationClip>();
        RemapBuildResult _build = new RemapBuildResult();
        PathFixPreview _preview = new PathFixPreview();
        List<BrokenPath> _broken = new List<BrokenPath>();
        PathFixResult _lastResult;
        PathFixPreview _retryPreview;
        string _notice;

        public string Id
        {
            get { return ToolkitModuleIds.PathFixer; }
        }

        public string DisplayName
        {
            get { return "Path Fixer"; }
        }

        public int Order
        {
            get { return ToolkitModuleIds.PathFixerOrder; }
        }

        public void OnEnable(ToolkitContext ctx)
        {
            _ctx = ctx;
            owner = ctx.ActiveProject;
            var live = owner;
            _moduleState = new ModuleState(Id, () => live);
            _service = new PathTrackingService(_moduleState);
            LoadUi();
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
            Undo.undoRedoPerformed += OnUndoRedo;
            EditorApplication.projectChanged += OnAssetsChanged;
            PathFixerEditorEvents.BaselineRetaken += OnHierarchyChanged;
            ctx.ProjectChanged += OnHierarchyChanged;
            _service.MarkDirty();
            _previewDirty = true;
            // タブを閉じている間に適用が Undo / Redo された場合もここで拾う
            HandleApplyUndo();
        }

        public void OnDisable()
        {
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
            Undo.undoRedoPerformed -= OnUndoRedo;
            EditorApplication.projectChanged -= OnAssetsChanged;
            PathFixerEditorEvents.BaselineRetaken -= OnHierarchyChanged;
            if (_ctx != null) _ctx.ProjectChanged -= OnHierarchyChanged;
            if (_moduleState != null) SaveUi();
            _ctx = null;
        }

        void OnHierarchyChanged()
        {
            // 合図として使うだけ。差分は次の Layout で基準と比べて計算し直す。
            if (_ctx != null && _ctx.ActiveProject != owner)
            {
                SaveUi();
                owner = _ctx.ActiveProject;
                var live = owner;
                _moduleState = new ModuleState(Id, () => live);
                _service = new PathTrackingService(_moduleState);
                _seenDiffRevision = -1;
                _lastResult = null;
                _notice = null;
                LoadUi();
            }
            _service?.MarkDirty();
            _previewDirty = true;
            _ctx?.Repaint();
        }

        void OnUndoRedo()
        {
            HandleApplyUndo();
            OnHierarchyChanged();
        }

        /// <summary>直前の「パスを修正」が Undo / Redo されたら、基準と入力内容を合わせる。</summary>
        void HandleApplyUndo()
        {
            if (_service == null) return;
            var state = _service.CheckApplyUndo(out string snapshot);
            switch (state)
            {
                case PathTrackingService.ApplyUndoState.Undone:
                    RestoreInputs(snapshot);
                    _lastResult = null;
                    _ui.retryRemaps.Clear();
                    _retryClips.Clear();
                    _notice = null;
                    SaveUi();
                    _ctx?.ShowNotification("パスの修正を取り消しました。検知した変更と手動リマップを元に戻しました");
                    break;
                case PathTrackingService.ApplyUndoState.Redone:
                    _ui.manual.Clear();
                    _selection.Clear();
                    SaveUi();
                    _ctx?.ShowNotification("パスの修正をやり直しました");
                    break;
                case PathTrackingService.ApplyUndoState.Unknown:
                    _notice = "パスの修正を取り消した可能性がありますが、クリップの内容が修正の前とも後とも一致しないため、検知した変更は戻していません。"
                        + "クリップのパスが今の階層と合わない場合は、「リンク切れ」の「手動リマップへ」から直してください。";
                    break;
            }
            if (state != PathTrackingService.ApplyUndoState.None)
            {
                _service.MarkDirty();
                _previewDirty = true;
                _ctx?.Repaint();
            }
        }

        void RestoreInputs(string snapshot)
        {
            if (string.IsNullOrEmpty(snapshot)) return;
            UiState saved = null;
            try
            {
                saved = JsonUtility.FromJson<UiState>(snapshot);
            }
            catch (Exception)
            {
                saved = null;
            }
            if (saved == null) return;
            _ui.manual = saved.manual ?? new List<ManualRemap>();
            _selection.Read(saved.checkedKeys, saved.uncheckedKeys, _service.BaselineEpoch);
        }

        void OnAssetsChanged()
        {
            _previewDirty = true;
            _ctx?.Repaint();
        }

        // ---- 描画 ----

        public void OnGUI(ToolkitContext ctx)
        {
            if (_service == null)
            {
                OnEnable(ctx);
            }
            else if (!ReferenceEquals(ctx, _ctx))
            {
                OnDisable();
                OnEnable(ctx);
            }

            if (Event.current.type == EventType.Layout) Recompute(ctx);

            ToolkitGUI.Section("Path Fixer");
            EditorGUILayout.LabelField("Hierarchy でオブジェクトの名前や親を変えたときに、AnimationClip 内のパスを直します。", EditorStyles.wordWrappedMiniLabel);

            if (_playMode)
            {
                ToolkitGUI.Hint("Play Mode 中は使えません。Play Mode を終了してください。");
                return;
            }

            DrawRoot();
            DrawCandidates();
            DrawManualRemaps();
            DrawBrokenPaths();
            DrawClips();
            DrawPreview();
            DrawApply();
            DrawResult();
        }

        void Recompute(ToolkitContext ctx)
        {
            _playMode = EditorApplication.isPlayingOrWillChangePlaymode;
            if (_playMode) return;

            _service.Refresh(ctx.ActiveProject);
            if (_selection.SyncEpoch(_service.BaselineEpoch))
            {
                // 基準を取り直した(シーンを開いた・Prefab 編集モードの出入り・ボタンなど)ので古いチェック状態は捨てる
                SaveUi();
                _previewDirty = true;
            }
            if (_service.DiffRevision != _seenDiffRevision)
            {
                _seenDiffRevision = _service.DiffRevision;
                if (_selection.Prune(_service.Diff.Candidates)) SaveUi();
                _previewDirty = true;
            }
            if (!_previewDirty) return;
            _previewDirty = false;

            Compute(out _clips, out _build, out _preview);
            _broken = PathFixPlanner.FindBrokenPaths(_clips, _service.PathRoot);
            _retryPreview = ComputeRetryPreview();
        }

        void Compute(out List<AnimationClip> clips, out RemapBuildResult build, out PathFixPreview preview)
        {
            var animator = _service.PathRootAnimator;
            var controller = animator != null ? animator.runtimeAnimatorController : null;
            clips = PathFixPlanner.CollectTargetClips(controller, _manualClips);
            build = PathFixPlanner.BuildRemaps(_service.Diff.Candidates, IsSelected, _ui.manual);
            preview = PathFixPlanner.Preview(clips, build.Remaps);
        }

        PathFixPreview ComputeRetryPreview()
        {
            _retryClips.RemoveAll(c => c == null);
            if (_retryClips.Count == 0 || _ui.retryRemaps.Count == 0) return null;
            var remaps = new List<PathRemap>();
            foreach (var r in _ui.retryRemaps) remaps.Add(new PathRemap(r.OldPath, r.NewPath));
            return PathFixPlanner.Preview(_retryClips, remaps);
        }

        void DrawRoot()
        {
            ToolkitGUI.Section("ルート");
            EditorGUI.BeginChangeCheck();
            var picked = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("ルート(手動指定)", "空のときは上部バーのライブ設定のルートを使います。"),
                _service.ManualRoot, typeof(GameObject), true);
            if (EditorGUI.EndChangeCheck())
            {
                if (picked != null && EditorUtility.IsPersistent(picked))
                {
                    _ctx.ShowNotification("シーン上のオブジェクトを指定してください");
                }
                else
                {
                    Structural(() => _service.SetManualRoot(picked));
                }
            }

            if (_service.UsesManualRoot && _service.ManualRoot == null && GUILayout.Button("手動指定をやめる(ライブ設定のルートを使う)", GUILayout.ExpandWidth(false)))
            {
                Structural(() => _service.SetManualRoot(null));
            }

            if (_service.RootProblem != null)
            {
                ToolkitGUI.Warning(_service.RootProblem);
                return;
            }

            var root = _service.PathRoot;
            string label = ProjectSceneUtility.GetScenePath(root) + (_service.PathRootAnimator != null ? "(Animator)" : "");
            EditorGUILayout.LabelField(new GUIContent("パスの基準", "クリップ内のパスはこのオブジェクトからの相対パスです。"), new GUIContent(label));
            if (_service.RootNote != null) ToolkitGUI.Hint(_service.RootNote);

            using (new EditorGUILayout.HorizontalScope())
            {
                var baseline = _service.Baseline;
                string status = _service.IsTracking && baseline != null
                    ? "追跡中: " + baseline.CapturedAtUtc.ToLocalTime().ToString("HH:mm:ss") + " に基準を取得(" + baseline.Count + " オブジェクト)"
                    : "基準がありません";
                EditorGUILayout.LabelField(status, EditorStyles.miniLabel);
                if (GUILayout.Button(new GUIContent("基準を取り直す", "今の階層を基準にします。検知した変更はすべて消えます。"), GUILayout.ExpandWidth(false)))
                {
                    Structural(() =>
                    {
                        _service.Rebaseline();
                        _selection.Clear();
                        _notice = null;
                        SaveUi();
                        _ctx.ShowNotification("基準を取り直しました");
                    });
                }
            }
        }

        void DrawCandidates()
        {
            var diff = _service.Diff;
            ToolkitGUI.Section("検知した変更(" + diff.Candidates.Count + " 件)");
            if (_service.PathRoot == null)
            {
                ToolkitGUI.Hint("ルートが決まると、名前や親の変更を自動で検知します。");
                return;
            }
            if (diff.Candidates.Count == 0)
            {
                ToolkitGUI.Hint("変更はありません。Hierarchy で名前や親を変えると、ここに「旧パス → 新パス」が出ます。シーンを閉じていた間の変更は検知できないため、下の「リンク切れ」と「手動リマップ」を使ってください。");
            }

            foreach (var c in diff.Candidates)
            {
                bool selected = IsSelected(c);
                bool now = EditorGUILayout.ToggleLeft(new GUIContent(c.OldPath + "  →  " + c.NewPath, c.OldPath + " → " + c.NewPath), selected);
                if (now != selected) SetSelected(c, now);
                if (c.NeedsReview)
                {
                    using (new EditorGUI.IndentLevelScope())
                    {
                        foreach (string reason in c.ReviewReasons)
                        {
                            EditorGUILayout.LabelField("要確認: " + reason, EditorStyles.wordWrappedMiniLabel);
                        }
                    }
                }
            }

            if (diff.Missing.Count > 0)
            {
                var lines = new List<string>
                {
                    "次のオブジェクトはルートの下から無くなりました。これら自身を指す候補は出しません。",
                    "ただし親を改名・移動していて、その候補を適用すると、これらへのバインディングも親に合わせてパスだけ書き換わります(オブジェクトを戻せばそのまま使えます):",
                };
                foreach (var m in diff.Missing) lines.Add("・" + m.Path + (m.MovedOutOfRoot ? "(ルートの外へ移動)" : "(削除)"));
                ToolkitGUI.Warning(string.Join("\n", lines));
            }
        }

        void DrawManualRemaps()
        {
            ToolkitGUI.Section("手動リマップ");
            if (_ui.manual.Count == 0) EditorGUILayout.LabelField("旧パスと新パスを入力して置き換えます(例: Effects/Fire → FX/Fire)。", EditorStyles.wordWrappedMiniLabel);

            for (int i = 0; i < _ui.manual.Count; i++)
            {
                var row = _ui.manual[i];
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUI.BeginChangeCheck();
                    string o = EditorGUILayout.TextField(row.OldPath ?? "", GUILayout.MinWidth(80f));
                    GUILayout.Label("→", GUILayout.ExpandWidth(false));
                    string n = EditorGUILayout.TextField(row.NewPath ?? "", GUILayout.MinWidth(80f));
                    if (EditorGUI.EndChangeCheck())
                    {
                        row.OldPath = o;
                        row.NewPath = n;
                        SaveUi();
                        _previewDirty = true;
                        _ctx.Repaint();
                    }
                    if (GUILayout.Button("削除", GUILayout.ExpandWidth(false)))
                    {
                        int index = i;
                        Structural(() =>
                        {
                            _ui.manual.RemoveAt(index);
                            SaveUi();
                        });
                    }
                }
            }
            if (GUILayout.Button("行を追加", GUILayout.ExpandWidth(false)))
            {
                Structural(() =>
                {
                    _ui.manual.Add(new ManualRemap());
                    SaveUi();
                });
            }
        }

        void DrawBrokenPaths()
        {
            ToolkitGUI.Section("リンク切れ(" + _broken.Count + " 件)");
            if (_service.PathRoot == null)
            {
                ToolkitGUI.Hint("ルートが決まると、クリップ内で見つからないパスを調べられます。");
                return;
            }
            if (_clips.Count == 0)
            {
                ToolkitGUI.Hint("対象クリップがありません。");
                return;
            }
            if (_broken.Count == 0)
            {
                EditorGUILayout.LabelField("対象クリップのパスはすべて今の階層で見つかります。", EditorStyles.wordWrappedMiniLabel);
                return;
            }
            foreach (var b in _broken)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(b.Path + "(" + b.Clips.Count + " クリップ)", ClipNames(b.Clips)));
                    if (GUILayout.Button(new GUIContent("手動リマップへ", "このパスを手動リマップの旧パス欄に入れます。"), GUILayout.ExpandWidth(false)))
                    {
                        string path = b.Path;
                        Structural(() => SendToManual(path));
                    }
                }
            }
        }

        void SendToManual(string path)
        {
            ManualRemap last = _ui.manual.Count > 0 ? _ui.manual[_ui.manual.Count - 1] : null;
            if (last != null && string.IsNullOrEmpty(last.OldPath) && string.IsNullOrEmpty(last.NewPath)) last.OldPath = path;
            else _ui.manual.Add(new ManualRemap { OldPath = path });
            SaveUi();
            _ctx.ShowNotification("「" + path + "」を手動リマップの旧パス欄に入れました");
        }

        void DrawClips()
        {
            ToolkitGUI.Section("対象クリップ(" + _clips.Count + ")");
            var animator = _service.PathRootAnimator;
            if (_service.PathRoot != null && animator != null && animator.runtimeAnimatorController == null)
            {
                ToolkitGUI.Hint("Animator に Controller が設定されていません。クリップを手動で追加してください。");
            }

            foreach (var clip in _clips)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    using (new EditorGUI.DisabledScope(true))
                    {
                        EditorGUILayout.ObjectField(clip, typeof(AnimationClip), false);
                    }
                    if (_manualClips.Contains(clip))
                    {
                        if (GUILayout.Button("外す", GUILayout.ExpandWidth(false)))
                        {
                            var target = clip;
                            Structural(() =>
                            {
                                _manualClips.Remove(target);
                                SaveUi();
                            });
                        }
                    }
                    else
                    {
                        GUILayout.Label("Controller", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                    }
                }
            }

            EditorGUI.BeginChangeCheck();
            var added = (AnimationClip)EditorGUILayout.ObjectField(new GUIContent("クリップを追加", "Controller に入っていないクリップも対象にします。"), null, typeof(AnimationClip), false);
            if (EditorGUI.EndChangeCheck() && added != null)
            {
                Structural(() =>
                {
                    if (!_manualClips.Contains(added)) _manualClips.Add(added);
                    SaveUi();
                });
            }
        }

        void DrawPreview()
        {
            ToolkitGUI.Section("プレビュー");
            foreach (string error in _build.Errors) ToolkitGUI.Error(error);
            if (_build.Remaps.Count == 0)
            {
                ToolkitGUI.Hint("直すパスがありません。検知した変更にチェックを入れるか、手動リマップを入力してください。");
                return;
            }

            bool any = false;
            foreach (var plan in _preview.Plans)
            {
                if (plan.Changes.Count == 0) continue;
                any = true;
                string name = plan.Clip != null ? plan.Clip.name : "(削除されたクリップ)";
                if (!plan.CanApply)
                {
                    ToolkitGUI.Warning(name + ": 飛ばします。" + PathFixPlanner.SkipReason(plan));
                    continue;
                }
                int id = plan.Clip.GetInstanceID();
                bool expanded = _expandedClips.Contains(id);
                bool now = EditorGUILayout.Foldout(expanded, name + ": " + plan.Changes.Count + " バインディング", true);
                if (now != expanded)
                {
                    Structural(() =>
                    {
                        if (now) _expandedClips.Add(id);
                        else _expandedClips.Remove(id);
                    });
                }
                if (!now) continue;
                using (new EditorGUI.IndentLevelScope())
                {
                    int shown = 0;
                    foreach (var ch in plan.Changes)
                    {
                        if (shown++ >= MaxDetailLines)
                        {
                            EditorGUILayout.LabelField("…ほか " + (plan.Changes.Count - MaxDetailLines) + " 件", EditorStyles.miniLabel);
                            break;
                        }
                        string type = ch.OldBinding.type != null ? ch.OldBinding.type.Name : "?";
                        EditorGUILayout.LabelField(ch.OldBinding.path + " → " + ch.NewPath + "(" + type + "." + ch.OldBinding.propertyName + ")", EditorStyles.miniLabel);
                    }
                }
            }
            if (!any)
            {
                ToolkitGUI.Hint("対象クリップに、このリマップで変わるバインディングはありません。");
                return;
            }

            string summary = _preview.ApplicableClipCount + " クリップ / " + _preview.TotalChanges + " バインディングを書き換えます";
            if (_preview.SkippedClipCount > 0) summary += "(飛ばすクリップ " + _preview.SkippedClipCount + ")";
            EditorGUILayout.LabelField(summary, EditorStyles.boldLabel);

            var missing = new List<string>();
            foreach (var m in _service.Diff.Missing) missing.Add(m.Path);
            int underMissing = PathFixPlanner.CountChangesUnder(_preview, missing);
            if (underMissing > 0)
            {
                ToolkitGUI.Hint("このうち、消えた / ルートの外へ出たオブジェクトへのバインディング " + underMissing
                    + " 件も、親の変更に合わせてパスだけ書き換わります(オブジェクトをルートの下へ戻せばそのまま使えます)。");
            }
        }

        void DrawApply()
        {
            GUILayout.Space(6f);
            if (_notice != null) ToolkitGUI.Warning(_notice);
            if (ToolkitGUI.PrimaryButton("パスを修正", ApplyBlockReason()))
            {
                Structural(DoApply);
            }
        }

        string ApplyBlockReason()
        {
            int pendingRetry = _retryPreview != null ? _retryClips.Count : 0;
            return PathFixPlanner.GetApplyBlockReason(_build, _clips.Count, _preview, pendingRetry);
        }

        void DoApply()
        {
            // 押した時点で作り直し、表示していたプレビューと違えば適用せずに新しいプレビューを見せる
            _service.Refresh(_ctx.ActiveProject);
            if (_selection.SyncEpoch(_service.BaselineEpoch)) SaveUi();
            Compute(out var clips, out var build, out var preview);
            if (build.Errors.Count > 0 || !PathFixPlanner.SamePreview(_preview, preview))
            {
                _clips = clips;
                _build = build;
                _preview = preview;
                _broken = PathFixPlanner.FindBrokenPaths(_clips, _service.PathRoot);
                _notice = "プレビューを表示した後に階層・入力・クリップの内容が変わりました。新しいプレビューを確認してから、もう一度「パスを修正」を押してください。";
                return;
            }
            _notice = null;

            SaveUi();
            string snapshot = JsonUtility.ToJson(_ui); // 適用を Undo したときに戻す入力内容
            var result = _service.ApplyAndUpdateBaseline(preview, snapshot);
            _lastResult = result;
            if (result.Applied.Count > 0)
            {
                // 同じリマップを 2 回適用しない(入れ替えが元に戻るなど)ように、使った手動リマップは消す
                _ui.manual.Clear();
            }
            _ui.retryRemaps.Clear();
            _retryClips.Clear();
            if (result.Skipped.Count > 0)
            {
                foreach (var r in result.Remaps) _ui.retryRemaps.Add(new ManualRemap { OldPath = r.OldPath, NewPath = r.NewPath });
                foreach (var sk in result.Skipped)
                {
                    if (sk.Clip != null && !_retryClips.Contains(sk.Clip)) _retryClips.Add(sk.Clip);
                }
            }
            SaveUi();
            string message = result.Applied.Count + " クリップ / " + result.TotalBindings + " バインディングを修正しました";
            if (result.Skipped.Count > 0) message += "(未修正のクリップ " + result.Skipped.Count + ")";
            _ctx.ShowNotification(message);
        }

        void DrawResult()
        {
            if (_lastResult != null)
            {
                ToolkitGUI.Section("前回の修正");
                ToolkitGUI.Hint(_lastResult.Applied.Count + " クリップ / " + _lastResult.TotalBindings + " バインディングを修正しました。Undo(Ctrl+Z)1 回で全クリップを元に戻せます(検知した変更と手動リマップも戻ります)。");
            }

            if (_retryPreview != null)
            {
                ToolkitGUI.Section("未修正のクリップ(" + _retryClips.Count + ")");
                ToolkitGUI.Warning("次のクリップは飛ばしたため、古いパスのまま未修正です。原因を直してから「もう一度試す」を押すと、前回と同じ修正をこれらのクリップだけに適用します。");
                foreach (var plan in _retryPreview.Plans)
                {
                    string name = plan.Clip != null ? plan.Clip.name : "(削除されたクリップ)";
                    string line;
                    if (plan.Changes.Count == 0) line = name + ": 変わるバインディングはありません(すでに直っています)。";
                    else if (plan.CanApply) line = name + ": もう一度試すと " + plan.Changes.Count + " バインディングを書き換えます。";
                    else line = name + ": このクリップは未修正のままです。" + PathFixPlanner.SkipReason(plan);
                    EditorGUILayout.LabelField(line, EditorStyles.wordWrappedMiniLabel);
                }
                using (new EditorGUILayout.HorizontalScope())
                {
                    using (new EditorGUI.DisabledScope(_retryPreview.TotalChanges == 0))
                    {
                        if (GUILayout.Button("もう一度試す", GUILayout.ExpandWidth(false))) Structural(DoRetry);
                    }
                    if (GUILayout.Button("未修正の一覧を閉じる", GUILayout.ExpandWidth(false)))
                    {
                        Structural(() =>
                        {
                            _ui.retryRemaps.Clear();
                            _retryClips.Clear();
                            SaveUi();
                        });
                    }
                }
            }

            if (_lastResult != null && GUILayout.Button("結果を閉じる", GUILayout.ExpandWidth(false)))
            {
                Structural(() => _lastResult = null);
            }
        }

        void DoRetry()
        {
            var fresh = ComputeRetryPreview();
            if (!PathFixPlanner.SamePreview(_retryPreview, fresh))
            {
                _retryPreview = fresh;
                _notice = "未修正のクリップの内容が変わりました。表示を確認してから、もう一度「もう一度試す」を押してください。";
                return;
            }
            var result = PathFixPlanner.Apply(fresh);
            foreach (var a in result.Applied) _retryClips.Remove(a.Clip);
            if (_retryClips.Count == 0) _ui.retryRemaps.Clear();
            SaveUi();
            _ctx.ShowNotification(result.Applied.Count + " クリップ / " + result.TotalBindings + " バインディングを修正しました");
        }

        // ---- 状態 ----

        bool IsSelected(PathCandidate c)
        {
            return _selection.IsSelected(c);
        }

        void SetSelected(PathCandidate c, bool value)
        {
            _selection.Set(c, value);
            SaveUi();
            _previewDirty = true;
            _ctx.Repaint();
        }

        /// <summary>表示の構造が変わる操作。実行して、このイベントの描画を打ち切る(次の Layout で計算し直す)。</summary>
        void Structural(Action action)
        {
            action();
            _previewDirty = true;
            _ctx?.Repaint();
            GUIUtility.ExitGUI();
        }

        static string ClipNames(List<AnimationClip> clips)
        {
            var names = new List<string>();
            foreach (var c in clips) names.Add(c != null ? c.name : "(削除されたクリップ)");
            return string.Join(", ", names);
        }

        void LoadUi()
        {
            _ui = null;
            string json = _moduleState.GetString(UiStateKey, "");
            if (json.Length > 0)
            {
                try
                {
                    _ui = JsonUtility.FromJson<UiState>(json);
                }
                catch (Exception)
                {
                    _ui = null;
                }
            }
            if (_ui == null) _ui = new UiState();
            if (_ui.manual == null) _ui.manual = new List<ManualRemap>();
            if (_ui.retryRemaps == null) _ui.retryRemaps = new List<ManualRemap>();

            LoadClips(_ui.clipRefs, _manualClips);
            LoadClips(_ui.retryClipRefs, _retryClips);
            _selection.Read(_ui.checkedKeys, _ui.uncheckedKeys, _ui.selectionEpoch);
        }

        static void LoadClips(List<string> ids, List<AnimationClip> into)
        {
            into.Clear();
            if (ids == null) return;
            foreach (string id in ids)
            {
                if (LiveSettings.Resolve<AnimationClip>(id) is AnimationClip clip && clip != null && !into.Contains(clip)) into.Add(clip);
            }
        }

        void SaveUi()
        {
            if (_moduleState == null) return;
            _ui.clipRefs = new List<string>();
            foreach (var clip in _manualClips)
            {
                if (clip != null) _ui.clipRefs.Add(LiveSettings.Identifier(clip));
            }
            _ui.retryClipRefs = new List<string>();
            foreach (var clip in _retryClips)
            {
                if (clip != null) _ui.retryClipRefs.Add(LiveSettings.Identifier(clip));
            }
            _ui.checkedKeys = new List<string>();
            _ui.uncheckedKeys = new List<string>();
            _selection.Write(_ui.checkedKeys, _ui.uncheckedKeys, out _ui.selectionEpoch);
            _moduleState.SetString(UiStateKey, JsonUtility.ToJson(_ui));
        }
    }
}
