using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>手動リマップの 1 行(UI 状態として保存するので Serializable)。</summary>
    [Serializable]
    public sealed class ManualRemap
    {
        public string OldPath = "";
        public string NewPath = "";
    }

    /// <summary>適用するリマップの一覧と、適用を止める理由。</summary>
    public sealed class RemapBuildResult
    {
        public readonly List<PathRemap> Remaps = new List<PathRemap>();

        /// <summary>1 件でもあれば適用できない(日本語、1 件 1 行)。</summary>
        public readonly List<string> Errors = new List<string>();
    }

    /// <summary>適用前のプレビュー(クリップごとの計画)。</summary>
    public sealed class PathFixPreview
    {
        public readonly List<PathRemap> Remaps = new List<PathRemap>();

        /// <summary>対象クリップすべての計画(変更なしのクリップも含む)。</summary>
        public readonly List<PathRemapPlan> Plans = new List<PathRemapPlan>();

        /// <summary>適用されるバインディング数(飛ばすクリップの分は含めない)。</summary>
        public int TotalChanges;

        /// <summary>適用されるクリップ数。</summary>
        public int ApplicableClipCount;

        /// <summary>変更はあるが衝突・書き換え不可で飛ばすクリップ数。</summary>
        public int SkippedClipCount;
    }

    public sealed class AppliedClip
    {
        public AnimationClip Clip;
        public int Bindings;
    }

    public sealed class SkippedClip
    {
        public AnimationClip Clip;
        public string Reason;
    }

    /// <summary>適用結果。</summary>
    public sealed class PathFixResult
    {
        public readonly List<AppliedClip> Applied = new List<AppliedClip>();
        public readonly List<SkippedClip> Skipped = new List<SkippedClip>();

        /// <summary>適用に使ったリマップ(飛ばしたクリップに同じ修正をやり直すときに使う)。</summary>
        public readonly List<PathRemap> Remaps = new List<PathRemap>();

        /// <summary>書き換えたバインディング数の合計。</summary>
        public int TotalBindings;
    }

    /// <summary>リンク切れのパス 1 件と、それを使っているクリップ。</summary>
    public sealed class BrokenPath
    {
        public string Path;
        public readonly List<AnimationClip> Clips = new List<AnimationClip>();
    }

    /// <summary>リマップの組み立て・プレビュー・適用(UI なし)。</summary>
    public static class PathFixPlanner
    {
        public const string UndoName = "パスの修正";

        /// <summary>候補の既定のチェック状態(要確認は外す)。</summary>
        public static bool IsSelectedByDefault(PathCandidate candidate)
        {
            return candidate != null && !candidate.NeedsReview;
        }

        /// <summary>
        /// 選んだ候補と手動リマップから、適用するリマップの一覧を作る。次の場合は Errors に理由を入れる(= 適用しない):
        ///  - 手動リマップの行が不完全(旧パス / 新パスが空、同じ、先頭・末尾の「/」や空のセグメント)。両方空の行は無視する。
        ///  - 同じ旧パスに異なる新パスが指定されている。
        ///  - 新パスが、選ばれていない候補の旧パスと重なる(連鎖・入れ替えの片方だけを適用すると、
        ///    別のオブジェクトのバインディングと混ざるため)。
        ///  - 選ばれていない候補の旧パスが、選んだ祖先のリマップで別のパスへ動かされる(入れ子の入れ替えの片方だけなど)。
        /// </summary>
        public static RemapBuildResult BuildRemaps(IReadOnlyList<PathCandidate> candidates, Func<PathCandidate, bool> isSelected, IReadOnlyList<ManualRemap> manual)
        {
            var result = new RemapBuildResult();
            var select = isSelected ?? IsSelectedByDefault;
            var unselected = new List<PathCandidate>();
            var sources = new List<string>(); // Remaps と同じ並びで、表示用の出どころ

            if (candidates != null)
            {
                foreach (var c in candidates)
                {
                    if (c == null) continue;
                    if (select(c)) Add(result, sources, new PathRemap(c.OldPath, c.NewPath), "候補");
                    else unselected.Add(c);
                }
            }

            if (manual != null)
            {
                for (int i = 0; i < manual.Count; i++)
                {
                    var row = manual[i];
                    if (row == null) continue;
                    string o = row.OldPath ?? "";
                    string n = row.NewPath ?? "";
                    string label = "手動リマップ " + (i + 1) + " 行目";
                    if (o.Length == 0 && n.Length == 0) continue;
                    if (o.Length == 0)
                    {
                        result.Errors.Add(label + ": 旧パスを入力してください。");
                        continue;
                    }
                    if (n.Length == 0)
                    {
                        result.Errors.Add(label + ": 新パスを入力してください。");
                        continue;
                    }
                    if (!IsWellFormed(o) || !IsWellFormed(n))
                    {
                        result.Errors.Add(label + ": パスの先頭・末尾に「/」を付けず、「//」も使わないでください(例: Effects/Fire)。");
                        continue;
                    }
                    if (string.Equals(o, n, StringComparison.Ordinal))
                    {
                        result.Errors.Add(label + ": 旧パスと新パスが同じです。");
                        continue;
                    }
                    Add(result, sources, new PathRemap(o, n), label);
                }
            }

            // 同じ旧パスに異なる新パス
            for (int i = 0; i < result.Remaps.Count; i++)
            {
                for (int j = i + 1; j < result.Remaps.Count; j++)
                {
                    var a = result.Remaps[i];
                    var b = result.Remaps[j];
                    if (string.Equals(a.OldPath, b.OldPath, StringComparison.Ordinal) && !string.Equals(a.NewPath, b.NewPath, StringComparison.Ordinal))
                    {
                        result.Errors.Add("旧パス「" + a.OldPath + "」に 2 つの新パス(「" + a.NewPath + "」(" + sources[i] + ")と「" + b.NewPath + "」(" + sources[j] + "))が指定されています。どちらか一方にしてください。");
                    }
                }
            }

            // 選ばれていない候補の旧パスと重なる新パス
            foreach (var r in result.Remaps)
            {
                foreach (var u in unselected)
                {
                    if (string.Equals(u.OldPath, r.OldPath, StringComparison.Ordinal)) continue; // 同じ旧パスを別の新パスへ = 上の重複チェックの対象外(選ばれていない側は使わない)
                    if (HierarchyPathUtility.IsSameOrChildPath(r.NewPath, u.OldPath) || HierarchyPathUtility.IsSameOrChildPath(u.OldPath, r.NewPath))
                    {
                        result.Errors.Add("「" + r.OldPath + " → " + r.NewPath + "」を適用するには、候補「" + u.OldPath + " → " + u.NewPath + "」にもチェックを入れてください(「" + u.OldPath + "」は別のオブジェクトの旧パスで、片方だけ直すとバインディングが混ざります)。");
                    }
                }
            }

            // 選ばれていない候補のオブジェクトが、選んだ祖先のリマップに巻き込まれて別のパスへ動かされる
            // (例: P → Q を選び、P/B → Q/A を外すと、P/B のバインディングが Q/B へ行き、別のオブジェクトを指す)
            foreach (var u in unselected)
            {
                bool explicitlyRemapped = false;
                foreach (var r in result.Remaps)
                {
                    if (string.Equals(r.OldPath, u.OldPath, StringComparison.Ordinal))
                    {
                        explicitlyRemapped = true; // 同じ旧パスを手動で別の新パスへ指定している(利用者の明示)
                        break;
                    }
                }
                if (explicitlyRemapped) continue;
                string carried = ClipPathRemapper.RemapPath(u.OldPath, result.Remaps);
                if (!string.Equals(carried, u.OldPath, StringComparison.Ordinal))
                {
                    result.Errors.Add("候補「" + u.OldPath + " → " + u.NewPath + "」にチェックが無いため、そのバインディングが親のリマップで「" + carried
                        + "」へ動き、別のオブジェクトを指してしまいます。この候補にもチェックを入れるか、親の候補のチェックを外してください。");
                }
            }
            return result;
        }

        static void Add(RemapBuildResult result, List<string> sources, PathRemap remap, string source)
        {
            foreach (var r in result.Remaps)
            {
                if (string.Equals(r.OldPath, remap.OldPath, StringComparison.Ordinal) && string.Equals(r.NewPath, remap.NewPath, StringComparison.Ordinal)) return;
            }
            result.Remaps.Add(remap);
            sources.Add(source);
        }

        static bool IsWellFormed(string path)
        {
            if (path.StartsWith("/", StringComparison.Ordinal) || path.EndsWith("/", StringComparison.Ordinal)) return false;
            return path.IndexOf("//", StringComparison.Ordinal) < 0;
        }

        /// <summary>対象クリップすべてについて計画を作る(クリップは変更しない)。</summary>
        public static PathFixPreview Preview(IReadOnlyList<AnimationClip> clips, IReadOnlyList<PathRemap> remaps)
        {
            var preview = new PathFixPreview();
            if (remaps != null) preview.Remaps.AddRange(remaps);
            if (clips == null || preview.Remaps.Count == 0) return preview;

            var seen = new HashSet<AnimationClip>();
            foreach (var clip in clips)
            {
                if (clip == null || !seen.Add(clip)) continue;
                var plan = ClipPathRemapper.Plan(clip, preview.Remaps);
                preview.Plans.Add(plan);
                if (plan.Changes.Count == 0) continue;
                if (plan.CanApply)
                {
                    preview.ApplicableClipCount++;
                    preview.TotalChanges += plan.Changes.Count;
                }
                else
                {
                    preview.SkippedClipCount++;
                }
            }
            return preview;
        }

        /// <summary>
        /// 「パスを修正」を押せない理由。押せるなら null。
        /// pendingRetryClips は前回の適用で飛ばして未修正のまま残っているクリップ数。
        /// </summary>
        public static string GetApplyBlockReason(RemapBuildResult build, int clipCount, PathFixPreview preview, int pendingRetryClips)
        {
            if (build == null || preview == null) return "プレビューがありません。";
            if (pendingRetryClips > 0)
                return "前回の修正で未修正のまま残っているクリップがあります。「未修正のクリップ」で「もう一度試す」か「未修正の一覧を閉じる」を先に行ってください。";
            if (build.Errors.Count > 0) return "プレビューのエラーを解決してください。";
            if (build.Remaps.Count == 0) return "直すパスがありません(検知した変更にチェックを入れるか、手動リマップを入力してください)。";
            if (clipCount == 0) return "対象クリップがありません(ルートの Animator に Controller を設定するか、クリップを手動で追加してください)。";
            if (preview.TotalChanges == 0)
            {
                return preview.SkippedClipCount > 0
                    ? "適用できるクリップがありません(すべて飛ばす対象です)。"
                    : "このリマップで変わるバインディングがありません。";
            }
            return null;
        }

        /// <summary>変更があるのに適用できない計画の理由。適用できる・変更なしなら null。</summary>
        public static string SkipReason(PathRemapPlan plan)
        {
            if (plan == null || plan.Changes.Count == 0 || plan.CanApply) return null;
            if (plan.BlockReason != null) return plan.BlockReason;
            return "書き換え後に同じバインディングが重複するため飛ばします: " + string.Join(" / ", plan.Conflicts);
        }

        /// <summary>
        /// プレビューを適用する。全クリップの書き換えを Undo 1 回にまとめる。
        /// 衝突・書き換え不可・プレビュー後に変更されたクリップは飛ばし、結果に理由を入れる(他のクリップは適用する)。
        /// </summary>
        public static PathFixResult Apply(PathFixPreview preview, string undoName = UndoName)
        {
            var result = new PathFixResult();
            if (preview == null) return result;
            result.Remaps.AddRange(preview.Remaps);
            string name = string.IsNullOrEmpty(undoName) ? UndoName : undoName;

            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(name);
            try
            {
                foreach (var plan in preview.Plans)
                {
                    if (plan == null || plan.Changes.Count == 0) continue;
                    if (!plan.CanApply)
                    {
                        result.Skipped.Add(new SkippedClip { Clip = plan.Clip, Reason = SkipReason(plan) });
                        continue;
                    }
                    if (plan.Clip == null)
                    {
                        result.Skipped.Add(new SkippedClip { Clip = null, Reason = "クリップが削除されています。" });
                        continue;
                    }

                    // プレビュー後にクリップが変わっていないか(プレビューの件数 = 適用件数を保証する)
                    var fresh = ClipPathRemapper.Plan(plan.Clip, preview.Remaps);
                    if (!SamePlan(plan, fresh))
                    {
                        string reason = SkipReason(fresh) ?? "プレビューの後にクリップが変更されたため飛ばしました。もう一度確認してから適用してください。";
                        result.Skipped.Add(new SkippedClip { Clip = plan.Clip, Reason = reason });
                        continue;
                    }

                    try
                    {
                        int n = ClipPathRemapper.Apply(fresh, name);
                        result.Applied.Add(new AppliedClip { Clip = plan.Clip, Bindings = n });
                        result.TotalBindings += n;
                    }
                    catch (Exception e)
                    {
                        result.Skipped.Add(new SkippedClip { Clip = plan.Clip, Reason = "書き換えに失敗しました: " + e.Message });
                    }
                }
            }
            finally
            {
                Undo.CollapseUndoOperations(group);
            }
            return result;
        }

        /// <summary>
        /// 2 つのプレビューが同じ内容か(リマップ、対象クリップ、各クリップの変更・衝突・書き換え不可の理由)。
        /// 「パスを修正」を押した時点で作り直したプレビューが、表示していたものと違えば適用しないために使う。
        /// </summary>
        public static bool SamePreview(PathFixPreview a, PathFixPreview b)
        {
            if (a == null || b == null) return a == null && b == null;
            if (a.Remaps.Count != b.Remaps.Count || a.Plans.Count != b.Plans.Count) return false;
            for (int i = 0; i < a.Remaps.Count; i++)
            {
                if (!string.Equals(a.Remaps[i].OldPath, b.Remaps[i].OldPath, StringComparison.Ordinal)) return false;
                if (!string.Equals(a.Remaps[i].NewPath, b.Remaps[i].NewPath, StringComparison.Ordinal)) return false;
            }
            for (int i = 0; i < a.Plans.Count; i++)
            {
                var x = a.Plans[i];
                var y = b.Plans[i];
                if (x.Clip != y.Clip || x.CanApply != y.CanApply) return false;
                if (!string.Equals(x.BlockReason, y.BlockReason, StringComparison.Ordinal)) return false;
                if (x.Conflicts.Count != y.Conflicts.Count) return false;
                for (int j = 0; j < x.Conflicts.Count; j++)
                {
                    if (!string.Equals(x.Conflicts[j], y.Conflicts[j], StringComparison.Ordinal)) return false;
                }
                if (!SameChanges(x, y)) return false;
            }
            return a.TotalChanges == b.TotalChanges && a.ApplicableClipCount == b.ApplicableClipCount && a.SkippedClipCount == b.SkippedClipCount;
        }

        /// <summary>
        /// 適用されるバインディングのうち、旧パスが paths(消えたオブジェクトのパス)と同じかその子孫のものの数。
        /// これらは親の変更に合わせてパスだけ書き換わる(オブジェクトを戻せばそのまま使える)。
        /// </summary>
        public static int CountChangesUnder(PathFixPreview preview, IEnumerable<string> paths)
        {
            if (preview == null || paths == null) return 0;
            var list = new List<string>(paths);
            if (list.Count == 0) return 0;
            int count = 0;
            foreach (var plan in preview.Plans)
            {
                if (plan == null || !plan.CanApply) continue;
                foreach (var ch in plan.Changes)
                {
                    foreach (string p in list)
                    {
                        if (!string.IsNullOrEmpty(p) && HierarchyPathUtility.IsSameOrChildPath(ch.OldBinding.path, p))
                        {
                            count++;
                            break;
                        }
                    }
                }
            }
            return count;
        }

        static bool SamePlan(PathRemapPlan a, PathRemapPlan b)
        {
            return b.CanApply && SameChanges(a, b);
        }

        static bool SameChanges(PathRemapPlan a, PathRemapPlan b)
        {
            if (a.Changes.Count != b.Changes.Count) return false;
            for (int i = 0; i < a.Changes.Count; i++)
            {
                var x = a.Changes[i];
                var y = b.Changes[i];
                if (x.OldBinding != y.OldBinding || x.IsObjectReference != y.IsObjectReference) return false;
                if (!string.Equals(x.NewPath, y.NewPath, StringComparison.Ordinal)) return false;
            }
            return true;
        }

        /// <summary>
        /// クリップ内のパスのうち、root から解決できないもの(パスの Ordinal 昇順、パスごとに使っているクリップをまとめる)。
        /// root が null なら空(調べられない)。
        /// </summary>
        public static List<BrokenPath> FindBrokenPaths(IReadOnlyList<AnimationClip> clips, Transform root)
        {
            var result = new List<BrokenPath>();
            if (clips == null || root == null) return result;
            var byPath = new Dictionary<string, BrokenPath>(StringComparer.Ordinal);
            var seen = new HashSet<AnimationClip>();
            foreach (var clip in clips)
            {
                if (clip == null || !seen.Add(clip)) continue;
                foreach (string path in ClipPathRemapper.FindMissingPaths(clip, root))
                {
                    if (!byPath.TryGetValue(path, out var entry))
                    {
                        entry = new BrokenPath { Path = path };
                        byPath.Add(path, entry);
                        result.Add(entry);
                    }
                    entry.Clips.Add(clip);
                }
            }
            result.Sort((a, b) => string.CompareOrdinal(a.Path, b.Path));
            return result;
        }

        /// <summary>
        /// 対象クリップ: controller が使う全クリップ(ClipEditUtility.CollectClips)→ 手動追加分の順。重複・null は除く。
        /// </summary>
        public static List<AnimationClip> CollectTargetClips(RuntimeAnimatorController controller, IEnumerable<AnimationClip> manual)
        {
            var result = new List<AnimationClip>();
            var seen = new HashSet<AnimationClip>();
            foreach (var clip in ClipEditUtility.CollectClips(controller))
            {
                if (clip != null && seen.Add(clip)) result.Add(clip);
            }
            if (manual != null)
            {
                foreach (var clip in manual)
                {
                    if (clip != null && seen.Add(clip)) result.Add(clip);
                }
            }
            return result;
        }
    }
}
