using System;
using System.Collections.Generic;
using ParticleLiveToolkit.Core;

namespace ParticleLiveToolkit.Modules.PathFixer
{
    /// <summary>検知した「旧パス → 新パス」の候補 1 件。</summary>
    public sealed class PathCandidate
    {
        public readonly string OldPath;
        public readonly string NewPath;

        /// <summary>変更されたオブジェクト(候補の起点)のインスタンス ID。</summary>
        public readonly int InstanceId;

        /// <summary>「要確認」の理由(日本語、1 件 1 行)。空なら確認不要。</summary>
        public readonly List<string> ReviewReasons = new List<string>();

        public PathCandidate(string oldPath, string newPath, int instanceId)
        {
            OldPath = oldPath ?? "";
            NewPath = newPath ?? "";
            InstanceId = instanceId;
        }

        /// <summary>要確認(既定でチェックを外す)か。</summary>
        public bool NeedsReview
        {
            get { return ReviewReasons.Count > 0; }
        }

        /// <summary>チェック状態の保存用キー。</summary>
        public string Key
        {
            get { return OldPath + "\n" + NewPath; }
        }

        internal void AddReason(string reason)
        {
            if (!ReviewReasons.Contains(reason)) ReviewReasons.Add(reason);
        }
    }

    /// <summary>基準にはあったが、今はルートの下に無いオブジェクト(子孫は最上位にまとめる)。</summary>
    public sealed class MissingPath
    {
        /// <summary>基準でのパス。</summary>
        public string Path;

        public int InstanceId;

        /// <summary>true = オブジェクトは残っているがルートの外へ移動した / false = 削除された。</summary>
        public bool MovedOutOfRoot;
    }

    /// <summary>基準と現在の差分。</summary>
    public sealed class HierarchyDiff
    {
        public readonly List<PathCandidate> Candidates = new List<PathCandidate>();
        public readonly List<MissingPath> Missing = new List<MissingPath>();

        public static HierarchyDiff Empty
        {
            get { return new HierarchyDiff(); }
        }
    }

    /// <summary>
    /// 基準スナップショットと現在のスナップショットから候補を計算する(純粋関数。イベントは溜めない)。
    ///
    /// 不変条件: 基準と現在の両方にあるオブジェクトはすべて、全候補を ClipPathRemapper.RemapPath で
    /// 同時に適用したとき旧パスが新パスに写る。写せない(恒等の上書きが必要な)場合は、
    /// 原因の候補を「要確認」にする。
    /// </summary>
    public static class HierarchyDiffCalculator
    {
        /// <param name="existsOutsideRoot">
        /// 現在ルートの下に無いオブジェクトが、シーン上には残っている(ルートの外へ移動した)かを返す。null なら常に false(削除扱い)。
        /// </param>
        public static HierarchyDiff Compute(HierarchySnapshot baseline, HierarchySnapshot current, Func<int, bool> existsOutsideRoot = null)
        {
            var diff = new HierarchyDiff();
            if (baseline == null || current == null) return diff;
            if (baseline.RootId != current.RootId) return diff; // 別のルート同士は比べない

            var survivors = new List<Entry>();
            var gone = new List<Entry>();
            foreach (var e in baseline.Entries)
            {
                if (current.TryGetPath(e.Key, out string now)) survivors.Add(new Entry(e.Key, e.Value, now));
                else gone.Add(new Entry(e.Key, e.Value, null));
            }
            survivors.Sort(Entry.Compare);
            gone.Sort(Entry.Compare);

            // 1. 浅い順に見て、既に採った候補で説明できない変更だけを候補にする(子孫は親の候補にまとまる)
            var remaps = new List<PathRemap>();
            foreach (var s in survivors)
            {
                if (string.Equals(s.OldPath, s.NewPath, StringComparison.Ordinal)) continue;
                if (string.Equals(ClipPathRemapper.RemapPath(s.OldPath, remaps), s.NewPath, StringComparison.Ordinal)) continue;
                diff.Candidates.Add(new PathCandidate(s.OldPath, s.NewPath, s.Id));
                remaps.Add(new PathRemap(s.OldPath, s.NewPath));
            }

            // 2. 消えたもの(子孫は最上位にまとめる)
            foreach (var g in gone)
            {
                bool covered = false;
                foreach (var m in diff.Missing)
                {
                    if (HierarchyPathUtility.IsSameOrChildPath(g.OldPath, m.Path))
                    {
                        covered = true;
                        break;
                    }
                }
                if (covered) continue;
                bool outside = false;
                if (existsOutsideRoot != null)
                {
                    try
                    {
                        outside = existsOutsideRoot(g.Id);
                    }
                    catch (Exception)
                    {
                        outside = false;
                    }
                }
                diff.Missing.Add(new MissingPath { Path = g.OldPath, InstanceId = g.Id, MovedOutOfRoot = outside });
            }

            if (diff.Candidates.Count == 0) return diff;
            FlagForReview(diff, survivors, baseline, current);
            return diff;
        }

        static void FlagForReview(HierarchyDiff diff, List<Entry> survivors, HierarchySnapshot baseline, HierarchySnapshot current)
        {
            var baseCount = CountPaths(baseline);
            var currentCount = CountPaths(current);
            var remaps = new List<PathRemap>(diff.Candidates.Count);
            foreach (var c in diff.Candidates) remaps.Add(new PathRemap(c.OldPath, c.NewPath));

            foreach (var c in diff.Candidates)
            {
                if (currentCount.ContainsKey(c.OldPath))
                    c.AddReason("旧パス「" + c.OldPath + "」は今の階層でも別のオブジェクトを指しています(入れ替え・同名の別オブジェクトなど)。");
                if (baseCount.TryGetValue(c.OldPath, out int nb) && nb > 1)
                    c.AddReason("基準の階層に「" + c.OldPath + "」が " + nb + " 個あり、どれのパスか区別できません。");
                if (currentCount.TryGetValue(c.NewPath, out int nc) && nc > 1)
                    c.AddReason("今の階層に「" + c.NewPath + "」が " + nc + " 個あり、どれを指すか区別できません。");
                foreach (var m in diff.Missing)
                {
                    if (HierarchyPathUtility.IsSameOrChildPath(c.NewPath, m.Path) || HierarchyPathUtility.IsSameOrChildPath(m.Path, c.NewPath))
                    {
                        c.AddReason("新パス「" + c.NewPath + "」は、消えたオブジェクト「" + m.Path + "」のパスと重なります。");
                        break;
                    }
                }
            }

            // 候補を全部適用しても新しいパスへ写らないオブジェクトがあれば、その原因の候補を要確認にする
            foreach (var s in survivors)
            {
                string mapped = ClipPathRemapper.RemapPath(s.OldPath, remaps);
                if (string.Equals(mapped, s.NewPath, StringComparison.Ordinal)) continue;
                PathCandidate culprit = LongestPrefixCandidate(diff.Candidates, s.OldPath);
                if (culprit == null) continue;
                culprit.AddReason("この候補を適用すると「" + s.OldPath + "」のバインディングが「" + mapped + "」に変わりますが、そのオブジェクトは今「" + s.NewPath + "」にあります。");
            }
        }

        static PathCandidate LongestPrefixCandidate(List<PathCandidate> candidates, string path)
        {
            PathCandidate best = null;
            foreach (var c in candidates)
            {
                if (c.OldPath.Length == 0 || string.Equals(c.OldPath, c.NewPath, StringComparison.Ordinal)) continue;
                if (!HierarchyPathUtility.IsSameOrChildPath(path, c.OldPath)) continue;
                if (best == null || c.OldPath.Length > best.OldPath.Length) best = c;
            }
            return best;
        }

        static Dictionary<string, int> CountPaths(HierarchySnapshot snapshot)
        {
            var counts = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var e in snapshot.Entries)
            {
                counts.TryGetValue(e.Value, out int n);
                counts[e.Value] = n + 1;
            }
            return counts;
        }

        static int Depth(string path)
        {
            if (string.IsNullOrEmpty(path)) return 0;
            int depth = 1;
            foreach (char ch in path)
            {
                if (ch == '/') depth++;
            }
            return depth;
        }

        readonly struct Entry
        {
            public readonly int Id;
            public readonly string OldPath;
            public readonly string NewPath;
            readonly int _depth;

            public Entry(int id, string oldPath, string newPath)
            {
                Id = id;
                OldPath = oldPath;
                NewPath = newPath;
                _depth = Depth(oldPath);
            }

            public static int Compare(Entry a, Entry b)
            {
                int c = a._depth.CompareTo(b._depth);
                if (c != 0) return c;
                c = string.CompareOrdinal(a.OldPath, b.OldPath);
                if (c != 0) return c;
                return a.Id.CompareTo(b.Id);
            }
        }
    }
}
