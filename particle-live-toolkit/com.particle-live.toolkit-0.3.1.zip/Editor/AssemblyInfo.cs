using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ParticleLiveToolkit.Editor.Tests")]
