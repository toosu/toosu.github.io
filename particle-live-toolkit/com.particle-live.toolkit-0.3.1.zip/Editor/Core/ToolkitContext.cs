using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// モジュールに渡される共有コンテキスト。編集中のライブ(プロジェクト設定アセット)と BPM を保持する。
    ///
    /// プロジェクト未選択でも Bpm / NoteDivisions は使える(Beat Calculator などを設定なしで即使えるようにするため)。
    /// その場合の値は Unity を閉じるまで保持される一時値。
    /// </summary>
    public sealed class ToolkitContext
    {
        /// <summary>プロジェクト未選択時の BPM 一時値の SessionState キー。</summary>
        internal const string TemporaryBpmKey = "PLT.Core.TemporaryBpm";

        private const int DefaultBeatsPerBar = 4;

        private readonly Action _repaint;
        private readonly Action<string> _notify;
        private readonly Dictionary<string, ModuleState> _states = new Dictionary<string, ModuleState>(StringComparer.Ordinal);
        private ParticleLiveProject _project;

        /// <param name="repaint">ホストウィンドウの再描画。null 可(テスト用)。</param>
        /// <param name="notify">ホストウィンドウの通知表示。null 可(テスト用)。</param>
        public ToolkitContext(Action repaint = null, Action<string> notify = null)
        {
            _repaint = repaint;
            _notify = notify;
        }

        /// <summary>編集中のライブ。未選択なら null。</summary>
        public ParticleLiveProject ActiveProject
        {
            // アセットが削除された場合も null を返す(Unity の null 判定)。
            get { return _project != null ? _project : null; }
        }

        public bool HasProject
        {
            get { return _project != null; }
        }

        /// <summary>
        /// ActiveProject の切り替え、またはその値(BPM など)の変更で発火する。
        /// Undo / Redo でプロジェクトの値が変わった場合もホストが RaiseProjectChanged を呼ぶ。
        /// </summary>
        public event Action ProjectChanged;

        /// <summary>編集中のライブを切り替える。同じものなら何もしない。null 可。</summary>
        public void SetActiveProject(ParticleLiveProject project)
        {
            ParticleLiveProject next = project != null ? project : null;
            if (ReferenceEquals(ActiveProject, next))
            {
                _project = next;
                return;
            }
            _project = next;
            ParticleLiveToolkit.Modules.Quick.LiveAudition.Select(next);
            ProjectChanged?.Invoke();
        }

        /// <summary>現在の BPM。プロジェクトがあればその bpm、無ければ一時値(既定 128)。常に 0 より大きい。</summary>
        public double Bpm
        {
            get
            {
                ParticleLiveProject project = ActiveProject;
                double value = project != null ? project.bpm : ReadTemporaryBpm();
                return IsValidBpm(value) ? value : ParticleLiveProject.DefaultBpm;
            }
        }

        /// <summary>
        /// BPM を変更する。プロジェクトがあれば Undo 可能な形でアセットに書き、無ければ一時値を更新する。
        /// 0 以下・NaN・無限大は無視する。値が変わったら ProjectChanged を発火する。
        /// </summary>
        public void SetBpm(double bpm)
        {
            if (!IsValidBpm(bpm)) return;

            ParticleLiveProject project = ActiveProject;
            if (project != null)
            {
                if (project.bpm.Equals(bpm)) return;
                Undo.RecordObject(project, "BPM の変更");
                project.bpm = bpm;
                LiveSettings.Dirty(project);
            }
            else
            {
                if (ReadTemporaryBpm().Equals(bpm)) return;
                SessionState.SetString(TemporaryBpmKey, ModuleState.EncodeDouble(bpm));
            }
            ProjectChanged?.Invoke();
        }

        /// <summary>1 小節の拍数。プロジェクトが無ければ 4。常に 1 以上。</summary>
        public int BeatsPerBar
        {
            get
            {
                ParticleLiveProject project = ActiveProject;
                return project != null && project.beatsPerBar >= 1 ? project.beatsPerBar : DefaultBeatsPerBar;
            }
        }

        /// <summary>
        /// 並べる「N 分」の一覧。プロジェクトがあり noteDivisions が空でなければそれ、
        /// そうでなければ ParticleLiveProject.DefaultNoteDivisions。0 以下の要素は除く。
        /// </summary>
        public IReadOnlyList<int> NoteDivisions
        {
            get
            {
                ParticleLiveProject project = ActiveProject;
                if (project != null && project.noteDivisions != null)
                {
                    int[] fromProject = PositiveOnly(project.noteDivisions);
                    if (fromProject.Length > 0) return fromProject;
                }
                return PositiveOnly(ParticleLiveProject.DefaultNoteDivisions);
            }
        }

        /// <summary>
        /// ActiveProject のフィールドを書き換える「前」に呼ぶ(Undo.RecordObject)。プロジェクトが無ければ何もしない。
        /// </summary>
        public void RecordProjectEdit(string undoName)
        {
            ParticleLiveProject project = ActiveProject;
            if (project == null) return;
            Undo.RecordObject(project, string.IsNullOrEmpty(undoName) ? "ライブ設定の変更" : undoName);
        }

        /// <summary>
        /// ActiveProject のフィールドを書き換えた「後」に呼ぶ(SetDirty + ProjectChanged 発火)。
        /// </summary>
        public void NotifyProjectEdited()
        {
            ParticleLiveProject project = ActiveProject;
            if (project == null) return;
            LiveSettings.Dirty(project);
            ProjectChanged?.Invoke();
        }

        /// <summary>ProjectChanged を発火するだけ(Undo / Redo 時にホストが呼ぶ)。</summary>
        public void RaiseProjectChanged()
        {
            ProjectChanged?.Invoke();
        }

        /// <summary>ウィンドウ上に短い通知を出す(例: 「0.468750 をコピーしました」)。</summary>
        public void ShowNotification(string message)
        {
            _notify?.Invoke(message ?? "");
        }

        /// <summary>ホストウィンドウを再描画する。</summary>
        public void Repaint()
        {
            _repaint?.Invoke();
        }

        /// <summary>モジュールごとの UI 状態保存先。同じ moduleId には同じ保存領域が返る。</summary>
        public ModuleState State(string moduleId)
        {
            if (moduleId == null) throw new ArgumentNullException(nameof(moduleId));
            if (!_states.TryGetValue(moduleId, out ModuleState state))
            {
                state = new ModuleState(moduleId, () => ActiveProject);
                _states.Add(moduleId, state);
            }
            return state;
        }

        /// <summary>プロジェクト未選択時の一時値(BPM)を消して既定に戻す。テストの初期化用。</summary>
        internal static void ResetTemporaryValues()
        {
            SessionState.EraseString(TemporaryBpmKey);
        }

        private static double ReadTemporaryBpm()
        {
            string stored = SessionState.GetString(TemporaryBpmKey, "");
            if (ModuleState.TryDecodeDouble(stored, out double value) && IsValidBpm(value)) return value;
            return ParticleLiveProject.DefaultBpm;
        }

        private static bool IsValidBpm(double bpm)
        {
            return bpm > 0.0 && !double.IsInfinity(bpm);
        }

        private static int[] PositiveOnly(int[] source)
        {
            var list = new List<int>(source.Length);
            foreach (int value in source)
            {
                if (value > 0) list.Add(value);
            }
            return list.ToArray();
        }
    }

    /// <summary>
    /// 編集中のライブを Unity プロジェクト単位で記憶する(EditorUserSettings にアセットの GUID を保存)。
    /// メインウィンドウが OnEnable で Load、ProjectChanged で Save する。
    /// </summary>
    internal static class ActiveProjectMemory
    {
        internal const string ConfigKey = "ParticleLiveToolkit.ActiveProjectGuid";

        /// <summary>記憶しているライブを読み込む。未記憶・削除済み・読み込めない場合は null。</summary>
        internal static ParticleLiveProject Load()
        {
            string guid = EditorUserSettings.GetConfigValue(ConfigKey);
            if (string.IsNullOrEmpty(guid)) return null;
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(path)) return null;
            return AssetDatabase.LoadAssetAtPath<ParticleLiveProject>(path);
        }

        /// <summary>ライブを記憶する。null やアセットとして保存されていないものは「未選択」として記憶する。</summary>
        internal static void Save(ParticleLiveProject project)
        {
            string guid = "";
            if (project != null && AssetDatabase.TryGetGUIDAndLocalFileIdentifier(project, out string found, out long _))
            {
                guid = found ?? "";
            }
            string current = EditorUserSettings.GetConfigValue(ConfigKey) ?? "";
            if (current != guid)
            {
                EditorUserSettings.SetConfigValue(ConfigKey, guid);
            }
        }
    }

    /// <summary>
    /// モジュールの UI 状態を再コンパイルをまたいで保持する小さな保存領域(Unity を閉じると消える)。
    /// キーは内部で "PLT.{moduleId}.{key}" に名前空間化される。
    /// </summary>
    public sealed class ModuleState
    {
        private const string DoublePrefix = "d:";
        private const string MissingProbeA = "PLT.missing.A";
        private const string MissingProbeB = "PLT.missing.B";

        private readonly string _moduleId;
        private readonly string _keyPrefix;

        private readonly Func<ParticleLiveProject> owner;

        public ModuleState(string moduleId, Func<ParticleLiveProject> owner = null)
        {
            this.owner = owner;
            _moduleId = moduleId ?? throw new ArgumentNullException(nameof(moduleId));
            _keyPrefix = "PLT." + moduleId + ".";
        }

        public string ModuleId
        {
            get { return _moduleId; }
        }

        public bool GetBool(string key, bool defaultValue = false) => bool.TryParse(GetString(key, null), out bool v) ? v : defaultValue;
        public void SetBool(string key, bool value) => SetString(key, value.ToString());
        public int GetInt(string key, int defaultValue = 0) => int.TryParse(GetString(key, null), NumberStyles.Integer, CultureInfo.InvariantCulture, out int v) ? v : defaultValue;
        public void SetInt(string key, int value) => SetString(key, value.ToString(CultureInfo.InvariantCulture));
        public float GetFloat(string key, float defaultValue = 0f) => (float)GetDouble(key, defaultValue);
        public void SetFloat(string key, float value) => SetDouble(key, value);
        public double GetDouble(string key, double defaultValue = 0) => TryDecodeDouble(GetString(key, null), out double v) ? v : defaultValue;
        public void SetDouble(string key, double value) => SetString(key, EncodeDouble(value));

        public string GetString(string key, string defaultValue = "")
        {
            var project = owner?.Invoke();
            if (project && !SessionOnly(key)) return LiveSettings.Read(project, FullKey(key), defaultValue);
            string full = SessionKey(project, key);
            string stored = SessionState.GetString(full, MissingProbeA);
            if (stored != MissingProbeA) return stored;
            return SessionState.GetString(full, MissingProbeB) == MissingProbeB ? defaultValue : stored;
        }

        public void SetString(string key, string value)
        {
            var project = owner?.Invoke();
            if (project && !SessionOnly(key)) LiveSettings.Write(project, FullKey(key), value);
            else if (value == null) SessionState.EraseString(SessionKey(project, key));
            else SessionState.SetString(SessionKey(project, key), value);
        }

        bool SessionOnly(string key) => _moduleId == "pathfixer" && (key.StartsWith("baseline", StringComparison.Ordinal) || key == "applyRecord" || key == "manualRootId");
        string SessionKey(ParticleLiveProject project, string key) => project ? FullKey(key) + "." + project.GetInstanceID() : FullKey(key);

        /// <summary>SessionState 上の実際のキー("PLT.{moduleId}.{key}")。</summary>
        internal string FullKey(string key)
        {
            return _keyPrefix + (key ?? "");
        }

        /// <summary>double をビット列のまま文字列化する(-0.0 や NaN も含めて完全に往復する)。</summary>
        internal static string EncodeDouble(double value)
        {
            return DoublePrefix + BitConverter.DoubleToInt64Bits(value).ToString(CultureInfo.InvariantCulture);
        }

        internal static bool TryDecodeDouble(string stored, out double value)
        {
            value = 0.0;
            if (string.IsNullOrEmpty(stored) || !stored.StartsWith(DoublePrefix, StringComparison.Ordinal)) return false;
            if (!long.TryParse(stored.Substring(DoublePrefix.Length), NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out long bits)) return false;
            value = BitConverter.Int64BitsToDouble(bits);
            return true;
        }
    }
}
