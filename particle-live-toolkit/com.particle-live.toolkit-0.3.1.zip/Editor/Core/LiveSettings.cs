using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Core
{
    [Serializable]
    internal sealed class SavedReference<T> where T : Object
    {
        [SerializeField] string id;
        [NonSerialized] T cached;
        public T Value
        {
            get
            {
                if (!cached && !string.IsNullOrEmpty(id)) cached = LiveSettings.Resolve<T>(id);
                return cached;
            }
            set
            {
                if (value == Value) return;
                cached = value;
                id = LiveSettings.Identifier(value);
            }
        }
    }

    internal sealed class LiveForm<T> where T : class, new()
    {
        ParticleLiveProject owner;
        T values;
        internal void Reload() { values = null; }
        internal void Draw(ToolkitContext ctx, string module, Action<T> draw)
        {
            var state = ctx.State(module);
            if (values == null || owner != ctx.ActiveProject)
            {
                owner = ctx.ActiveProject;
                values = new T();
                string json = state.GetString("form");
                if (!string.IsNullOrEmpty(json)) JsonUtility.FromJsonOverwrite(json, values);
            }
            EditorGUI.BeginChangeCheck();
            try { draw(values); }
            finally { if (EditorGUI.EndChangeCheck()) state.SetString("form", JsonUtility.ToJson(values)); }
        }
    }

    [InitializeOnLoad]
    internal static class LiveSettings
    {
        static readonly HashSet<ParticleLiveProject> pending = new HashSet<ParticleLiveProject>();
        static double due;
        static LiveSettings()
        {
            EditorApplication.update += () => { if (pending.Count > 0 && EditorApplication.timeSinceStartup >= due) Flush(); };
            EditorApplication.quitting += Flush;
            AssemblyReloadEvents.beforeAssemblyReload += Flush;
        }

        internal static string Identifier(Object value) => value ? GlobalObjectId.GetGlobalObjectIdSlow(value).ToString() : "";
        internal static T Resolve<T>(string value) where T : Object =>
            GlobalObjectId.TryParse(value, out var id) ? GlobalObjectId.GlobalObjectIdentifierToObjectSlow(id) as T : null;

        internal static string Read(ParticleLiveProject p, string key, string fallback = "") =>
            p.editorSettings?.Find(item => item != null && item.key == key)?.value ?? fallback;

        internal static void Write(ParticleLiveProject p, string key, string value)
        {
            if (Read(p, key, null) == value) return;
            if (p.editorSettings == null) p.editorSettings = new List<ParticleLiveProject.EditorSetting>();
            var item = p.editorSettings.Find(entry => entry != null && entry.key == key);
            if (value == null) p.editorSettings.Remove(item);
            else if (item != null) item.value = value;
            else p.editorSettings.Add(new ParticleLiveProject.EditorSetting { key = key, value = value });
            Dirty(p);
        }

        internal static void Dirty(ParticleLiveProject p)
        {
            EditorUtility.SetDirty(p);
            if (!EditorUtility.IsPersistent(p)) return;
            if (pending.Count == 0) due = EditorApplication.timeSinceStartup + 1;
            pending.Add(p);
        }

        internal static void Flush()
        {
            foreach (var p in pending) if (p) AssetDatabase.SaveAssetIfDirty(p);
            pending.Clear();
        }
    }
}
