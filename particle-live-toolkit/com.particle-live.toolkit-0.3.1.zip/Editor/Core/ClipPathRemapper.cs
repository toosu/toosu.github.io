using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>「旧パス → 新パス」の 1 件。子孫のパスも接頭辞としてまとめて書き換える。</summary>
    public readonly struct PathRemap
    {
        public readonly string OldPath;
        public readonly string NewPath;

        public PathRemap(string oldPath, string newPath)
        {
            OldPath = oldPath ?? "";
            NewPath = newPath ?? "";
        }
    }

    /// <summary>書き換え対象のバインディング 1 件。</summary>
    public sealed class PathRemapChange
    {
        public EditorCurveBinding OldBinding;
        public string NewPath;
        public bool IsObjectReference;
    }

    /// <summary>1 クリップぶんの書き換え計画(プレビュー用。作っただけではクリップは変わらない)。</summary>
    public sealed class PathRemapPlan
    {
        public AnimationClip Clip;

        /// <summary>パスが変わるバインディング。</summary>
        public List<PathRemapChange> Changes = new List<PathRemapChange>();

        /// <summary>衝突の説明(1 件 1 行、日本語)。書き換え後に同じ (パス, 型, プロパティ名) が 2 つ以上になる場合。</summary>
        public List<string> Conflicts = new List<string>();

        /// <summary>クリップが書き換え不可のときの理由(ClipEditUtility.IsEditable の reason)。可なら null。</summary>
        public string BlockReason;

        /// <summary>Changes が 1 件以上あり、Conflicts が空で、BlockReason が null。</summary>
        public bool CanApply
        {
            get { return Changes.Count > 0 && Conflicts.Count == 0 && BlockReason == null; }
        }
    }

    /// <summary>AnimationClip のバインディングパスの書き換え。</summary>
    public static class ClipPathRemapper
    {
        /// <summary>
        /// path に remaps を適用した結果を返す(純粋関数)。
        ///  - HierarchyPathUtility.IsSameOrChildPath(path, OldPath) が true の remap のうち、OldPath が最も長いものを 1 つだけ適用する。
        ///  - どれにも一致しなければ path をそのまま返す。
        ///  - 全パスを「元のパス」から同時に計算するので、A→B と B→A の入れ替えや A→B, B→C の連鎖も正しく扱える。
        ///  - OldPath == NewPath の remap は無視する。OldPath が "" の remap は無視する(ルート自身は書き換え対象外)。
        /// </summary>
        public static string RemapPath(string path, IReadOnlyList<PathRemap> remaps)
        {
            if (path == null || remaps == null) return path;
            int best = -1;
            int bestLength = -1;
            for (int i = 0; i < remaps.Count; i++)
            {
                var r = remaps[i];
                if (string.IsNullOrEmpty(r.OldPath)) continue;     // ルート自身は書き換え対象外(default(PathRemap) は null)
                if (string.Equals(r.OldPath, r.NewPath ?? "", StringComparison.Ordinal)) continue;
                if (!HierarchyPathUtility.IsSameOrChildPath(path, r.OldPath)) continue;
                if (r.OldPath.Length > bestLength)                 // 同じ長さなら先に来たものを優先
                {
                    best = i;
                    bestLength = r.OldPath.Length;
                }
            }
            if (best < 0) return path;
            return HierarchyPathUtility.ReplacePrefix(path, remaps[best].OldPath, remaps[best].NewPath);
        }

        /// <summary>
        /// clip に remaps を適用した場合の計画を作る。クリップは変更しない。
        /// 衝突判定は、書き換え後の全バインディング(変わらないものを含む)の中での重複で行う。
        /// </summary>
        public static PathRemapPlan Plan(AnimationClip clip, IReadOnlyList<PathRemap> remaps)
        {
            var plan = new PathRemapPlan { Clip = clip };
            if (!ClipEditUtility.IsEditable(clip, out string reason)) plan.BlockReason = reason;
            if (clip == null) return plan;

            // 書き換え後の (パス, 型, プロパティ名) ごとに、元のバインディングを集める(変わらないものも含む)
            var groups = new Dictionary<(string path, Type type, string prop), List<EditorCurveBinding>>();
            var order = new List<(string path, Type type, string prop)>();
            foreach (var c in ClipEditUtility.GetAllCurves(clip))
            {
                var b = c.Binding;
                string newPath = RemapPath(b.path, remaps);
                if (!string.Equals(newPath, b.path, StringComparison.Ordinal))
                    plan.Changes.Add(new PathRemapChange { OldBinding = b, NewPath = newPath, IsObjectReference = c.IsObjectReference });

                var key = (newPath, b.type, b.propertyName);
                if (!groups.TryGetValue(key, out var list))
                {
                    list = new List<EditorCurveBinding>();
                    groups.Add(key, list);
                    order.Add(key);
                }
                list.Add(b);
            }

            foreach (var key in order)
            {
                var list = groups[key];
                if (list.Count < 2) continue;
                var sources = new List<string>();
                foreach (var b in list) sources.Add(DisplayPath(b.path));
                string typeName = key.type != null ? key.type.Name : "?";
                plan.Conflicts.Add($"{DisplayPath(key.path)} の {typeName}.{key.prop} が重複します(元のパス: {string.Join(", ", sources)})");
            }
            return plan;
        }

        static string DisplayPath(string path)
        {
            return string.IsNullOrEmpty(path) ? "(ルート)" : path;
        }

        /// <summary>
        /// 計画を適用する(ClipEditSession 経由。バックアップと Undo 込み)。カーブの中身(キー・接線)は一切変えない。
        /// 戻り値は書き換えたバインディング数。
        /// </summary>
        /// <exception cref="InvalidOperationException">plan.CanApply が false。</exception>
        public static int Apply(PathRemapPlan plan, string undoName)
        {
            if (plan == null) throw new ArgumentNullException(nameof(plan));
            if (!plan.CanApply) throw new InvalidOperationException("この計画は適用できません(変更なし、衝突あり、または書き換え不可のクリップ)。");

            var session = new ClipEditSession(plan.Clip);

            // 1. 書き換える前に全カーブの中身を読む(入れ替え A↔B や連鎖 A→B, B→C で、
            //    先に書いた結果を後で読んでしまわないようにする)
            int n = plan.Changes.Count;
            var floatData = new AnimationCurve[n];
            var objectData = new ObjectReferenceKeyframe[n][];
            for (int i = 0; i < n; i++)
            {
                var ch = plan.Changes[i];
                if (ch.IsObjectReference) objectData[i] = session.GetObjectCurve(ch.OldBinding);
                else floatData[i] = session.GetFloatCurve(ch.OldBinding);
                if (floatData[i] == null && objectData[i] == null)
                    throw new InvalidOperationException("計画の作成後にクリップが変更されています。もう一度プレビューしてください: " + ch.OldBinding.path);
            }

            // 2. 旧バインディングをすべて削除登録してから、3. 新しいパスへ同じ中身を登録する
            //    (旧と新が同じバインディングになる場合は 3 の登録が勝つ)
            for (int i = 0; i < n; i++)
            {
                var ch = plan.Changes[i];
                if (ch.IsObjectReference) session.SetObjectCurve(ch.OldBinding, null);
                else session.SetFloatCurve(ch.OldBinding, null);
            }
            for (int i = 0; i < n; i++)
            {
                var ch = plan.Changes[i];
                var nb = ch.OldBinding; // 構造体コピー: 型・プロパティ名・PPtr かどうかはそのまま
                nb.path = ch.NewPath;
                if (ch.IsObjectReference) session.SetObjectCurve(nb, objectData[i]);
                else session.SetFloatCurve(nb, floatData[i]);
            }

            session.Commit(undoName);
            return n;
        }

        /// <summary>
        /// clip のバインディングパスのうち、root からの相対パスとして解決できないもの(重複なし、Ordinal 昇順)。
        /// "" (ルート自身)は常に解決できるものとして扱う。
        /// </summary>
        public static IReadOnlyList<string> FindMissingPaths(AnimationClip clip, Transform root)
        {
            var missing = new List<string>();
            if (clip == null) return missing;
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var c in ClipEditUtility.GetAllCurves(clip))
            {
                string path = c.Binding.path ?? "";
                if (path.Length == 0 || !seen.Add(path)) continue;
                // root が null のときは何も解決できないので、"" 以外はすべてリンク切れ扱い
                if (HierarchyPathUtility.Resolve(root, path) == null) missing.Add(path);
            }
            missing.Sort(StringComparer.Ordinal);
            return missing;
        }
    }
}
