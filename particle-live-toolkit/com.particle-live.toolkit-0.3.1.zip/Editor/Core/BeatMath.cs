using System;
using System.Globalization;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// BPM と時間の変換(純粋関数)。
    /// 「N 分」の秒数 = 全音符(4 拍)の長さ / N = 240 / BPM / N。
    /// 例: BPM 128 の 4 分 = 0.46875 秒、12 分(3 連 8 分)= 0.15625 秒。
    /// </summary>
    public static class BeatMath
    {
        /// <summary>「division 分」音符 1 つの秒数。bpm と division は 0 より大きいこと。</summary>
        public static double NoteSeconds(double bpm, int division)
        {
            RequirePositive(bpm, nameof(bpm));
            if (division <= 0) throw new ArgumentOutOfRangeException(nameof(division));
            return 240.0 / bpm / division;
        }

        /// <summary>「division 分」音符 multiplier 個ぶんの秒数。</summary>
        public static double NoteSeconds(double bpm, int division, double multiplier)
        {
            return NoteSeconds(bpm, division) * multiplier;
        }

        /// <summary>1 拍(4 分音符)の秒数。</summary>
        public static double BeatSeconds(double bpm)
        {
            RequirePositive(bpm, nameof(bpm));
            return 60.0 / bpm;
        }

        /// <summary>1 小節の秒数。</summary>
        public static double BarSeconds(double bpm, int beatsPerBar)
        {
            if (beatsPerBar <= 0) throw new ArgumentOutOfRangeException(nameof(beatsPerBar));
            return BeatSeconds(bpm) * beatsPerBar;
        }

        /// <summary>秒数をフレーム数に換算する(丸めない)。</summary>
        public static double SecondsToFrames(double seconds, double frameRate)
        {
            RequirePositive(frameRate, nameof(frameRate));
            return seconds * frameRate;
        }

        /// <summary>
        /// time を、offsetSeconds を起点とする「division 分」のグリッドの最も近い位置に寄せる。
        /// ちょうど中間のときは後ろ(大きい方)へ寄せる。
        /// </summary>
        public static double SnapToGrid(double time, double bpm, int division, double offsetSeconds)
        {
            double step = NoteSeconds(bpm, division);
            double index = Math.Floor((time - offsetSeconds) / step + 0.5);
            return offsetSeconds + index * step;
        }

        /// <summary>
        /// 秒数を小数 decimals 桁の固定小数表記にする(コピー用)。
        /// 丸めは四捨五入(ちょうど中間は 0 から遠い方へ)。カルチャに依存せず小数点は常に "."。
        /// 例: 0.1171875 → "0.117188"、0.0390625 → "0.039063"。
        /// NaN・無限大・絶対値が 1e15 を超える値は表記できないので、例外を投げず "-" を返す
        /// (入力途中の極端な値で画面を止めないため)。
        /// </summary>
        public static string FormatSeconds(double seconds, int decimals = 6)
        {
            if (decimals < 0 || decimals > 15) throw new ArgumentOutOfRangeException(nameof(decimals));
            if (double.IsNaN(seconds) || double.IsInfinity(seconds) || Math.Abs(seconds) > 1e15) return "-";
            decimal rounded = Math.Round((decimal)seconds, decimals, MidpointRounding.AwayFromZero);
            return rounded.ToString("F" + decimals.ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);
        }

        private static void RequirePositive(double value, string name)
        {
            if (!(value > 0.0) || double.IsInfinity(value)) throw new ArgumentOutOfRangeException(name);
        }
    }
}
