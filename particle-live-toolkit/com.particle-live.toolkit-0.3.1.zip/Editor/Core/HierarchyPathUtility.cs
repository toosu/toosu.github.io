using System;
using System.Collections.Generic;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// AnimationClip のバインディングパス("A/B/C"、ルート自身は "")の操作(純粋関数中心)。
    /// パスの比較・置換はすべて「/」区切りのセグメント単位で行う("Effects/Fire" は "Effects/Fire2" の接頭辞ではない)。
    /// </summary>
    public static class HierarchyPathUtility
    {
        /// <summary>
        /// root から target への相対パス。target == root なら ""。target が root の子孫でなければ null。
        /// どちらかが null なら null。
        /// </summary>
        public static string GetRelativePath(Transform root, Transform target)
        {
            if (root == null || target == null) return null;
            if (target == root) return "";

            var names = new List<string>();
            for (var t = target; t != null; t = t.parent)
            {
                if (t == root)
                {
                    names.Reverse();
                    return string.Join("/", names);
                }
                names.Add(t.name);
            }
            return null; // root に到達しなかった = 子孫ではない
        }

        /// <summary>
        /// root からの相対パスで Transform を探す(非アクティブ含む。Transform.Find と同じ規則)。
        /// path が "" なら root。見つからなければ null。path が null なら null。
        /// </summary>
        public static Transform Resolve(Transform root, string path)
        {
            if (root == null || path == null) return null;
            if (path.Length == 0) return root;
            return root.Find(path);
        }

        /// <summary>親パスと子の名前(または相対パス)を連結する。どちらかが "" ならもう片方をそのまま返す。</summary>
        public static string Combine(string parentPath, string child)
        {
            if (string.IsNullOrEmpty(parentPath)) return child ?? "";
            if (string.IsNullOrEmpty(child)) return parentPath;
            return parentPath + "/" + child;
        }

        /// <summary>
        /// path が prefix と同じ、または prefix の子孫パスなら true(セグメント単位)。
        /// prefix が "" のときは常に true。
        /// </summary>
        public static bool IsSameOrChildPath(string path, string prefix)
        {
            if (string.IsNullOrEmpty(prefix)) return true;
            if (path == null || path.Length < prefix.Length) return false;
            if (!path.StartsWith(prefix, StringComparison.Ordinal)) return false;
            // 一致した直後がパスの終わりか「/」のときだけ(セグメント境界)
            return path.Length == prefix.Length || path[prefix.Length] == '/';
        }

        /// <summary>
        /// path の先頭の oldPrefix を newPrefix に置き換える(セグメント単位)。
        /// IsSameOrChildPath(path, oldPrefix) が false なら path をそのまま返す。
        /// 例: ("Effects/P01/Sub", "Effects/P01", "Effects/Drop/Fire") → "Effects/Drop/Fire/Sub"
        /// </summary>
        public static string ReplacePrefix(string path, string oldPrefix, string newPrefix)
        {
            if (!IsSameOrChildPath(path, oldPrefix)) return path;
            string oldP = oldPrefix ?? "";
            // 残り: oldPrefix が "" ならパス全体、それ以外は "" か "/..." から先頭の "/" を除いたもの
            string rest = oldP.Length == 0 ? path : (path.Length == oldP.Length ? "" : path.Substring(oldP.Length + 1));
            return Combine(newPrefix ?? "", rest);
        }
    }
}
