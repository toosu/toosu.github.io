using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// 「N 分 × 倍率」または秒数直指定で表す時間間隔。Beat Calculator と同じ計算を他のモジュールが再利用するための値型。
    /// </summary>
    [Serializable]
    public struct BeatInterval
    {
        private const string CustomKey = ".custom";
        private const string DivisionKey = ".division";
        private const string MultiplierKey = ".multiplier";
        private const string SecondsKey = ".seconds";

        /// <summary>true なら customSeconds をそのまま使う。</summary>
        public bool useCustomSeconds;
        public bool beatMode;

        /// <summary>「N 分」の N。</summary>
        public int division;

        /// <summary>N 分音符いくつぶんか。</summary>
        public double multiplier;

        public double customSeconds;

        /// <summary>既定値: 4 分 × 1。</summary>
        public static BeatInterval Default
        {
            get { return new BeatInterval { useCustomSeconds = false, division = 4, multiplier = 1.0, customSeconds = 0.5 }; }
        }

        /// <summary>
        /// 秒数に換算する。useCustomSeconds なら customSeconds、そうでなければ BeatMath.NoteSeconds(bpm, division, multiplier)。
        /// 値が不正(division &lt;= 0、bpm &lt;= 0 など)の場合は例外を投げず 0 を返す。
        /// </summary>
        public double ToSeconds(double bpm)
        {
            double seconds;
            if (useCustomSeconds)
            {
                // 秒数直指定では BPM を使わないので、BPM の値は問わない。
                seconds = customSeconds;
            }
            else
            {
                bool valid = division > 0
                    && bpm > 0.0 && !double.IsInfinity(bpm)
                    && multiplier >= 0.0 && !double.IsInfinity(multiplier);
                if (!valid) return 0.0;
                seconds = BeatMath.NoteSeconds(bpm, division, multiplier);
            }
            return seconds >= 0.0 && !double.IsInfinity(seconds) ? seconds : 0.0;
        }

        /// <summary>ModuleState に保存する("{keyPrefix}.custom" などのキーを使う)。</summary>
        public void Save(ModuleState state, string keyPrefix)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            string prefix = keyPrefix ?? "";
            state.SetBool(prefix + ".beatMode", beatMode);
            state.SetBool(prefix + CustomKey, useCustomSeconds);
            state.SetInt(prefix + DivisionKey, division);
            state.SetDouble(prefix + MultiplierKey, multiplier);
            state.SetDouble(prefix + SecondsKey, customSeconds);
        }

        /// <summary>ModuleState から復元する。保存が無ければ fallback を返す。</summary>
        public static BeatInterval Load(ModuleState state, string keyPrefix, BeatInterval fallback)
        {
            if (state == null) throw new ArgumentNullException(nameof(state));
            string prefix = keyPrefix ?? "";
            // 各項目の既定値を fallback にすることで、保存が無ければ fallback そのものになる。
            return new BeatInterval
            {
                beatMode = state.GetBool(prefix + ".beatMode", false),
                useCustomSeconds = state.GetBool(prefix + CustomKey, fallback.useCustomSeconds),
                division = state.GetInt(prefix + DivisionKey, fallback.division),
                multiplier = state.GetDouble(prefix + MultiplierKey, fallback.multiplier),
                customSeconds = state.GetDouble(prefix + SecondsKey, fallback.customSeconds),
            };
        }

        /// <summary>Save が使うキーの一覧(テストの後片付け用)。</summary>
        internal static IEnumerable<string> StateKeys(string keyPrefix)
        {
            string prefix = keyPrefix ?? "";
            return new[] { prefix + CustomKey, prefix + DivisionKey, prefix + MultiplierKey, prefix + SecondsKey };
        }
    }

    /// <summary>BeatInterval の IMGUI 入力欄。</summary>
    public static class BeatIntervalGUI
    {
        private static readonly string[] ModeLabels = { "音符", "秒数", "ビート" };

        /// <summary>
        /// 1〜2 行の入力欄を EditorGUILayout で描く:「音符 / 秒数」の切替、N 分の選択(ctx.NoteDivisions から)、倍率、
        /// または秒数。右端に現在の BPM での換算結果(BeatMath.FormatSeconds)を常に表示する。
        /// 変更後の値を返す(変更が無ければ同じ値)。
        /// </summary>
        public static BeatInterval Field(string label, BeatInterval value, ToolkitContext ctx)
        {
            double bpm = ctx != null ? ctx.Bpm : ParticleLiveProject.DefaultBpm;
            IReadOnlyList<int> divisions = ctx != null ? ctx.NoteDivisions : ParticleLiveProject.DefaultNoteDivisions;
            BeatInterval result = value;

            using (new EditorGUILayout.HorizontalScope())
            {
                if (!string.IsNullOrEmpty(label))
                {
                    EditorGUILayout.PrefixLabel(label);
                }

                int mode = EditorGUILayout.Popup(value.useCustomSeconds ? 1 : value.beatMode ? 2 : 0, ModeLabels, GUILayout.Width(68));
                result.beatMode = mode == 2;
                if (result.beatMode) result.division = 4;
                result.useCustomSeconds = mode == 1;

                if (!result.useCustomSeconds)
                {
                    BuildDivisionOptions(divisions, result.division, out int[] values, out string[] labels);
                    int index = Array.IndexOf(values, result.division);
                    int picked = result.beatMode ? index : EditorGUILayout.Popup(index, labels, GUILayout.Width(64));
                    if (picked != index && picked >= 0 && picked < values.Length)
                    {
                        result.division = values[picked];
                    }

                    GUILayout.Label("×", GUILayout.Width(12));
                    EditorGUI.BeginChangeCheck();
                    double multiplier = EditorGUILayout.DoubleField(result.multiplier, GUILayout.Width(48));
                    if (EditorGUI.EndChangeCheck())
                    {
                        result.multiplier = multiplier >= 0.0 && !double.IsInfinity(multiplier) ? multiplier : 0.0;
                    }
                }
                else
                {
                    EditorGUI.BeginChangeCheck();
                    double seconds = EditorGUILayout.DoubleField(result.customSeconds, GUILayout.Width(72));
                    if (EditorGUI.EndChangeCheck())
                    {
                        result.customSeconds = seconds >= 0.0 && !double.IsInfinity(seconds) ? seconds : 0.0;
                    }
                    GUILayout.Label("秒", GUILayout.Width(16));
                }

                GUILayout.FlexibleSpace();
                GUILayout.Label("= " + BeatMath.FormatSeconds(result.ToSeconds(bpm)) + " 秒", GUILayout.ExpandWidth(false));
            }
            return result;
        }

        /// <summary>選択肢を作る。今の division が一覧に無い(かつ正の値)なら末尾に足して、表示だけで値が変わらないようにする。</summary>
        private static void BuildDivisionOptions(IReadOnlyList<int> divisions, int current, out int[] values, out string[] labels)
        {
            var list = new List<int>();
            if (divisions != null)
            {
                foreach (int d in divisions)
                {
                    if (d > 0 && !list.Contains(d)) list.Add(d);
                }
            }
            foreach (int extra in new[] { 2, 3, 6 }) if (!list.Contains(extra)) list.Add(extra);
            if (current > 0 && !list.Contains(current)) list.Add(current);

            values = list.ToArray();
            labels = new string[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                labels[i] = values[i] + "分";
            }
        }
    }
}
