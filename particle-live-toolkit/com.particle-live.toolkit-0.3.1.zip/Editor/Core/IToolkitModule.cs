using System;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// ツールキットのモジュール契約。このインターフェースを実装した public クラス(引数なしコンストラクタ)を
    /// 1 つ足すだけで、メインウィンドウのサイドバーに並ぶ。既存コードの変更は不要。
    ///
    /// ライフサイクル:
    ///  - OnEnable : このモジュールのタブが選択されたとき(ウィンドウを開いた直後の初期選択を含む)。
    ///  - OnGUI    : 選択中のあいだ毎フレーム(IMGUI)。
    ///  - OnDisable: 別のタブへ切り替えたとき / ウィンドウを閉じたとき / 再コンパイル直前。
    ///    OnEnable と必ず対になる。プレビューや AnimationMode はここで必ず止める。
    ///
    /// インスタンスは再コンパイル(ドメインリロード)で作り直される。残したい UI 状態は
    /// ToolkitContext.State(Id) に保存する。
    /// モジュール同士は直接参照しない。共有は ParticleLiveToolkit.Core 経由のみ。
    /// </summary>
    public interface IToolkitModule
    {
        /// <summary>一意な ID(英小文字)。例: "beat"</summary>
        string Id { get; }

        /// <summary>サイドバーの表示名。</summary>
        string DisplayName { get; }

        /// <summary>並び順。小さいほど上。同値なら Id の昇順。</summary>
        int Order { get; }

        void OnEnable(ToolkitContext ctx);

        void OnDisable();

        void OnGUI(ToolkitContext ctx);
    }

    /// <summary>
    /// 付けたモジュールはメインウィンドウの一覧に出さない(テスト用ダミーなど)。
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    public sealed class HideToolkitModuleAttribute : Attribute
    {
    }

    /// <summary>v1 の 6 モジュールの Id と Order。新しいモジュールは 100 以降を使う。</summary>
    public static class ToolkitModuleIds
    {
        public const string Project = "project";
        public const string PathFixer = "pathfixer";
        public const string Beat = "beat";
        public const string AnimationRepeat = "animation";
        public const string Transform = "transform";
        public const string Preview = "preview";

        public const int ProjectOrder = 10;
        public const int PathFixerOrder = 20;
        public const int BeatOrder = 30;
        public const int AnimationRepeatOrder = 40;
        public const int TransformOrder = 50;
        public const int PreviewOrder = 60;
    }
}
