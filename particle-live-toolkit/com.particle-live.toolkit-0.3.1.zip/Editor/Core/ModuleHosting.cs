using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>IToolkitModule 実装の自動検出。</summary>
    public static class ModuleRegistry
    {
        /// <summary>
        /// TypeCache で IToolkitModule を実装した具象クラス(public な引数なしコンストラクタあり)を集めて生成し、
        /// Order 昇順 → Id 昇順(Ordinal)で返す。
        ///  - [HideToolkitModule] 付きは includeHidden が true のときだけ含める。
        ///  - 生成で例外を投げたクラス、Id が null / 空のモジュール、Id が重複した 2 つ目以降は除外し、
        ///    problems が非 null なら理由を 1 件 1 行で追加する。例外は外へ出さない。
        /// </summary>
        public static IReadOnlyList<IToolkitModule> CreateModules(bool includeHidden = false, List<string> problems = null)
        {
            var candidates = new List<Candidate>();
            try
            {
                foreach (Type type in TypeCache.GetTypesDerivedFrom<IToolkitModule>())
                {
                    Candidate candidate = TryCreate(type, includeHidden, problems);
                    if (candidate != null) candidates.Add(candidate);
                }
            }
            catch (Exception e)
            {
                problems?.Add("モジュールの検出中にエラーが発生しました: " + OneLine(e));
            }

            // 同じ Id のうちどれを残すかが実行ごとに変わらないよう、最後に型名でも並べる。
            candidates.Sort((a, b) =>
            {
                int c = a.Order.CompareTo(b.Order);
                if (c != 0) return c;
                c = string.CompareOrdinal(a.Id, b.Id);
                if (c != 0) return c;
                return string.CompareOrdinal(a.Type.FullName, b.Type.FullName);
            });

            var result = new List<IToolkitModule>(candidates.Count);
            var firstById = new Dictionary<string, Type>(StringComparer.Ordinal);
            foreach (Candidate c in candidates)
            {
                if (firstById.TryGetValue(c.Id, out Type first))
                {
                    problems?.Add(c.Type.FullName + ": Id \"" + c.Id + "\" が " + first.FullName + " と重複しているため除外しました");
                    continue;
                }
                firstById.Add(c.Id, c.Type);
                result.Add(c.Module);
            }
            return result.AsReadOnly();
        }

        private static Candidate TryCreate(Type type, bool includeHidden, List<string> problems)
        {
            if (type == null || !type.IsClass || type.IsAbstract || type.ContainsGenericParameters) return null;
            if (type.GetConstructor(Type.EmptyTypes) == null) return null;
            // 隠しモジュールは生成前に除外する(テスト用の壊れたダミーが本番の一覧に問題として出ないように)。
            if (!includeHidden && type.IsDefined(typeof(HideToolkitModuleAttribute), false)) return null;

            IToolkitModule module;
            try
            {
                module = (IToolkitModule)Activator.CreateInstance(type);
            }
            catch (Exception e)
            {
                problems?.Add(type.FullName + ": 生成時に例外が発生したため除外しました(" + OneLine(e) + ")");
                return null;
            }

            string id;
            int order;
            try
            {
                id = module.Id;
                order = module.Order;
            }
            catch (Exception e)
            {
                problems?.Add(type.FullName + ": Id または Order の取得で例外が発生したため除外しました(" + OneLine(e) + ")");
                return null;
            }

            if (string.IsNullOrEmpty(id))
            {
                problems?.Add(type.FullName + ": Id が空のため除外しました");
                return null;
            }
            return new Candidate(module, type, id, order);
        }

        private static string OneLine(Exception e)
        {
            while (e is TargetInvocationException && e.InnerException != null)
            {
                e = e.InnerException;
            }
            string message = e.GetType().Name + ": " + e.Message;
            return message.Replace("\r", " ").Replace("\n", " ");
        }

        private sealed class Candidate
        {
            public readonly IToolkitModule Module;
            public readonly Type Type;
            public readonly string Id;
            public readonly int Order;

            public Candidate(IToolkitModule module, Type type, string id, int order)
            {
                Module = module;
                Type = type;
                Id = id;
                Order = order;
            }
        }
    }

    /// <summary>モジュール呼び出しの例外隔離。</summary>
    public static class ModuleRunner
    {
        /// <summary>
        /// action を実行する。例外が出たら error に入れて false を返す(ログは出さない。表示は呼び出し側)。
        /// UnityEngine.ExitGUIException だけは握りつぶさずそのまま再スローする(IMGUI の正常な制御フロー)。
        /// </summary>
        public static bool TryInvoke(Action action, out Exception error)
        {
            if (action == null)
            {
                error = new ArgumentNullException(nameof(action));
                return false;
            }
            try
            {
                action();
                error = null;
                return true;
            }
            catch (ExitGUIException)
            {
                throw;
            }
            catch (Exception e)
            {
                error = e;
                return false;
            }
        }
    }

    /// <summary>
    /// モジュールの選択とライフサイクル管理(UI なし。メインウィンドウはこれを描画するだけ)。
    /// 1 つのモジュールが例外を投げても他のモジュールは使い続けられる。
    /// </summary>
    public sealed class ModuleHost
    {
        private readonly ReadOnlyCollection<IToolkitModule> _modules;
        private readonly ToolkitContext _context;
        private readonly Dictionary<string, Exception> _errors = new Dictionary<string, Exception>(StringComparer.Ordinal);
        private IToolkitModule _selected;
        // 選択中モジュールの OnEnable を呼んでから、対になる OnDisable をまだ呼んでいないあいだ true。
        private bool _selectedActive;

        public ModuleHost(IReadOnlyList<IToolkitModule> modules, ToolkitContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            var list = new List<IToolkitModule>();
            if (modules != null)
            {
                foreach (IToolkitModule module in modules)
                {
                    if (module != null) list.Add(module);
                }
            }
            _modules = list.AsReadOnly();
        }

        public IReadOnlyList<IToolkitModule> Modules
        {
            get { return _modules; }
        }

        public ToolkitContext Context
        {
            get { return _context; }
        }

        /// <summary>選択中のモジュール。未選択なら null。</summary>
        public IToolkitModule Selected
        {
            get { return _selected; }
        }

        /// <summary>
        /// id のモジュールを選択する。見つからなければ false を返して何も変えない。
        /// 既に選択中なら何もせず true。切り替え時は 旧.OnDisable → 新.OnEnable の順に、それぞれ例外隔離して呼ぶ。
        /// OnEnable が例外を投げてもそのモジュールは選択状態になり、エラーは GetError で取得できる。
        /// </summary>
        public bool Select(string id)
        {
            IToolkitModule target = Find(id);
            if (target == null) return false;
            if (ReferenceEquals(target, _selected)) return true;

            DisableSelected();

            _selected = target;
            _errors.Remove(id);
            _selectedActive = true;
            Invoke(target, () => target.OnEnable(_context));
            return true;
        }

        /// <summary>選択中モジュールの OnGUI を例外隔離して呼ぶ。未選択なら何もしない。</summary>
        public void DrawSelected()
        {
            IToolkitModule module = _selected;
            if (module == null) return;
            if (Invoke(module, () => module.OnGUI(_context))) return;

            // 描画中に例外が出たモジュールは、その場で止める(プレビューや AnimationMode を動かしたままにしない)。
            // 選択状態とエラーは残し、ウィンドウの「再読み込み」で OnEnable からやり直す。
            if (_selectedActive)
            {
                _selectedActive = false;
                string id = SafeId(module);
                Exception guiError = GetError(id);
                Invoke(module, module.OnDisable);
                if (id != null && guiError != null) _errors[id] = guiError; // 最初の原因(OnGUI の例外)を表示に残す
            }
        }

        /// <summary>そのモジュールで直近に起きた例外。無ければ null。Select し直すとクリアされる。</summary>
        public Exception GetError(string id)
        {
            if (id == null) return null;
            return _errors.TryGetValue(id, out Exception error) ? error : null;
        }

        /// <summary>選択中モジュールの OnDisable を例外隔離して呼び、未選択状態にする。何度呼んでも安全。</summary>
        public void Shutdown()
        {
            DisableSelected();
        }

        /// <summary>選択を外し、OnEnable 済みで OnDisable がまだなら 1 回だけ呼ぶ。</summary>
        private void DisableSelected()
        {
            IToolkitModule module = _selected;
            if (module == null) return;
            _selected = null;
            bool wasActive = _selectedActive;
            _selectedActive = false;
            if (wasActive) Invoke(module, module.OnDisable);
        }

        /// <summary>
        /// 選択中のモジュールを OnDisable → OnEnable で再起動し、エラーをクリアする(ウィンドウの「再読み込み」)。
        /// 未選択なら false。
        /// </summary>
        internal bool Reload()
        {
            IToolkitModule module = _selected;
            if (module == null) return false;
            string id = SafeId(module);
            Shutdown();
            return Select(id);
        }

        /// <summary>サイドバー用の表示名。DisplayName が空または例外なら Id。</summary>
        internal static string GetDisplayName(IToolkitModule module)
        {
            if (module == null) return "";
            string name = null;
            try
            {
                name = module.DisplayName;
            }
            catch (Exception)
            {
                name = null;
            }
            return string.IsNullOrEmpty(name) ? (SafeId(module) ?? "") : name;
        }

        /// <summary>例外を投げない Id 取得。取得できなければ null。</summary>
        internal static string SafeId(IToolkitModule module)
        {
            if (module == null) return null;
            try
            {
                return module.Id;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private IToolkitModule Find(string id)
        {
            if (id == null) return null;
            foreach (IToolkitModule module in _modules)
            {
                if (string.Equals(SafeId(module), id, StringComparison.Ordinal)) return module;
            }
            return null;
        }

        private bool Invoke(IToolkitModule module, Action action)
        {
            if (ModuleRunner.TryInvoke(action, out Exception error)) return true;
            string id = SafeId(module);
            if (id != null) _errors[id] = error;
            return false;
        }
    }
}
