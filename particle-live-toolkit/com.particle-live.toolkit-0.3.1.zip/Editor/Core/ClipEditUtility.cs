using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Core
{
    /// <summary>クリップ内の 1 本のカーブ(float カーブまたは ObjectReference カーブ)。</summary>
    public readonly struct ClipCurveRef : IEquatable<ClipCurveRef>
    {
        public readonly EditorCurveBinding Binding;
        public readonly bool IsObjectReference;

        public ClipCurveRef(EditorCurveBinding binding, bool isObjectReference)
        {
            Binding = binding;
            IsObjectReference = isObjectReference;
        }

        public bool Equals(ClipCurveRef other)
        {
            return IsObjectReference == other.IsObjectReference && Binding.Equals(other.Binding);
        }

        public override bool Equals(object obj)
        {
            return obj is ClipCurveRef other && Equals(other);
        }

        public override int GetHashCode()
        {
            return Binding.GetHashCode() ^ (IsObjectReference ? 1 : 0);
        }
    }

    /// <summary>AnimationClip の読み取りと安全な書き換え。</summary>
    public static class ClipEditUtility
    {
        /// <summary>
        /// クリップの全カーブ(float カーブ → ObjectReference カーブの順、それぞれ AnimationUtility の返す順)。
        /// clip が null なら空。
        /// </summary>
        public static IReadOnlyList<ClipCurveRef> GetAllCurves(AnimationClip clip)
        {
            if (clip == null) return Array.Empty<ClipCurveRef>();
            var floats = AnimationUtility.GetCurveBindings(clip);
            var objs = AnimationUtility.GetObjectReferenceCurveBindings(clip);
            var result = new ClipCurveRef[floats.Length + objs.Length];
            for (int i = 0; i < floats.Length; i++) result[i] = new ClipCurveRef(floats[i], false);
            for (int i = 0; i < objs.Length; i++) result[floats.Length + i] = new ClipCurveRef(objs[i], true);
            return result;
        }

        /// <summary>
        /// このツールで書き換えてよいクリップか。次の場合は false で、reason に日本語の理由を入れる:
        ///  - null
        ///  - 読み取り専用(FBX などモデルに埋め込まれたクリップ、HideFlags.NotEditable、Packages/ 配下の読み取り専用アセット)
        /// アセットとして保存されていないメモリ上のクリップは書き換え可(テストで使うため)。
        /// true のとき reason は null。
        /// </summary>
        public static bool IsEditable(AnimationClip clip, out string reason)
        {
            if (clip == null)
            {
                reason = "クリップが指定されていません。";
                return false;
            }
            if ((clip.hideFlags & HideFlags.NotEditable) != 0)
            {
                reason = "このクリップは読み取り専用のため書き換えられません。";
                return false;
            }

            string path = AssetDatabase.GetAssetPath(clip);
            if (string.IsNullOrEmpty(path))
            {
                // アセットとして保存されていないメモリ上のクリップ
                reason = null;
                return true;
            }
            if (!AssetDatabase.IsNativeAsset(clip))
            {
                // FBX などから読み込まれたクリップ(インポート結果なので、書き換えても再インポートで消える)
                reason = "モデル(FBX など)に埋め込まれたクリップは書き換えられません。.anim に複製したクリップを使ってください。";
                return false;
            }
            if (IsInReadOnlyPackage(path))
            {
                reason = "読み取り専用のパッケージ内のクリップは書き換えられません。";
                return false;
            }

            reason = null;
            return true;
        }

        static bool IsInReadOnlyPackage(string assetPath)
        {
            if (!assetPath.StartsWith("Packages/", StringComparison.Ordinal)) return false;
            var info = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(assetPath);
            if (info == null) return true; // 所属パッケージが分からない場合は安全側(書き換えない)
            // Embedded(Packages/ 直下に置いたもの)と Local(file: 参照のフォルダ)だけが書き換え可能。
            // Registry / Git / BuiltIn / LocalTarball はキャッシュから展開された読み取り専用。
            return info.source != UnityEditor.PackageManager.PackageSource.Embedded
                && info.source != UnityEditor.PackageManager.PackageSource.Local;
        }

        /// <summary>
        /// ルートの Animator が使う全クリップ(重複なし、null なし)。
        /// RuntimeAnimatorController.animationClips を使う(BlendTree・サブステートマシン・Override Controller を含む)。
        /// controller が null なら空。
        /// </summary>
        public static IReadOnlyList<AnimationClip> CollectClips(RuntimeAnimatorController controller)
        {
            if (controller == null) return Array.Empty<AnimationClip>();
            var result = new List<AnimationClip>();
            var clips = controller.animationClips; // Override Controller では上書き後のクリップが返る(実測)
            if (clips == null) return result;
            var seen = new HashSet<AnimationClip>();
            foreach (var c in clips)
            {
                if (c == null) continue;
                if (seen.Add(c)) result.Add(c);
            }
            return result;
        }
    }

    /// <summary>
    /// 1 つのクリップへの書き換えをまとめて行う単位。
    /// Get で作業用コピーを取り出して編集し、Set で登録、最後に Commit で 1 回だけクリップへ書き込む。
    /// Commit するまでクリップは一切変更されない(= プレビュー計算に使ってもクリップは汚れない)。
    /// </summary>
    public sealed class ClipEditSession
    {
        readonly AnimationClip _clip;
        readonly IReadOnlyList<ClipCurveRef> _curves;

        // 作業用コピー(GetFloatCurve が返したインスタンス)。同じ binding には同じインスタンスを返すために保持する。
        readonly Dictionary<EditorCurveBinding, AnimationCurve> _floatWork = new Dictionary<EditorCurveBinding, AnimationCurve>(BindingComparer.Instance);

        // Set された変更(値 null = 削除)。float と ObjectReference は別々に持ち、登録順も保持する。
        readonly Dictionary<EditorCurveBinding, AnimationCurve> _floatSets = new Dictionary<EditorCurveBinding, AnimationCurve>(BindingComparer.Instance);
        readonly Dictionary<EditorCurveBinding, ObjectReferenceKeyframe[]> _objectSets = new Dictionary<EditorCurveBinding, ObjectReferenceKeyframe[]>(BindingComparer.Instance);
        readonly List<EditorCurveBinding> _floatOrder = new List<EditorCurveBinding>();
        readonly List<EditorCurveBinding> _objectOrder = new List<EditorCurveBinding>();

        /// <exception cref="ArgumentException">ClipEditUtility.IsEditable が false のクリップ。</exception>
        public ClipEditSession(AnimationClip clip)
        {
            if (!ClipEditUtility.IsEditable(clip, out string reason))
                throw new ArgumentException(reason, nameof(clip));
            _clip = clip;
            _curves = ClipEditUtility.GetAllCurves(clip);
        }

        public AnimationClip Clip
        {
            get { return _clip; }
        }

        /// <summary>セッション作成時点のカーブ一覧。</summary>
        public IReadOnlyList<ClipCurveRef> Curves
        {
            get { return _curves; }
        }

        /// <summary>
        /// float カーブの作業用コピー。同じ binding には同じインスタンスを返す。
        /// Set 済みならその値。クリップに存在しなければ null。
        /// </summary>
        public AnimationCurve GetFloatCurve(EditorCurveBinding binding)
        {
            if (_floatSets.TryGetValue(binding, out var set)) return set;
            if (_floatWork.TryGetValue(binding, out var work)) return work;
            if (binding.type == null) return null;
            // GetEditorCurve は毎回新しいコピーを返す(クリップ本体とは共有しない)。存在しなければ null。
            var curve = AnimationUtility.GetEditorCurve(_clip, binding);
            if (curve != null) _floatWork[binding] = curve;
            return curve;
        }

        /// <summary>ObjectReference カーブのキー配列(コピー)。Set 済みならその値。存在しなければ null。</summary>
        public ObjectReferenceKeyframe[] GetObjectCurve(EditorCurveBinding binding)
        {
            if (_objectSets.TryGetValue(binding, out var set)) return set == null ? null : (ObjectReferenceKeyframe[])set.Clone();
            if (binding.type == null) return null;
            // GetObjectReferenceCurve は毎回新しい配列を返す。存在しなければ null。
            return AnimationUtility.GetObjectReferenceCurve(_clip, binding);
        }

        /// <summary>float カーブを登録する。curve が null ならそのカーブを削除する。</summary>
        public void SetFloatCurve(EditorCurveBinding binding, AnimationCurve curve)
        {
            if (binding.type == null) throw new ArgumentException("binding.type が null です。", nameof(binding));
            if (!_floatSets.ContainsKey(binding)) _floatOrder.Add(binding);
            _floatSets[binding] = curve;
            if (curve != null) _floatWork[binding] = curve;
            else _floatWork.Remove(binding);
        }

        /// <summary>ObjectReference カーブを登録する。keys が null ならそのカーブを削除する。</summary>
        public void SetObjectCurve(EditorCurveBinding binding, ObjectReferenceKeyframe[] keys)
        {
            if (binding.type == null) throw new ArgumentException("binding.type が null です。", nameof(binding));
            if (!_objectSets.ContainsKey(binding)) _objectOrder.Add(binding);
            // 呼び出し側が後で配列を書き換えても登録内容が変わらないようにコピーして持つ
            _objectSets[binding] = keys == null ? null : (ObjectReferenceKeyframe[])keys.Clone();
        }

        /// <summary>Set が 1 回でも呼ばれていれば true。</summary>
        public bool HasChanges
        {
            get { return _floatSets.Count > 0 || _objectSets.Count > 0; }
        }

        /// <summary>
        /// 登録済みの変更をクリップへ書き込む。順序:
        ///  1. backup が true なら ClipBackup.EnsureBackedUp(Clip)
        ///  2. Undo.RegisterCompleteObjectUndo(Clip, undoName)(Undo 1 回で全変更が戻ること)
        ///  3. AnimationUtility.SetEditorCurves / SetObjectReferenceCurves でまとめて書き込み
        ///  4. EditorUtility.SetDirty(Clip)
        /// 変更が無ければ何もせず 0。戻り値は書き込んだ(削除を含む)カーブ数。Commit 後のセッションは再利用しない。
        /// </summary>
        public int Commit(string undoName, bool backup = true)
        {
            if (!HasChanges) return 0;

            if (backup) ClipBackup.EnsureBackedUp(_clip);

            // 削除も含めて 1 回の Undo で戻るよう、書き込み前にクリップ全体を記録する
            Undo.RegisterCompleteObjectUndo(_clip, undoName);

            // 実測(Unity 2022.3.22f1):
            //  - SetEditorCurves / SetObjectReferenceCurves はキーの接線・重み・接線モードを再計算せずにそのまま保存する。
            //  - ただし SetEditorCurves は、1 回の呼び出しに「削除(null)」と「新規カーブ」が混ざり、null が先に並ぶと
            //    削除が無視される(Transform の位置では残りの成分まで追加される)。
            //    そのため「削除だけ」の呼び出しを先に行い、次に「書き込みだけ」の呼び出しを行う。
            //    どちらも上の RegisterCompleteObjectUndo の後なので Undo は 1 回のまま。
            WriteFloatCurves(deletes: true);
            WriteFloatCurves(deletes: false);
            WriteObjectCurves(deletes: true);
            WriteObjectCurves(deletes: false);

            EditorUtility.SetDirty(_clip);
            return _floatOrder.Count + _objectOrder.Count;
        }

        void WriteFloatCurves(bool deletes)
        {
            var bindings = new List<EditorCurveBinding>();
            var curves = new List<AnimationCurve>();
            foreach (var b in _floatOrder)
            {
                var c = _floatSets[b];
                if ((c == null) != deletes) continue;
                bindings.Add(b);
                curves.Add(c);
            }
            if (bindings.Count > 0) AnimationUtility.SetEditorCurves(_clip, bindings.ToArray(), curves.ToArray());
        }

        void WriteObjectCurves(bool deletes)
        {
            var bindings = new List<EditorCurveBinding>();
            var keys = new List<ObjectReferenceKeyframe[]>();
            foreach (var b in _objectOrder)
            {
                var k = _objectSets[b];
                if ((k == null) != deletes) continue;
                bindings.Add(b);
                keys.Add(k);
            }
            if (bindings.Count > 0) AnimationUtility.SetObjectReferenceCurves(_clip, bindings.ToArray(), keys.ToArray());
        }

        /// <summary>
        /// EditorCurveBinding の比較。Unity 標準の GetHashCode は type が null だと例外になるため自前で計算する。
        /// 等価判定は Unity の ==(path / type / propertyName / PPtr かどうか)に従う。
        /// </summary>
        sealed class BindingComparer : IEqualityComparer<EditorCurveBinding>
        {
            public static readonly BindingComparer Instance = new BindingComparer();

            public bool Equals(EditorCurveBinding a, EditorCurveBinding b)
            {
                return a == b;
            }

            public int GetHashCode(EditorCurveBinding b)
            {
                unchecked
                {
                    int h = b.path != null ? b.path.GetHashCode() : 0;
                    h = h * 31 + (b.propertyName != null ? b.propertyName.GetHashCode() : 0);
                    h = h * 31 + (b.type != null ? b.type.GetHashCode() : 0);
                    return h;
                }
            }
        }
    }

    /// <summary>
    /// クリップを書き換える前の自動バックアップ。Undo は保存・再起動後には効かないため、
    /// 「そのクリップを Unity 起動後はじめて書き換える直前」に 1 回だけ複製を残す。
    /// </summary>
    public static class ClipBackup
    {
        const string EnabledPrefKey = "ParticleLiveToolkit.ClipBackup.Enabled";

        // 「この Unity 起動中にバックアップ済み」のクリップ GUID(改行区切り)。
        // SessionState は再コンパイル(ドメインリロード)では消えず、Unity を終了すると消える。
        const string DoneSessionKey = "ParticleLiveToolkit.ClipBackup.Done";

        /// <summary>バックアップを取るか(EditorPrefs に保存。既定 true)。</summary>
        public static bool Enabled
        {
            get { return EnabledOverride ?? EditorPrefs.GetBool(EnabledPrefKey, true); }
            set
            {
                if (EnabledOverride.HasValue) EnabledOverride = value;
                else EditorPrefs.SetBool(EnabledPrefKey, value);
            }
        }

        /// <summary>
        /// テスト用。null 以外のあいだは EditorPrefs を読み書きせず、この値だけを使う(メモリ上のみ)。
        /// EditorPrefs はこの PC の全 Unity で共有されるため、テストが実際の設定を書き換えると、
        /// 同時に動いている別の Unity のテストと「元の値」を取り違えて、オフのまま残ることがある。
        /// </summary>
        internal static bool? EnabledOverride;

        /// <summary>
        /// clip が単独の .anim アセットで、この Unity 起動中にまだバックアップしていなければ、
        /// ToolkitPaths.BackupFolder に "{クリップ名}_{yyyyMMdd_HHmmss}.anim" として複製し、そのパスを返す。
        /// 取らなかった場合(無効 / 取得済み / アセットでない / .anim でない / 失敗)は null。例外は投げない。
        /// </summary>
        public static string EnsureBackedUp(AnimationClip clip)
        {
            try
            {
                if (!Enabled || clip == null) return null;
                string path = AssetDatabase.GetAssetPath(clip);
                if (string.IsNullOrEmpty(path)) return null;
                if (!path.EndsWith(".anim", StringComparison.OrdinalIgnoreCase)) return null;
                if (!AssetDatabase.IsMainAsset(clip)) return null;

                string guid = AssetDatabase.AssetPathToGUID(path);
                if (string.IsNullOrEmpty(guid) || IsDone(guid)) return null;

                if (!EnsureFolder(ToolkitPaths.BackupFolder)) return null;
                string fileName = SafeFileName(clip.name, path) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".anim";
                // 同じ秒に同名のバックアップがあれば上書きせず別名にする
                string dest = AssetDatabase.GenerateUniqueAssetPath(ToolkitPaths.BackupFolder + "/" + fileName);
                if (string.IsNullOrEmpty(dest)) return null;

                if (EditorUtility.IsDirty(clip))
                {
                    // 未保存の変更があるときは、ディスク上のファイルではなく「書き換える直前」のメモリ上の内容を残す
                    var copy = Object.Instantiate(clip);
                    copy.name = Path.GetFileNameWithoutExtension(dest);
                    AssetDatabase.CreateAsset(copy, dest);
                }
                else if (!AssetDatabase.CopyAsset(path, dest))
                {
                    Debug.LogWarning("[ParticleLiveToolkit] クリップのバックアップを作れませんでした(複製に失敗): " + path);
                    return null;
                }

                if (AssetDatabase.LoadAssetAtPath<AnimationClip>(dest) == null)
                {
                    Debug.LogWarning("[ParticleLiveToolkit] クリップのバックアップを作れませんでした(複製先を読み込めません): " + dest);
                    return null;
                }
                MarkDone(guid);
                return dest;
            }
            catch (Exception e)
            {
                Debug.LogWarning("[ParticleLiveToolkit] クリップのバックアップに失敗しました: " + e.Message);
                return null;
            }
        }

        /// <summary>「取得済み」の記録を消す(テスト用)。</summary>
        public static void ResetSession()
        {
            SessionState.EraseString(DoneSessionKey);
        }

        static bool IsDone(string guid)
        {
            string done = SessionState.GetString(DoneSessionKey, "");
            if (done.Length == 0) return false;
            return Array.IndexOf(done.Split('\n'), guid) >= 0;
        }

        static void MarkDone(string guid)
        {
            string done = SessionState.GetString(DoneSessionKey, "");
            SessionState.SetString(DoneSessionKey, done.Length == 0 ? guid : done + "\n" + guid);
        }

        static bool EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return true;
            int slash = folder.LastIndexOf('/');
            if (slash <= 0) return false;
            string parent = folder.Substring(0, slash);
            if (!EnsureFolder(parent)) return false;
            AssetDatabase.CreateFolder(parent, folder.Substring(slash + 1));
            return AssetDatabase.IsValidFolder(folder);
        }

        static string SafeFileName(string clipName, string assetPath)
        {
            string name = string.IsNullOrEmpty(clipName) ? Path.GetFileNameWithoutExtension(assetPath) : clipName;
            foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            return name;
        }
    }
}
