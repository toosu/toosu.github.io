using System;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// 全モジュール共通の見た目・操作感をそろえるための IMGUI ヘルパー(EditorGUILayout ベース)。
    /// モジュールは独自のスタイルを作らず、可能な限りここを使う。
    /// </summary>
    public static class ToolkitGUI
    {
        private const float PrimaryButtonHeight = 28f;
        private const float CopyButtonWidth = 56f;

        internal const string RequireProjectMessage = "上部バーでライブ(プロジェクト設定)を選ぶか、Project タブで新規作成してください";

        private static GUIStyle s_reasonStyle;

        private static GUIStyle ReasonStyle
        {
            get
            {
                if (s_reasonStyle == null)
                {
                    s_reasonStyle = new GUIStyle(EditorStyles.miniLabel) { wordWrap = true };
                }
                return s_reasonStyle;
            }
        }

        /// <summary>セクション見出し(太字ラベル + 上に少し余白)。</summary>
        public static void Section(string title)
        {
            GUILayout.Space(8f);
            EditorGUILayout.LabelField(title ?? "", EditorStyles.boldLabel);
        }

        /// <summary>補足説明(情報のヘルプボックス)。</summary>
        public static void Hint(string message)
        {
            EditorGUILayout.HelpBox(message ?? "", MessageType.Info);
        }

        /// <summary>警告(警告のヘルプボックス)。</summary>
        public static void Warning(string message)
        {
            EditorGUILayout.HelpBox(message ?? "", MessageType.Warning);
        }

        /// <summary>エラー(エラーのヘルプボックス)。</summary>
        public static void Error(string message)
        {
            EditorGUILayout.HelpBox(message ?? "", MessageType.Error);
        }

        /// <summary>
        /// 主操作のボタン(高さ 28)。disabledReason が null / 空でなければ押せない状態で描き、
        /// 直下にその理由を小さく表示する(押せない理由を必ず見せる)。押されたら true。
        /// </summary>
        public static bool PrimaryButton(string label, string disabledReason = null)
        {
            bool disabled = !string.IsNullOrEmpty(disabledReason);
            bool pressed;
            using (new EditorGUI.DisabledScope(disabled))
            {
                pressed = GUILayout.Button(label ?? "", GUILayout.Height(PrimaryButtonHeight));
            }
            if (disabled)
            {
                EditorGUILayout.LabelField(disabledReason, ReasonStyle);
            }
            return pressed && !disabled;
        }

        /// <summary>
        /// 「コピー」ボタン(幅固定)。押すと ToolkitClipboard.Copy(text) を呼び、
        /// ctx が非 null なら「{text} をコピーしました」と通知する。押されたら true。
        /// </summary>
        public static bool CopyButton(string text, ToolkitContext ctx)
        {
            if (!GUILayout.Button("コピー", GUILayout.Width(CopyButtonWidth))) return false;
            CopyWithNotification(text, ctx);
            return true;
        }

        /// <summary>
        /// プロジェクト必須のモジュール用。ctx.HasProject なら true を返すだけ。
        /// 無ければ「上部バーでライブ(プロジェクト設定)を選ぶか、Project タブで新規作成してください」と案内を描いて false。
        /// </summary>
        public static bool RequireProject(ToolkitContext ctx)
        {
            if (ctx != null && ctx.HasProject) return true;
            Hint(RequireProjectMessage);
            return false;
        }

        /// <summary>CopyButton が押されたときの処理(描画なし。テスト用に分離)。</summary>
        internal static void CopyWithNotification(string text, ToolkitContext ctx)
        {
            string value = text ?? "";
            ToolkitClipboard.Copy(value);
            ctx?.ShowNotification(value + " をコピーしました");
        }
    }

    /// <summary>クリップボード。テストでは Sink を差し替えて実クリップボードに触れずに検証する。</summary>
    public static class ToolkitClipboard
    {
        /// <summary>null のときは EditorGUIUtility.systemCopyBuffer に書く。</summary>
        internal static Action<string> Sink;

        public static void Copy(string text)
        {
            string value = text ?? "";
            Action<string> sink = Sink;
            if (sink != null)
            {
                sink(value);
            }
            else
            {
                EditorGUIUtility.systemCopyBuffer = value;
            }
        }
    }
}
