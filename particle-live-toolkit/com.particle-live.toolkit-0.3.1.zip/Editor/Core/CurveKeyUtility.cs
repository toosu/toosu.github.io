using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// キーフレームの時間範囲操作(クリップに依存しない純粋関数。AnimationCurve / ObjectReferenceKeyframe[] を直接扱う)。
    ///
    /// 共通規則:
    ///  - 範囲は半開区間 [start, endExclusive)。判定は TimeEpsilon の許容つき:
    ///    key.time >= start - TimeEpsilon かつ key.time &lt; endExclusive - TimeEpsilon のキーが範囲内。
    ///  - 「同じ時刻」= 時刻の差が TimeEpsilon 以下。
    ///  - 貼り付け先の時刻は (float)((double)元の時刻 + offset)。コピーを重ねても誤差が累積しない計算にすること。
    ///  - 接線(inTangent / outTangent)、重み(inWeight / outWeight / weightedMode)、接線モード
    ///    (AnimationUtility の Left / Right TangentMode と Broken)は元のキーの値をそのまま写す。再計算しない。
    /// </summary>
    public static class CurveKeyUtility
    {
        /// <summary>時刻比較の許容誤差(秒)。float の精度(300 秒付近で約 3e-5)より大きく、64 分音符より十分小さい値。</summary>
        public const double TimeEpsilon = 1e-4;

        // 実装メモ(接線の再計算を避ける):
        //  キーは Keyframe 構造体をコピーして time だけ書き換え、配列を組み立てて curve.keys = ... で一括代入する。
        //  Keyframe 構造体は接線モード(Left / Right / Broken)を内部フィールドに持つため、構造体のコピーでそのまま写る。
        //  AnimationUtility.SetKeyLeftTangentMode などのモード設定 API は使わない(モードは写すだけで設定し直さない)。

        static bool InRange(float time, double start, double endExclusive)
        {
            double t = time;
            return t >= start - TimeEpsilon && t < endExclusive - TimeEpsilon;
        }

        static bool SameTime(float a, float b)
        {
            return Math.Abs((double)a - (double)b) <= TimeEpsilon;
        }

        static float PastedTime(float time, double offset)
        {
            return (float)((double)time + offset);
        }

        /// <summary>範囲内のキー数。curve が null なら 0。</summary>
        public static int CountRange(AnimationCurve curve, double start, double endExclusive)
        {
            if (curve == null) return 0;
            int n = 0;
            foreach (var k in curve.keys)
                if (InRange(k.time, start, endExclusive)) n++;
            return n;
        }

        /// <summary>範囲内のキーを削除し、削除した数を返す。curve が null なら 0。</summary>
        public static int RemoveRange(AnimationCurve curve, double start, double endExclusive)
        {
            if (curve == null) return 0;
            var keys = curve.keys;
            var kept = new List<Keyframe>(keys.Length);
            foreach (var k in keys)
                if (!InRange(k.time, start, endExclusive)) kept.Add(k);
            int removed = keys.Length - kept.Count;
            if (removed > 0) curve.keys = kept.ToArray();
            return removed;
        }

        /// <summary>
        /// src の範囲内のキーを offset 秒ずらして dst に貼る(src は変更しない。src と dst が同じインスタンスでもよい)。
        ///  - dst に「同じ時刻」のキーが既にある場合: replaceExisting が true なら置き換え、false ならそのキーは貼らない。
        ///  - 戻り値は実際に貼った(追加または置き換えた)キー数。
        /// </summary>
        public static int CopyRange(AnimationCurve src, double start, double endExclusive, double offset, AnimationCurve dst, bool replaceExisting = true)
        {
            if (src == null || dst == null) return 0;

            // dst を書き換える前に src のキーを取り出しておく(src と dst が同じインスタンスでも元のキーを読む)
            var pasted = new List<Keyframe>();
            foreach (var k in src.keys)
            {
                if (!InRange(k.time, start, endExclusive)) continue;
                var copy = k; // 構造体コピー: 接線・重み・接線モードがそのまま写る
                copy.time = PastedTime(k.time, offset);
                pasted.Add(copy);
            }
            if (pasted.Count == 0) return 0;

            var existing = dst.keys;
            int count = Merge(existing, pasted, k => k.time, replaceExisting, out var merged);
            if (count > 0) dst.keys = merged.ToArray();
            return count;
        }

        /// <summary>範囲内のキー数。keys が null なら 0。</summary>
        public static int CountRange(ObjectReferenceKeyframe[] keys, double start, double endExclusive)
        {
            if (keys == null) return 0;
            int n = 0;
            foreach (var k in keys)
                if (InRange(k.time, start, endExclusive)) n++;
            return n;
        }

        /// <summary>範囲内のキーを除いた新しい配列を返す(時刻昇順)。keys が null なら空配列。</summary>
        public static ObjectReferenceKeyframe[] RemoveRange(ObjectReferenceKeyframe[] keys, double start, double endExclusive, out int removed)
        {
            removed = 0;
            if (keys == null) return new ObjectReferenceKeyframe[0];
            var kept = new List<ObjectReferenceKeyframe>(keys.Length);
            foreach (var k in keys)
            {
                if (InRange(k.time, start, endExclusive)) removed++;
                else kept.Add(k);
            }
            return SortByTime(kept, k => k.time);
        }

        /// <summary>
        /// src の範囲内のキーを offset 秒ずらして dst に貼った新しい配列を返す(時刻昇順。src / dst は変更しない)。
        /// 「同じ時刻」の既存キーの扱いは AnimationCurve 版と同じ。pasted は実際に貼った数。
        /// </summary>
        public static ObjectReferenceKeyframe[] CopyRange(ObjectReferenceKeyframe[] src, double start, double endExclusive, double offset, ObjectReferenceKeyframe[] dst, out int pasted, bool replaceExisting = true)
        {
            var existing = dst ?? new ObjectReferenceKeyframe[0];
            var toPaste = new List<ObjectReferenceKeyframe>();
            if (src != null)
            {
                foreach (var k in src)
                {
                    if (!InRange(k.time, start, endExclusive)) continue;
                    toPaste.Add(new ObjectReferenceKeyframe { time = PastedTime(k.time, offset), value = k.value });
                }
            }
            pasted = Merge(existing, toPaste, k => k.time, replaceExisting, out var merged);
            return merged.ToArray();
        }

        /// <summary>
        /// existing に toPaste を合流させ、時刻昇順(同時刻は元の並び順を保つ安定ソート)の結果を返す。
        /// 「同じ時刻」の判定は貼る前の existing のキーに対してだけ行う。
        /// 戻り値は実際に貼ったキー数。
        /// </summary>
        static int Merge<T>(T[] existing, List<T> toPaste, Func<T, float> time, bool replaceExisting, out List<T> merged)
        {
            var removedExisting = new bool[existing.Length];
            var accepted = new List<T>(toPaste.Count);
            foreach (var p in toPaste)
            {
                float pt = time(p);
                bool hasSame = false;
                for (int i = 0; i < existing.Length; i++)
                {
                    if (!SameTime(time(existing[i]), pt)) continue;
                    hasSame = true;
                    if (replaceExisting) removedExisting[i] = true;
                }
                if (hasSame && !replaceExisting) continue;
                accepted.Add(p);
            }

            var all = new List<T>(existing.Length + accepted.Count);
            for (int i = 0; i < existing.Length; i++)
                if (!removedExisting[i]) all.Add(existing[i]);
            all.AddRange(accepted);
            merged = SortByTime(all, time).ToList();
            return accepted.Count;
        }

        static T[] SortByTime<T>(List<T> items, Func<T, float> time)
        {
            // OrderBy は安定ソート
            return items.OrderBy(time).ToArray();
        }
    }
}
