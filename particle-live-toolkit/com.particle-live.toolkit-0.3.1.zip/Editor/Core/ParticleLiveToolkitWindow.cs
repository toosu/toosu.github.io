using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ParticleLiveToolkit.Core
{
    /// <summary>
    /// メインウィンドウ。上部バー(編集中のライブの ObjectField と BPM 欄)、左サイドバー(モジュール一覧)、
    /// 右に選択中モジュールの OnGUI。ロジックは ModuleHost / ToolkitContext に置き、ここは描画と配線だけ。
    ///
    /// 配線:
    ///  - OnEnable : ToolkitContext と ModuleHost を作り、前回選択していたモジュール(無ければ先頭)を Select。
    ///               編集中のライブは Unity プロジェクト単位で記憶して復元する。
    ///  - OnDisable: ModuleHost.Shutdown()(再コンパイル前にも呼ばれる)。
    ///  - Undo.undoRedoPerformed: ToolkitContext.RaiseProjectChanged() と Repaint。
    ///  - モジュールが例外を出したら、そのモジュールの領域にエラー内容と「再読み込み」ボタンを表示する。
    /// </summary>
    public sealed class ParticleLiveToolkitWindow : EditorWindow
    {
        public const string MenuPath = "Tools/Particle Live Toolkit";

        private const string SelectedModuleConfigKey = "ParticleLiveToolkit.SelectedModule";
        private const float SidebarWidth = 150f;

        [SerializeField] private string _selectedId;
        [SerializeField] private Vector2 _sidebarScroll;
        [SerializeField] private Vector2 _contentScroll;

        private ToolkitContext _context;
        private ModuleHost _host;
        private readonly List<string> _problems = new List<string>();
        private bool _showProblems;
        private GUIStyle _tabStyle;

        [MenuItem(MenuPath)]
        public static void Open()
        {
            Open(null);
        }

        /// <summary>ウィンドウを開き、指定モジュールを選択する。</summary>
        public static void Open(string moduleId)
        {
            var window = GetWindow<ParticleLiveToolkitWindow>();
            window.Show();
            if (!string.IsNullOrEmpty(moduleId))
            {
                window.SelectModule(moduleId);
            }
            window.Focus();
        }

        private void OnEnable()
        {
            titleContent = new GUIContent("Particle Live Toolkit");
            minSize = new Vector2(480f, 320f);

            _context = new ToolkitContext(Repaint, ShowNotificationText);
            _context.SetActiveProject(LoadRememberedProject());
            _context.ProjectChanged += OnProjectChanged;

            _problems.Clear();
            _host = new ModuleHost(ModuleRegistry.CreateModules(false, _problems), _context);
            SelectInitialModule();

            Undo.undoRedoPerformed += OnUndoRedo;
        }

        private void OnDisable()
        {
            Undo.undoRedoPerformed -= OnUndoRedo;
            if (_context != null)
            {
                _context.ProjectChanged -= OnProjectChanged;
            }
            if (_host != null)
            {
                _host.Shutdown();
                foreach (var module in _host.Modules)
                    if (module is IDisposable disposable) disposable.Dispose();
            }
        }

        // ---- 配線 ----

        private static ParticleLiveProject LoadRememberedProject()
        {
            try
            {
                return ActiveProjectMemory.Load();
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void SelectInitialModule()
        {
            string id = !string.IsNullOrEmpty(_selectedId) ? _selectedId : EditorUserSettings.GetConfigValue(SelectedModuleConfigKey);
            if (string.IsNullOrEmpty(id) || !_host.Select(id))
            {
                if (_host.Modules.Count > 0)
                {
                    _host.Select(ModuleHost.SafeId(_host.Modules[0]));
                }
            }
            RememberSelection();
        }

        private void SelectModule(string id)
        {
            if (_host == null || !_host.Select(id)) return;
            _showProblems = false;
            _contentScroll = Vector2.zero;
            RememberSelection();
            Repaint();
        }

        private void RememberSelection()
        {
            string id = ModuleHost.SafeId(_host.Selected);
            if (string.IsNullOrEmpty(id)) return;
            _selectedId = id;
            if (EditorUserSettings.GetConfigValue(SelectedModuleConfigKey) != id)
            {
                EditorUserSettings.SetConfigValue(SelectedModuleConfigKey, id);
            }
        }

        private void OnProjectChanged()
        {
            try
            {
                ActiveProjectMemory.Save(_context.ActiveProject);
            }
            catch (Exception)
            {
                // 記憶できなくてもウィンドウの動作には影響しない
            }
            Repaint();
        }

        private void OnUndoRedo()
        {
            _context?.RaiseProjectChanged();
            Repaint();
        }

        private void ShowNotificationText(string message)
        {
            ShowNotification(new GUIContent(message));
        }

        // ---- 描画 ----

        private void OnGUI()
        {
            if (_host == null || _context == null)
            {
                ToolkitGUI.Error("ウィンドウの初期化に失敗しました。ウィンドウを閉じて開き直してください。");
                return;
            }

            DrawTopBar();
            DrawHorizontalLine();

            using (new EditorGUILayout.HorizontalScope(GUILayout.ExpandHeight(true)))
            {
                DrawSidebar();
                DrawVerticalLine();
                DrawContent();
            }
        }

        private void DrawTopBar()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(4f);
                GUILayout.Label("ライブ", GUILayout.ExpandWidth(false));
                EditorGUI.BeginChangeCheck();
                var picked = (ParticleLiveProject)EditorGUILayout.ObjectField(
                    _context.ActiveProject, typeof(ParticleLiveProject), false, GUILayout.MinWidth(120f), GUILayout.MaxWidth(260f));
                if (EditorGUI.EndChangeCheck())
                {
                    _context.SetActiveProject(picked);
                }

                GUILayout.Space(12f);
                GUILayout.Label("BPM", GUILayout.ExpandWidth(false));
                double before = _context.Bpm;
                EditorGUI.BeginChangeCheck();
                // ラベルなしのオーバーロードは Unity 2022.3 で毎フレーム「DrawPrefixLabel ... GUIContent that is null」を出すため、GUIContent.none を渡す。
                double bpm = EditorGUILayout.DelayedDoubleField(GUIContent.none, before, GUILayout.Width(64f));
                if (EditorGUI.EndChangeCheck() && !bpm.Equals(before))
                {
                    _context.SetBpm(bpm);
                    if (_context.Bpm.Equals(before))
                    {
                        ShowNotificationText("BPM は 0 より大きい数を入力してください");
                    }
                }

                if (!_context.HasProject)
                {
                    GUILayout.Label("未選択(BPM は一時値)", EditorStyles.miniLabel, GUILayout.ExpandWidth(false));
                }
                GUILayout.FlexibleSpace();
            }
        }

        static readonly string[] Categories = { "", "プロジェクト", "音楽・時間", "アニメーション", "オブジェクト・演出", "プレビュー", "拡張" };
        static int CategoryOrder(string id)
        {
            switch (id)
            {
                case "quick": case "workspace": case "utilities": return 0;
                case "project": case "presets": return 1;
                case "beat": case "snap": case "markers": return 2;
                case "animation": case "pathfixer": return 3;
                case "transform": case "material": case "particles": case "rename": return 4;
                case "preview": return 5;
                default: return 6;
            }
        }

        private void DrawSidebar()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.Width(SidebarWidth)))
            {
                _sidebarScroll = EditorGUILayout.BeginScrollView(_sidebarScroll);
                GUILayout.Space(4f);

                string previousCategory = null;
                foreach (IToolkitModule module in System.Linq.Enumerable.OrderBy(_host.Modules, m => CategoryOrder(ModuleHost.SafeId(m))))
                {
                    string id = ModuleHost.SafeId(module);
                    string category = Categories[CategoryOrder(id)];
                    if (category != previousCategory && category.Length > 0)
                        EditorGUILayout.LabelField(category, EditorStyles.miniBoldLabel);
                    previousCategory = category;
                    bool isSelected = !_showProblems && ReferenceEquals(module, _host.Selected);
                    string label = ModuleHost.GetDisplayName(module);
                    if (_host.GetError(id) != null)
                    {
                        label += "(エラー)";
                    }

                    bool clicked = GUILayout.Toggle(isSelected, label, TabStyle);
                    if (clicked && !isSelected)
                    {
                        if (ReferenceEquals(module, _host.Selected))
                        {
                            _showProblems = false;
                        }
                        else
                        {
                            SelectModule(id);
                        }
                        // レイアウトが変わるので、このイベントの描画はここで打ち切る
                        GUIUtility.ExitGUI();
                    }
                }

                if (_problems.Count > 0)
                {
                    GUILayout.Space(8f);
                    bool show = GUILayout.Toggle(_showProblems, "読み込めないモジュール " + _problems.Count + " 件", TabStyle);
                    if (show != _showProblems)
                    {
                        _showProblems = show;
                        GUIUtility.ExitGUI();
                    }
                }

                EditorGUILayout.EndScrollView();

                // クリップを書き換える機能すべてに効く安全策なので、どのタブからも見える場所に置く
                bool backup = ClipBackup.Enabled;
                bool newBackup = EditorGUILayout.ToggleLeft(
                    new GUIContent("クリップを自動バックアップ", "AnimationClip を書き換える前に、Unity を起動してから最初の 1 回だけ " + ToolkitPaths.BackupFolder + " に複製を残します。"),
                    backup, GUILayout.Width(SidebarWidth - 4f));
                if (newBackup != backup) ClipBackup.Enabled = newBackup;
                GUILayout.Space(4f);
            }
        }

        private void DrawContent()
        {
            using (new EditorGUILayout.VerticalScope())
            {
                _contentScroll = EditorGUILayout.BeginScrollView(_contentScroll);
                GUILayout.Space(4f);
                DrawContentBody();
                EditorGUILayout.EndScrollView();
            }
        }

        private void DrawContentBody()
        {
            if (_showProblems)
            {
                DrawProblems();
                return;
            }

            if (_host.Modules.Count == 0)
            {
                ToolkitGUI.Hint("表示できるモジュールがありません。IToolkitModule を実装した public クラス(引数なしコンストラクタ)を追加すると、ここに表示されます。");
                if (_problems.Count > 0) DrawProblems();
                return;
            }

            IToolkitModule selected = _host.Selected;
            if (selected == null)
            {
                ToolkitGUI.Hint("左の一覧からモジュールを選んでください。");
                return;
            }

            string id = ModuleHost.SafeId(selected);
            Exception error = _host.GetError(id);
            if (error != null)
            {
                DrawModuleError(selected, error);
                return;
            }

            _host.DrawSelected();
            if (_host.GetError(id) != null)
            {
                // 途中で例外が出るとレイアウトの対応が崩れるので、このフレームは捨てて次の描画でエラー表示にする
                Repaint();
                GUIUtility.ExitGUI();
            }
        }

        private void DrawModuleError(IToolkitModule module, Exception error)
        {
            ToolkitGUI.Section(ModuleHost.GetDisplayName(module));
            ToolkitGUI.Error("このモジュールでエラーが発生しました。他のモジュールはそのまま使えます。\n"
                + error.GetType().Name + ": " + error.Message);
            if (ToolkitGUI.PrimaryButton("再読み込み"))
            {
                _host.Reload();
                Repaint();
                GUIUtility.ExitGUI();
            }
            if (GUILayout.Button("詳細をコンソールに出力", GUILayout.ExpandWidth(false)))
            {
                Debug.LogException(error);
            }
        }

        private void DrawProblems()
        {
            ToolkitGUI.Section("読み込めないモジュール");
            ToolkitGUI.Warning(string.Join("\n", _problems));
        }

        private GUIStyle TabStyle
        {
            get
            {
                if (_tabStyle == null)
                {
                    _tabStyle = new GUIStyle(GUI.skin.button)
                    {
                        alignment = TextAnchor.MiddleLeft,
                        fixedHeight = 24f,
                        padding = new RectOffset(8, 4, 2, 2),
                        margin = new RectOffset(4, 4, 1, 1),
                    };
                }
                return _tabStyle;
            }
        }

        private static Color LineColor
        {
            get { return EditorGUIUtility.isProSkin ? new Color(0.1f, 0.1f, 0.1f, 1f) : new Color(0.6f, 0.6f, 0.6f, 1f); }
        }

        private static void DrawHorizontalLine()
        {
            Rect rect = GUILayoutUtility.GetRect(1f, 1f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(rect, LineColor);
        }

        private static void DrawVerticalLine()
        {
            Rect rect = GUILayoutUtility.GetRect(1f, 1f, GUILayout.Width(1f), GUILayout.ExpandHeight(true));
            EditorGUI.DrawRect(rect, LineColor);
        }
    }
}
