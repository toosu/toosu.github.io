using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ParticleLiveToolkit.Core
{
    /// <summary>パッケージ内のパス解決。Assets/ 配下に置いても Packages/ 配下に置いても動く。</summary>
    public static class ToolkitPaths
    {
        /// <summary>クリップのバックアップ先フォルダ。</summary>
        public const string BackupFolder = "Assets/ParticleLiveToolkit_Backups";

        private const string EditorAssemblyName = "ParticleLiveToolkit.Editor";

        private static string s_packageRoot;

        /// <summary>
        /// このパッケージのルート(AssetDatabase 形式、"/" 区切り、末尾 "/" なし)。
        /// 例: "Packages/com.particle-live.toolkit" または "Assets/ParticleLiveToolkit"。
        /// ParticleLiveToolkit.Editor の asmdef の場所から求める。
        /// </summary>
        public static string PackageRoot
        {
            get
            {
                if (s_packageRoot == null)
                {
                    s_packageRoot = ResolvePackageRoot();
                }
                return s_packageRoot;
            }
        }

        /// <summary>PackageRoot + "/Editor/Templates"。</summary>
        public static string TemplatesFolder
        {
            get
            {
                string root = PackageRoot;
                return root == null ? null : root + "/Editor/Templates";
            }
        }

        /// <summary>
        /// Templates フォルダ内のテキストテンプレート(TextAsset、拡張子 .txt)の中身を返す。無ければ null。
        /// fileName は拡張子込み(例: "ParticleLivePlayer.cs.txt")。
        /// </summary>
        public static string LoadTemplateText(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return null;
            // Templates フォルダの外を指せないようにする。
            if (fileName.IndexOf('/') >= 0 || fileName.IndexOf('\\') >= 0 || fileName == "." || fileName == "..") return null;

            string folder = TemplatesFolder;
            if (folder == null) return null;
            var asset = AssetDatabase.LoadAssetAtPath<TextAsset>(folder + "/" + fileName);
            return asset != null ? asset.text : null;
        }

        private static string ResolvePackageRoot()
        {
            try
            {
                string asmdef = CompilationPipeline.GetAssemblyDefinitionFilePathFromAssemblyName(EditorAssemblyName);
                string root = RootFromAsmdefPath(asmdef);
                if (root != null) return root;
            }
            catch (Exception)
            {
                // 次の方法を試す
            }

            try
            {
                var info = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(ToolkitPaths).Assembly);
                if (info != null && !string.IsNullOrEmpty(info.assetPath))
                {
                    return Normalize(info.assetPath);
                }
            }
            catch (Exception)
            {
                // 求められない
            }
            return null;
        }

        /// <summary>".../&lt;root&gt;/Editor/ParticleLiveToolkit.Editor.asmdef" から &lt;root&gt; を取り出す。</summary>
        private static string RootFromAsmdefPath(string asmdefPath)
        {
            if (string.IsNullOrEmpty(asmdefPath)) return null;
            string path = Normalize(asmdefPath);
            if (!path.StartsWith("Assets/", StringComparison.Ordinal) && !path.StartsWith("Packages/", StringComparison.Ordinal)) return null;

            int fileSlash = path.LastIndexOf('/');
            if (fileSlash <= 0) return null;
            string editorFolder = path.Substring(0, fileSlash);
            int editorSlash = editorFolder.LastIndexOf('/');
            if (editorSlash <= 0) return null;
            return editorFolder.Substring(0, editorSlash);
        }

        private static string Normalize(string path)
        {
            return path.Replace('\\', '/').TrimEnd('/');
        }
    }

    /// <summary>プロジェクト設定とシーン内オブジェクトの対応付け。</summary>
    public static class ProjectSceneUtility
    {
        /// <summary>
        /// ライブルートを探す。rootGlobalId(GlobalObjectId)で見つかればそれ、
        /// 見つからなければ rootPath("A/B/C" 形式。先頭はシーン直下のオブジェクト名)で読み込み済みシーンから探す(非アクティブ含む)。
        /// どちらも無ければ null。project が null でも null。
        /// </summary>
        public static GameObject FindRoot(ParticleLiveProject project)
        {
            if (project == null) return null;
            GameObject byId = FindByGlobalId(project.rootGlobalId);
            if (byId != null) return byId;
            if (GlobalObjectId.TryParse(project.rootGlobalId, out var id) && !id.assetGUID.Empty())
            {
                var scene = SceneManager.GetSceneByPath(AssetDatabase.GUIDToAssetPath(id.assetGUID.ToString()));
                if (!scene.isLoaded) return null;
                foreach (var candidate in scene.GetRootGameObjects())
                    foreach (var child in candidate.GetComponentsInChildren<Transform>(true))
                        if (GetScenePath(child) == project.rootPath) return child.gameObject;
                return null;
            }
            return FindByScenePath(project.rootPath);
        }

        /// <summary>
        /// ライブルートを設定する(Undo 可能、SetDirty 済み)。rootGlobalId と rootPath の両方を更新する。root が null ならクリア。
        /// </summary>
        public static void SetRoot(ParticleLiveProject project, GameObject root)
        {
            if (project == null) return;
            Undo.RecordObject(project, "ライブルートの設定");
            if (root == null)
            {
                project.rootGlobalId = "";
                project.rootPath = "";
            }
            else
            {
                project.rootGlobalId = GetStableGlobalId(root);
                project.rootPath = GetScenePath(root.transform) ?? "";
            }
            EditorUtility.SetDirty(project);
        }

        /// <summary>シーン直下からのフルパス("A/B/C")。</summary>
        public static string GetScenePath(Transform transform)
        {
            if (transform == null) return null;
            var names = new List<string>();
            for (Transform t = transform; t != null; t = t.parent)
            {
                names.Add(t.name);
            }
            names.Reverse();
            return string.Join("/", names);
        }

        /// <summary>
        /// 視点の「目の位置」と向きを返す。
        /// anchorPath が空でなく、ライブルートからの相対パスで Transform が見つかれば、その position + up * eyeHeight と rotation。
        /// そうでなければ viewpoint.position + Vector3.up * eyeHeight と Quaternion.Euler(eulerAngles)。
        /// viewpoint が null なら false。
        /// </summary>
        public static bool TryGetViewpointPose(ParticleLiveProject project, Viewpoint viewpoint, out Vector3 eyePosition, out Quaternion rotation)
        {
            eyePosition = Vector3.zero;
            rotation = Quaternion.identity;
            if (viewpoint == null) return false;

            if (!string.IsNullOrEmpty(viewpoint.anchorPath))
            {
                GameObject root = FindRoot(project);
                Transform anchor = root != null ? root.transform.Find(viewpoint.anchorPath) : null;
                if (anchor != null)
                {
                    // アンカーの「上」方向(傾けたアンカーなら傾いた上方向)に目の高さを取る。
                    eyePosition = anchor.position + anchor.up * viewpoint.eyeHeight;
                    rotation = anchor.rotation;
                    return true;
                }
            }

            eyePosition = viewpoint.position + Vector3.up * viewpoint.eyeHeight;
            rotation = Quaternion.Euler(viewpoint.eulerAngles);
            return true;
        }

        private static GameObject FindByGlobalId(string globalId)
        {
            if (string.IsNullOrEmpty(globalId)) return null;
            try
            {
                if (!GlobalObjectId.TryParse(globalId, out GlobalObjectId id)) return null;
                Object obj = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(id);
                GameObject go = obj as GameObject;
                if (go == null && obj is Component component && component != null) go = component.gameObject;
                // シーン上のオブジェクトだけを対象にする(プレハブアセットなどは除く)。
                if (go == null || EditorUtility.IsPersistent(go) || !go.scene.IsValid()) return null;
                return go;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static GameObject FindByScenePath(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;
            int slash = path.IndexOf('/');
            string first = slash < 0 ? path : path.Substring(0, slash);
            string rest = slash < 0 ? null : path.Substring(slash + 1);

            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                Scene scene = SceneManager.GetSceneAt(i);
                if (!scene.isLoaded) continue;
                foreach (GameObject go in scene.GetRootGameObjects())
                {
                    if (go.name != first) continue;
                    if (string.IsNullOrEmpty(rest)) return go;
                    // Transform.Find は非アクティブの子も "/" 区切りでたどれる。
                    Transform found = go.transform.Find(rest);
                    if (found != null) return found.gameObject;
                }
            }
            return null;
        }

        /// <summary>保存済みシーンのオブジェクトなら GlobalObjectId 文字列、未保存シーンなど安定しない場合は ""。</summary>
        private static string GetStableGlobalId(GameObject root)
        {
            try
            {
                GlobalObjectId id = GlobalObjectId.GetGlobalObjectIdSlow(root);
                if (id.identifierType == 0 || id.assetGUID.Empty() || id.targetObjectId == 0) return "";
                return id.ToString();
            }
            catch (Exception)
            {
                return "";
            }
        }
    }
}
