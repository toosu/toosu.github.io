# Particle Live Toolkit

このツールは作る過程の楽しみはユーザーに残し、めんどくさい作業の効率化にフォーカスしたEditor拡張です。

パーティクルライブをワールドとして作成するために使用する事を想定したツールです。

アバターには対応していない場合があります。

## 導入

[ALCOM・VCCの登録ページ](https://toosu.github.io/particle-live-toolkit/)

リポジトリを追加したら、対象プロジェクトのパッケージ一覧で「Particle Live Toolkit」をインストールします。Unityで「Tools → Particle Live Toolkit」を開き、「Project」から曲とBPMを設定してください。

Unity 2022.3・Unity Timeline 1.7系。VRChat用の同期再生スクリプトの自動設定にはWorlds SDKとUdonSharpを使います。

旧unitypackage版から更新すると、パッケージ管理ツールが Assets/ParticleLiveToolkit を削除します。そこに独自に追加・編集したファイルは先に退避してください。通常のライブ作品は別フォルダの Assets/ParticleLive にあります。

## 手間を減らす操作と使い方

| 効率化できる作業 | 使う場所・操作 |
|---|---|
| 曲・Animation・Timelineの配置を一度で済ませる | Project → ライブを生成 |
| 小節や音符の秒数を暗算せずコピーする | よく使う項目 → 秒数コピー（細かい指定は Beat） |
| 選択したキーのタイミングをまとめて拍に揃える | Beat Snap → 選択キーを拍に合わせる |
| 選んだカーブを1・2・4拍間隔で4回ずつ追加する | よく使う項目 → 現在の範囲を取得 → ビートで4回 など（詳細設定は Animation） |
| オフ・オンの2つのキーを一度に打つ | Hierarchyで対象を選択 → UnityのAnimationウィンドウで Ctrl+R。現在フレームがオン、1フレーム前がオフ。0フレームではオンのみ。 |
| 同じ箇所を頭出しし直さずに聴き比べる | UnityのTimeline・Animationでスペース長押し → 離すと元の位置。目印の登録は Marker System → 現在位置にマーカーを追加 |
| 床・トレイル・Burst・雪の初期設定を省く | 便利ツール → 透明な床（Collider）、マテリアル付き Particle、マテリアル付き Trail Particle、Burst 100、広範囲に降る雪 |
| アニメーション中の発生数を調べてMax Particlesを見積もる手間を省く | Hierarchyで対象を選択 → 便利ツール → Max Particles → 必要数を計算して適用 |
| 階層を変えた後のAnimationパスをまとめて直す | よく使う項目 → 変更前に押す → 改名・移動 → 変更後に押す（個別確認は Path Fixer） |
| 同じ調整を複数のオブジェクトにまとめて適用する | 整列は Transform、連番は Batch Rename、粒子設定は Particle Editor、マテリアル変更は Material Editor |
| 作った演出をPrefabとして次のシーンでも使う | Effect Preset → 選択した演出を保存。呼び出すときは一覧の「配置」 |
| 観客視点で同じ区間だけ繰り返し確認する | Preview → 区間ループ |
| ライブを切り替えるたびにシーンと編集位置を探す手間を省く | ライブの編集 → ライブ設定を読み込む → このライブの編集に戻る |
